import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { HomePanelProps, HomePanel, NotebookItem } from "./HomePanel";
import { ThemeName, newId, parseJson, UserProfile } from "../shared/types";


export class ShelfHome
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;

    private eventName = "";
    private eventPayload = "";
    private eventId = "";

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);

        this.host = document.createElement("div");
        this.host.className = "shelf shelf-home";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;

        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        this.host.style.height = h > 0 ? `${h}px` : "100%";
        this.host.style.width = w > 0 ? `${w}px` : "100%";

        const props: HomePanelProps = {
            notebooks: parseJson<NotebookItem[]>(p.NotebooksJson?.raw, []),
            logoSvg: p.LogoSvg?.raw ?? "",
            logoUrl: p.LogoUrl?.raw ?? "",
            appName: p.AppName?.raw || "RCPG Agent",
            heroHeadline: p.HeroHeadline?.raw || "Your retail & CPG co-pilot.",
            heroDescription: p.HeroDescription?.raw || "Ask questions grounded in your own sources — pricing, share, promotions and assortment.",
            userName: p.UserName?.raw ?? "",
            theme: (p.Theme?.raw || "dark") as ThemeName,
            isAdmin: p.IsAdmin?.raw === true,
            showObservability: p.ShowObservability?.raw === true,
            // add to each control's props object in updateView:
            userProfile: parseJson<UserProfile | null>(p.UserProfileJson?.raw, null),
            onEvent: (name, payload) => this.emit(name, payload),
        };

        this.root.render(React.createElement(HomePanel, props));
    }

    private emit(name: string, payload?: unknown): void {
        this.eventName = name;
        this.eventPayload = payload === undefined ? "" : JSON.stringify(payload);
        this.eventId = newId();
        this.notify();
    }

    public getOutputs(): IOutputs {
        return {
            EventName: this.eventName,
            EventPayload: this.eventPayload,
            EventId: this.eventId,
        };
    }

    public destroy(): void {
        this.root.unmount();
    }
}
