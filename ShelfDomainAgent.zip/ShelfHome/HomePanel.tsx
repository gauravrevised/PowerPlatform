import * as React from "react";
import { Plus, MoreVertical, Pencil, Trash2, Sun, Moon, Settings, Activity, ShieldCheck } from "lucide-react";
import { ThemeName, UserProfile } from "../shared/types";
import { ProfileCard } from "../shared/ProfileCard";
import { CommonMenuItems } from "../shared/CommonMenuItems";


export interface NotebookItem {
    id: string;
    name: string;
    createdOn: string;
    sourceCount: number;
}

export interface HomePanelProps {
    notebooks: NotebookItem[];
    logoSvg: string;
    logoUrl: string;
    appName: string;
    heroHeadline: string;      
    heroDescription: string;
    userName: string;
    isAdmin: boolean;
    showObservability: boolean;
    theme: ThemeName;
    userProfile: UserProfile | null;
    onEvent: (name: string, payload?: unknown) => void;
}

/* Same safe SVG sandboxing as Workspace.tsx */
const BrandMark: React.FC<{ svg: string; url: string }> = ({ svg, url }) => {
    if (svg.trim().startsWith("<svg")) {
        const src = `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
        return <img className="ws-logo" src={src} alt="" aria-hidden="true" />;
    }
    if (url) return <img className="ws-logo" src={url} alt="" aria-hidden="true" />;
    return (
        <svg className="ws-logo" viewBox="0 0 64 64" aria-hidden="true">
            <rect width="64" height="64" rx="16" fill="currentColor" />
            <rect x="16" y="22" width="32" height="4" rx="2" fill="#fff" />
            <rect x="16" y="42" width="32" height="4" rx="2" fill="#fff" />
            <rect x="20" y="10" width="9" height="12" rx="2" fill="#fff" />
            <rect x="33" y="14" width="9" height="12" rx="2" fill="#fff" opacity=".55" />
            <rect x="20" y="32" width="14" height="10" rx="2" fill="#fff" opacity=".55" />
        </svg>

    );
};

const NotebookCard: React.FC<{
    item: NotebookItem;
    onEvent: (name: string, payload?: unknown) => void;
}> = ({ item, onEvent }) => {
    const [menuOpen, setMenuOpen] = React.useState(false);
    

    const fmt = (iso: string) => {
        try {
            return new Date(iso).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
        } catch {
            return iso;
        }
    };

    return (
        <div className="nb-card" onClick={() => onEvent("NotebookOpened", { type: "existing", id: item.id, name: item.name })}>
            <div className="nb-card-top">
                <div className="nb-card-icon">
                    <span className="nb-card-initial">{item.name.trim()[0]?.toUpperCase() ?? "N"}</span>
                </div>
                <div className="nb-card-menu-wrap">
                    <button
                        className="iconbtn sm"
                        aria-label="More options"
                        onClick={(e) => { e.stopPropagation(); setMenuOpen((o) => !o); }}
                    >
                        <MoreVertical size={16} />
                    </button>
                    {menuOpen ? (
                        <>
                            <div className="ws-menu-scrim" onClick={(e) => { e.stopPropagation(); setMenuOpen(false); }} />
                            <div className="ws-menu nb-card-dropdown">
                                <button className="ws-mi" onClick={(e) => {
                                    e.stopPropagation(); setMenuOpen(false);
                                    onEvent("NotebookRenameRequested", { id: item.id, name: item.name });
                                }}>
                                    <Pencil size={15} className="mi-i" />
                                    <span>Edit title</span>
                                </button>
                                <button className="ws-mi danger" onClick={(e) => {
                                    e.stopPropagation(); setMenuOpen(false);
                                    onEvent("NotebookDeleteRequested", { id: item.id, name: item.name });
                                }}>
                                    <Trash2 size={15} />
                                    <span>Delete</span>
                                </button>
                            </div>
                        </>
                    ) : null}
                </div>
            </div>
            <div className="nb-card-name">{item.name}</div>
            <div className="nb-card-meta">
                {fmt(item.createdOn)} · {item.sourceCount} source{item.sourceCount === 1 ? "" : "s"}
            </div>
        </div>
    );
};

export const HomePanel: React.FC<HomePanelProps> = ({
    notebooks, logoSvg, logoUrl, appName, heroHeadline, heroDescription, userName, theme, isAdmin, showObservability, userProfile, onEvent,
}) => {
    const [menuOpen, setMenuOpen] = React.useState(false);
    const [profileOpen, setProfileOpen] = React.useState(false);

    const initials = (userName || "U")
        .split(" ").filter(Boolean).slice(0, 2)
        .map((w) => w[0].toUpperCase()).join("");

    return (
        <div className="ws" data-t={theme}>
            {/* Header — same structure as Workspace, minus ws-title */}
            <header className="ws-top">
                <button className="ws-brand" aria-label="Go to home" onClick={() => onEvent("NavigateHome")}>
                    <BrandMark svg={logoSvg} url={logoUrl} />
                    <span className="ws-name">{appName}</span>
                </button>
                <div className="ws-sp" />
                <div className="ws-actions">
                    <button className="iconbtn" title="Switch theme"
                        onClick={() => onEvent("ThemeToggled", { theme: theme === "dark" ? "light" : "dark" })}>
                        {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
                    </button>
                    <button className={"iconbtn" + (menuOpen ? " on" : "")} title="Settings"
                        onClick={() => setMenuOpen(!menuOpen)}>
                        <Settings size={18} />
                    </button>
                    <div style={{ position: "relative" }}>
                        <button className="ws-avatar" title={userName || "Profile"}
                            onClick={() => setProfileOpen(v => !v)}>
                            {initials}
                        </button>
                        {profileOpen && userProfile ? (
                            <ProfileCard
                                profile={userProfile}
                                initials={initials}
                                onClose={() => setProfileOpen(false)}
                            />
                        ) : null}
                    </div>
                    {menuOpen ? (
                        <>
                            <div className="ws-menu-scrim" onClick={() => setMenuOpen(false)} />
                            <div className="ws-menu">
                            {showObservability ? (
                                <button className="ws-mi"
                                    onClick={() => { setMenuOpen(false); onEvent("OpenObservability"); }}>
                                    <Activity size={16} className="mi-i" />
                                    <span>Observability<span className="mi-s">Usage, grounding, guardrail</span></span>
                                </button>
                            ) : null}
                            {isAdmin ? (
                                <button className="ws-mi"
                                    onClick={() => { setMenuOpen(false); onEvent("NavigateAdminScreen"); }}>
                                    <ShieldCheck size={16} />
                                    <span>Admin<span className="mi-s">Limits, roles and users</span></span>
                                </button>
                            ) : null}
                                                        <CommonMenuItems
                                withSeparator={showObservability || isAdmin}
                                onProfile={userProfile ? () => { setMenuOpen(false); setProfileOpen(true); } : undefined}
                                onHelp={() => { setMenuOpen(false); onEvent("OpenHelp"); }}
                                onFeedback={() => { setMenuOpen(false); onEvent("SendFeedback"); }}
                            />
                        </div>
                        </>
                    ) : null}
                </div>
            </header>

            {/* Body */}
            <div className="home-body">
                <div className="home-hero">
                    <h1 className="home-hero-title">{heroHeadline}</h1>
                    <p className="home-hero-sub">{heroDescription}</p>
                </div>
                <div className="home-section">
                    <div className="home-section-label">Recent Workspaces</div>
                    <div className="home-grid">
                        {/* Create new card */}
                        <button
                            className="nb-card nb-card-new"
                            onClick={() => onEvent("NotebookOpened", { type: "new" })}
                        >
                            <div className="nb-new-icon"><Plus size={22} /></div>
                            <div className="nb-card-name">Create new agent workspace</div>
                        </button>

                        {/* Existing notebooks */}
                        {notebooks.map((nb) => (
                            <NotebookCard key={nb.id} item={nb} onEvent={onEvent} />
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};
