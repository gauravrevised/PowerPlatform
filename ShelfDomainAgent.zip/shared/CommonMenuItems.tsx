import * as React from "react";
import { LifeBuoy, MessageSquare, User } from "lucide-react";

export interface CommonMenuItemsProps {
    onHelp: () => void;
    onFeedback: () => void;
    onProfile?: () => void;        // omit when there is no profile to show
    withSeparator?: boolean;       // draw a divider above the items
}

export const CommonMenuItems: React.FC<CommonMenuItemsProps> = ({
    onHelp, onFeedback, onProfile, withSeparator,
}) => (
    <>
        {withSeparator ? (
            <div style={{ height: 1, background: "var(--line)", margin: "4px 6px" }} />
        ) : null}
        {onProfile ? (
            <button className="ws-mi" onClick={onProfile}>
                <User size={16} />
                <span>My profile<span className="mi-s">Name, email and role</span></span>
            </button>
        ) : null}
        <button className="ws-mi" onClick={onHelp}>
            <LifeBuoy size={16} />
            <span>Help &amp; guide<span className="mi-s">How to use this app</span></span>
        </button>
        <button className="ws-mi" onClick={onFeedback}>
            <MessageSquare size={16} />
            <span>Send feedback<span className="mi-s">Report an issue or idea</span></span>
        </button>
    </>
);