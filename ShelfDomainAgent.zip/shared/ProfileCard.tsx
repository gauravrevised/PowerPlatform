import * as React from "react";
import { X, Mail, Briefcase, Building2 } from "lucide-react";
import { UserProfile } from "./types";

interface ProfileCardProps {
    profile: UserProfile;
    initials: string;
    onClose: () => void;
}

export const ProfileCard: React.FC<ProfileCardProps> = ({ profile, initials, onClose }) => (
    <>
        <div className="ws-menu-scrim" onClick={onClose} />
        <div className="profile-card" role="dialog" aria-label="Profile">
            <button className="profile-close iconbtn sm" onClick={onClose} aria-label="Close">
                <X size={14} />
            </button>
            <div className="profile-avatar">{initials}</div>
            <div className="profile-name">{profile.name}</div>
            {profile.role ? (
                <div className="profile-row">
                    <Briefcase size={13} />
                    <span>{profile.role}</span>
                </div>
            ) : null}
            {profile.department ? (
                <div className="profile-row">
                    <Building2 size={13} />
                    <span>{profile.department}</span>
                </div>
            ) : null}
            {profile.email ? (
                <div className="profile-row">
                    <Mail size={13} />
                    <span>{profile.email}</span>
                </div>
            ) : null}
        </div>
    </>
);