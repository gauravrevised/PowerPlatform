/*
 * ShelfMind PCF - shared contracts
 * Every control parses its JSON inputs into these shapes.
 * Keep this file in sync with CONTRACTS.md.
 */

import type { ComponentType, SVGProps } from "react";

export type ThemeName = "light" | "dark";

export type IconCmp = ComponentType<
  SVGProps<SVGSVGElement> & {
    size?: string | number;
    className?: string;
  }
>;

export type PanelKey = "sources" | "chat" | "studio" | "shell";
/* — sources ---------------------------------------------------- */

export type SourceGroup = "retail" | "cpg" | "mine";

export interface SourceItem {
  id: string;
  title: string;
  meta?: string;
  group: SourceGroup;
  isBuiltIn?: boolean;
  flagged?: boolean;
  kind?: "file" | "link";
  /** Canonical file name. Used to resolve agent citations back to this record. */
  fileName?: string;
  /** Short description shown in the viewer and on citation hover. */
  summary?: string;
  /** Opens the source in place, e.g. a SharePoint preview link. */
  url?: string;
  downloadUrl?: string;
  pages?: number;
}

export interface GuardrailState {
  active: boolean;
  domain: string;
  blockedToday?: number;
  /** Bullet list shown in the guardrail dialog. */
  rules?: string[];
}

export interface DiscoverResult {
  id: string;
  title: string;
  source: string;
  snippet?: string;
  url?: string;
}

export interface DiscoverState {
  status: "idle" | "loading" | "done" | "error";
  query?: string;
  topics?: string[];
  results?: DiscoverResult[];
  message?: string;
}

/* — chat ---------------------------------------------------- */

export interface Citation {
  index: number;
  sourceId: string;
  /** Filename the agent returned, when the flow could not resolve an id. */
  fileName?: string;
  sourceTitle?: string;
  /** Passage the answer leaned on. */
  snippet?: string;
  /** One-line description of the whole source, shown on hover. */
  summary?: string;
  url?: string;
  page?: number;
}

export type QuestionOrigin = "typed" | "suggested" | "followup";

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  text: string;
  citations?: Citation[];
  /** Agent-generated next questions, rendered as chips under this answer. */
  followUps?: string[];
  status?: "ok" | "blocked" | "low";
  createdOn?: string;
}

export interface NotebookMeta {
  title: string;
  emoji?: string;
  summary?: string;
  topics?: string[];
}

export interface SuggestedQuestion {
  id: string;
  text: string;
}

/* — viewer payloads ---------------------------------------------------- */

export interface SlideItem {
  title: string;
  bullets: string[];
}

export interface QuizQuestion {
  id: string;
  prompt: string;
  options: string[];
  answerIndex: number;
  explanation?: string;
}

export interface PathModule {
  n: number;
  title: string;
  desc?: string;
  hours?: string;
  sourceTitles?: string[];
  done?: boolean;
}

export interface LearningPath {
  id?: string;
  title?: string;
  role: string;
  level: string;
  goal?: string;
  totalHours?: string;
  modules: PathModule[];
}

export interface TextSection {
  heading?: string;
  body: string;
}

export type ViewerPayload =
  | { type: "doc"; data: SourceItem }
  | { type: "slides"; data: { id?: string; title?: string; slides: SlideItem[] } }
  | { type: "quiz"; data: { id?: string; title?: string; passMark?: number; questions: QuizQuestion[] } }
  | { type: "path"; data: LearningPath }
  | { type: "text"; data: { id?: string; title?: string; meta?: string; sections: TextSection[] } };

/* — studio ---------------------------------------------------- */

export interface StudioTool {
  id: string;
  name: string;
  sub?: string;
  icon?: "slides" | "quiz" | "guide" | "brief" | "path";
  enabled?: boolean;
}

export interface StudioOutput {
  id: string;
  type: string;
  name: string;
  meta?: string;
  createdOn?: string;
  status?: "queued" | "running" | "complete" | "failed";
}

export interface PathDefaults {
  roles?: string[];
  levels?: string[];
  role?: string;
  level?: string;
  goal?: string;
}



/* — command channel (app → control) ————————————————— */
export interface Command {
  id:string;
  action:string;
  payload?:any;
}


/* — helpers ————————————————————————————————————————— */

export function parseJson<T>(raw: string | null | undefined, fallback: T): T {
  if (!raw) return fallback;
  try {
    const v = JSON.parse(raw) as T;
    return v === null || v === undefined ? fallback : v;
  } catch {
    return fallback;
  }
}

export function newId(): string {
  const c = (globalThis as { crypto?: Crypto }).crypto;
  if (c && typeof c.randomUUID === "function") return c.randomUUID();
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

/* — admin —————————————————————————————————————————————— */

export type AdminFieldType = "text" | "textarea" | "number" | "boolean" | "choice" | "email" | "segmented" | "people";

export interface AdminFieldSchema {
  key: string;
  label: string;
  type: AdminFieldType;
  required: boolean;
  options?: string[];
  helpText?: string;
  min?: number;
  max?: number;
  minLength?: number;
  maxLength?: number;
  defaultValue?: AdminSettingValue;
  onError?: string;
  /** Rendered but not editable — e.g. a value locked by an org-wide admin setting. */
  readOnly?: boolean;
}
export interface AdminPersonResult { name: string; email: string; title?: string; }
/* — shared schema-driven form helpers (used by AdminPanel and Workspace's SettingsDialog) — */

export function withDefaults(schema: AdminFieldSchema[], values: AdminSettingValues): AdminSettingValues {
  const out: AdminSettingValues = { ...values };
  schema.forEach((f) => {
    if ((out[f.key] === undefined || out[f.key] === null) && f.defaultValue !== undefined) {
      out[f.key] = f.defaultValue;
    }
  });
  return out;
}

export function validateField(f: AdminFieldSchema, value: AdminSettingValues[string]): string | null {
  if (f.readOnly) return null;
  const isEmpty = value === null || value === undefined || value === "";

  if (f.required && isEmpty) return f.onError || `${f.label} is required.`;
  if (isEmpty) return null;

  if (f.type === "text" || f.type === "textarea" || f.type === "email" || f.type === "people") {
    const str = String(value);
    if (f.minLength !== undefined && str.length < f.minLength) {
      return f.onError || `${f.label} must be at least ${f.minLength} characters.`;
    }
    if (f.maxLength !== undefined && str.length > f.maxLength) {
      return f.onError || `${f.label} must be ${f.maxLength} characters or fewer.`;
    }
    if ((f.type === "email" || f.type === "people") && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(str)) {
      return f.onError || "Enter a valid email address.";
    }
  }

  if (f.type === "number") {
    const n = Number(value);
    if (f.min !== undefined && n < f.min) return f.onError || `${f.label} must be at least ${f.min}.`;
    if (f.max !== undefined && n > f.max) return f.onError || `${f.label} must be ${f.max} or less.`;
  }

  return null;
}

export function validateForm(schema: AdminFieldSchema[], values: AdminSettingValues): Record<string, string> {
  const errs: Record<string, string> = {};
  schema.forEach((f) => {
    const msg = validateField(f, values[f.key]);
    if (msg) errs[f.key] = msg;
  });
  return errs;
}

export type AdminSettingValue = string | number | boolean | null;
export type AdminSettingValues = Record<string, AdminSettingValue>;

export interface AdminRoleOption {
  id: string;
  name: string;
}

export interface AdminUserRow {
  id: string;             // rcpg_workspaceroleid
  userId: string;
  name: string;
  email: string;
  roleId: string;
  roleName: string;
  status: "Invited" | "Active" | "Revoked";
}

export interface UserProfile {
    name:       string;
    email:      string;
    role:       string;
    department?: string;
    avatarUrl?:  string;
}


/* — observability ———————————————————————————————— */

/** One logged control event. The host stamps `at` and the user when it writes the row. */
export interface TelemetryRow {
  id?: string;
  /** ISO timestamp (Power Fx: Now() converted to UTC). */
  at: string;
  userId: string;
  userName?: string;
  notebookId?: string;
  /** sources | chat | studio | shell | home | admin */
  panel?: string;
  /** Event name exactly as the control emitted it, e.g. AskQuestion. */
  name: string;
  /** EventPayload as an object or as the raw JSON string. */
  payload?: Record<string, unknown> | string | null;
}

/** Picker entry. AdminUserRow from the Admin control is accepted as is. */
export interface ObsUser {
  userId: string;
  name?: string;
  email?: string;
  roleName?: string;
  status?: string;
}
