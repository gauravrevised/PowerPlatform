import * as React from "react";
import {
    Presentation, ListChecks, BookOpen, FileText, Route, Sparkles, Loader2, Trash2,
    PanelRight, X, AlertTriangle, Clock,
} from "lucide-react";
import {
    Command, IconCmp,PathDefaults, StudioOutput, StudioTool, ThemeName,
} from "../shared/types";

export interface StudioPanelProps {
    tools: StudioTool[];
    outputs: StudioOutput[];
    busyToolId: string;
    collapsed?: boolean
    pathDefaults: PathDefaults;
    selectedCount: number;
    minSources: number;
    errorText: string;
    theme: ThemeName;
    command?: Command;
    onRequestPathDialog?: () => void;
    onEvent: (name: string, payload?: unknown) => void;
}

const ICONS: Record<string, IconCmp> = {
    slides: Presentation,
    quiz: ListChecks,
    guide: BookOpen,
    brief: FileText,
    path: Route,
};

const iconFor = (t: StudioTool | StudioOutput): IconCmp => {
    const key: string = ("icon" in t && t.icon) ? String(t.icon) 
    : ("type" in t && t.type) ? String(t.type)
    : String(t.id);
    return ICONS[key as string] ?? FileText;
};

export const StudioPanel: React.FC<StudioPanelProps> = (props) => {
    const {
        tools, outputs, busyToolId,collapsed , pathDefaults, selectedCount, minSources,
        errorText, theme, command, onRequestPathDialog,onEvent,
    } = props;

    const [dialog, setDialog] = React.useState(false);
    const busy = busyToolId.length > 0;
    const tooFewSources = selectedCount < minSources;
    
    React.useEffect(() => {
        if (!command) return;
        if (command.action === "OpenPathDialog") setDialog(true);
        if (command.action === "CloseDialog") setDialog(false);
    }, [command]);

if (collapsed) {
    return (
        <button
            className="panel panel-collapsed"
            data-t={theme}
            title="Open studio"
            onClick={() => onEvent("ExpandRequested", { panel: "studio" })}
        >
            {/* <PanelRight size={17} /> */}
            <span className="ph-icon">
            <svg
                    width="17"
                    height="17"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                >
                    <rect x="3" y="3" width="7" height="7" rx="1.5"></rect>
                    <rect x="14" y="3" width="7" height="7" rx="1.5"></rect>
                    <rect x="3" y="14" width="7" height="7" rx="1.5"></rect>
                    <rect x="14" y="14" width="7" height="7" rx="1.5"></rect>
                </svg></span>
            <span className="ph-label">Tools</span>
            {busyToolId ? <span className="ph-dot" /> : null}
        </button>
    );
}
    return (
        <div className="panel" data-t={theme}>
            <div className="ph"  onClick={() => onEvent("CollapseRequested", { panel: "studio" })}>
                
                <button className="glyph" title="Collapse"
                    onClick={() => onEvent("CollapseRequested", { panel: "studio" })}>
                    {/* <PanelRight size={17} /> */}
                    <svg
                    width="17"
                    height="17"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.8"
                >
                    <rect x="3" y="3" width="7" height="7" rx="1.5"></rect>
                    <rect x="14" y="3" width="7" height="7" rx="1.5"></rect>
                    <rect x="3" y="14" width="7" height="7" rx="1.5"></rect>
                    <rect x="14" y="14" width="7" height="7" rx="1.5"></rect>
                </svg>
                
                </button>
                <h2>Tools</h2>
                <span className="ph-dot"></span>
            </div>

            <div className="scroll">
                {errorText ? (
                    <div className="warn err">
                        <AlertTriangle size={15} className="werr wicon" />
                        <span>{errorText}</span>
                    </div>
                ) : null}

                {tooFewSources ? (
                    <div className="warn">
                        <AlertTriangle size={15} className="werr wicon" />
                        <span>
                            Select at least {minSources} source{minSources === 1 ? "" : "s"} before generating. Outputs are only as grounded as what is ticked.
                        </span>
                    </div>
                ) : null}

                {/* learning path, the one tool that needs input first */}
                <div className="feature">
                    <div className="feature-top">
                        <Route size={18} className="di" />
                        <div>
                            <div className="ft">Learning path</div>
                            <div className="fs">
                                Answer three questions about your role and goal.
                            </div>
                        </div>
                    </div>
                    <button className="pillbtn solid full mt12"
                        disabled={busy || tooFewSources}
                        onClick={() => (onRequestPathDialog ? onRequestPathDialog() : setDialog(true))}>
                        {busyToolId === "path"
                            ? <><Loader2 size={14} className="spin" /> Building...</>
                            : <><Sparkles size={14} /> Create path</>}
                    </button>
                </div>

                <div className="tools">
                    {tools.map((t) => {
                        const Icon = iconFor(t);
                        const thisBusy = busyToolId === t.id;
                        return (
                            <button key={t.id} className={"tool" + (thisBusy ? " busy" : "")}
                                disabled={busy || tooFewSources}
                                onClick={() => onEvent("GenerateRequested", { tool: t.id, toolName: t.name })}>
                                {thisBusy
                                    ? <Loader2 size={18} className="ti spin" />
                                    : <Icon size={18} className="ti" />}
                                <div className="tn">{t.name}</div>
                                <div className="ts">{thisBusy ? "Generating..." : (t.sub ?? "")}</div>
                            </button>
                        );
                    })}
                </div>

                <div className="subh">Outputs</div>
                {outputs.length === 0 ? (
                    <div className="dash">
                        Nothing generated yet. Slides, quizzes and learning paths you create collect here.
                    </div>
                ) : (
                    outputs.map((o) => {
                        const Icon = iconFor(o);
                        const pending = o.status === "queued" || o.status === "running";
                        const failed = o.status === "failed";
                        return (
                            <div className={"out" + (failed ? " failed" : "")} key={o.id}>
                                {pending
                                    ? <Loader2 size={16} className="oi spin" />
                                    : <Icon size={16} className="oi" />}
                                <button className="out-b" disabled={pending}
                                    onClick={() => onEvent("OpenOutput", { id: o.id, type: o.type })}>
                                    <div className="on">{o.name}</div>
                                    <div className="om">
                                        {pending
                                            ? (o.status === "queued" ? "Queued..." : "Generating...")
                                            : failed ? "Failed. Tap retry." : (o.meta ?? "")}
                                    </div>
                                </button>
                                {failed ? (
                                    <button className="iconbtn sm" aria-label="Retry"
                                        onClick={() => onEvent("RetryOutput", { id: o.id, type: o.type })}>
                                        <Sparkles size={14} />
                                    </button>
                                ) : null}
                                <button className="iconbtn sm" aria-label="Delete output"
                                    disabled={pending}
                                    onClick={() => onEvent("DeleteOutput", { id: o.id })}>
                                    <Trash2 size={14} />
                                </button>
                            </div>
                        );
                    })
                )}
            </div>

            {dialog && !onRequestPathDialog ? (
                <PathDialog
                    defaults={pathDefaults}
                    onClose={() => setDialog(false)}
                    onCreate={(role, level, goal) => {
                        setDialog(false);
                        onEvent("CreatePathRequested", { role, level, goal });
                    }}
                />
            ) : null}
        </div>
    );
};

/* ── path dialog ──────────────────────────────────────────────── */

export const PathDialog: React.FC<{
    defaults: PathDefaults;
    onClose: () => void;
    onCreate: (role: string, level: string, goal: string) => void;
}> = ({ defaults, onClose, onCreate }) => {
    const roles = defaults.roles ?? [];
    const levels = defaults.levels ?? [];
    const [role, setRole] = React.useState(defaults.role ?? roles[0] ?? "");
    const [level, setLevel] = React.useState(defaults.level ?? levels[0] ?? "");
    const [goal, setGoal] = React.useState(defaults.goal ?? "");

    return (
        <div className="scrim" onClick={onClose}>
            <div className="dlg" onClick={(e) => e.stopPropagation()}>
                <div className="dlg-top">
                    <div>
                        <h3>Build a learning path</h3>
                        <p className="dsub">
                            Modules are sequenced from the selected sources and sized to your answers.
                        </p>
                    </div>
                    <button className="iconbtn" onClick={onClose} aria-label="Close"><X size={18} /></button>
                </div>

                <div className="dlg-scroll">
                    <div className="fld">
                        <label>Your role</label>
                        <div className="segs">
                            {roles.map((r) => (
                                <button key={r} className={"seg" + (role === r ? " on" : "")}
                                    onClick={() => setRole(r)}>{r}</button>
                            ))}
                        </div>
                    </div>

                    <div className="fld">
                        <label>Experience level</label>
                        <div className="segs">
                            {levels.map((l) => (
                                <button key={l} className={"seg" + (level === l ? " on" : "")}
                                    onClick={() => setLevel(l)}>{l}</button>
                            ))}
                        </div>
                    </div>

                    <div className="fld">
                        <label>What do you want to be able to do?</label>
                        <textarea rows={3} value={goal} onChange={(e) => setGoal(e.target.value)}
                            placeholder="Run my first joint business plan with a national grocery account" />
                    </div>

                    <div className="warn">
                        <Clock size={15} className="wicon di" />
                    <span>Paths take up to a minute to build. You can keep working while it runs.</span>
                </div>
            </div>

            <div className="dlg-act end">
                <button className="pillbtn" onClick={onClose}>Cancel</button>
                <button className="pillbtn fill" disabled={!role || !level}
                    onClick={() => onCreate(role, level, goal.trim() || "general readiness in the role")}>
                    <Sparkles size={15} /> Create path
                </button>
            </div>
        </div>
    </div>
  );
};
