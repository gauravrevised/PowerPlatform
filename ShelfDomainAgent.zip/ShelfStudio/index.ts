import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { StudioPanel, StudioPanelProps } from "./StudioPanel";
import {
    Command, PathDefaults, StudioOutput, StudioTool, ThemeName, newId, parseJson,
} from "../shared/types";

const DEFAULT_TOOLS: StudioTool[] = [
    { id: "slides", name: "Slide deck", sub: "Board-ready summary", icon: "slides", enabled: true },
    { id: "quiz", name: "Quiz", sub: "Check understanding", icon: "quiz", enabled: true },
    { id: "guide", name: "Study guide", sub: "Terms and questions", icon: "guide", enabled: true },
    { id: "brief", name: "Briefing doc", sub: "One-page summary", icon: "brief", enabled: true },
];

const DEFAULT_PATH: PathDefaults = {
    roles: ["Category manager", "Key account manager", "Store manager", "Brand manager", "Analyst"],
    levels: ["New to the field", "Some experience", "Experienced"],
};

export class ShelfStudio
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;

    private eventName = "";
    private eventPayload = "";
    private eventId = "";

    private lastCommandId = "";
    private command?: Command;

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);

        this.host = document.createElement("div");
        this.host.className = "shelf shelf-studio";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;

        const tools = parseJson<StudioTool[]>(p.ToolsJson?.raw, DEFAULT_TOOLS);
        const outputs = parseJson<StudioOutput[]>(p.OutputsJson?.raw, []);
        const pathDefaults = parseJson<PathDefaults>(p.PathDefaultsJson?.raw, DEFAULT_PATH);

        const cmd = parseJson<Command | null>(p.Command?.raw, null);
        if (cmd && cmd.id && cmd.id !== this.lastCommandId) {
            this.lastCommandId = cmd.id;
            this.command = cmd;
        } else {
            this.command = undefined;
        }

        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        if (h > 0) this.host.style.height = `${h}px`;
        if (w > 0) this.host.style.width = `${w}px`;

        const props: StudioPanelProps = {
            tools: tools.filter((t) => t.enabled !== false),
            outputs,
            busyToolId: p.BusyToolId?.raw ?? "",
            pathDefaults: {
                roles: pathDefaults.roles ?? DEFAULT_PATH.roles,
                levels: pathDefaults.levels ?? DEFAULT_PATH.levels,
                role: pathDefaults.role,
                level: pathDefaults.level,
                goal: pathDefaults.goal,
            },
            selectedCount: p.SelectedCount?.raw ?? 0,
            minSources: p.MinSources?.raw ?? 1,
            errorText: p.ErrorText?.raw ?? "",
            theme: ((p.Theme?.raw || "dark") as ThemeName),
            command: this.command,
            onEvent: (name, payload) => this.emit(name, payload),
        };

        this.root.render(React.createElement(StudioPanel, props));
    }

    private emit(name: string, payload?: unknown): void {
        this.eventName = name;
        this.eventPayload = payload === undefined ? "" : JSON.stringify(payload);
        this.eventId = newId();
        this.notify();
    }

    public getOutputs(): IOutputs {
        return {
            EventName: this.eventName,
            EventPayload: this.eventPayload,
            EventId: this.eventId,
        };
    }

    public destroy(): void {
        this.root.unmount();
    }
}
