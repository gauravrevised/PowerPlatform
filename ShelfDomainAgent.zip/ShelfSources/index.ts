import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { SourcesPanel, SourcesPanelProps } from "./SourcesPanel";
import {
  Command,
  GuardrailState,
  SourceItem,
  ThemeName,
  newId,
  parseJson,
} from "../shared/types";

export class ShelfSources
  implements ComponentFramework.StandardControl<IInputs, IOutputs> {

  private root!: Root;
  private host!: HTMLDivElement;
  private notify!: () => void;

  /* outputs */
  private selectedIds: string[] = [];
  private eventName = "";
  private eventPayload = "";
  private eventId = "";

  /* command de-duplication */
  private lastCommandId = "";
  private command?: Command;

  /* set once from SelectedIdsIn, then owned by the control */
  private seeded = false;

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    _state: ComponentFramework.Dictionary,
    container: HTMLDivElement,
  ): void {
    this.notify = notifyOutputChanged;
    context.mode.trackContainerResize(true);

    this.host = document.createElement("div");
    this.host.className = "shelf shelf-sources";
    container.appendChild(this.host);
    this.root = createRoot(this.host);
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    const p = context.parameters;

    const sources = parseJson<SourceItem[]>(p.SourcesJson?.raw, []);
    const guardrail = parseJson<GuardrailState>(p.GuardrailJson?.raw, {
      active: true,
      domain: "Retail & CPG",
    });

    /* seed selection from the app on first paint only */
    if (!this.seeded) {
      const seed = (p.SelectedIdsIn?.raw ?? "").split(",").map((s) => s.trim()).filter(Boolean);
      // this.selectedIds = seed.length ? seed : sources.map((s) => s.id);
      this.selectedIds = seed.length ? seed : [];
      this.seeded = true;
    }

    /* honour a new command exactly once */
    const cmd = parseJson<Command | null>(p.Command?.raw, null);
    if (cmd && cmd.id && cmd.id !== this.lastCommandId) {
      this.lastCommandId = cmd.id;
      this.command = cmd;
      if (cmd.action === "SetSelection" && Array.isArray(cmd.payload?.ids)) {
        this.selectedIds = cmd.payload!.ids as string[];
      }
      if (cmd.action === "SelectAll") {
        this.selectedIds = sources.map((s) => s.id);
      }
      if (cmd.action === "ClearSelection") {
        this.selectedIds = [];
      }
    } else {
      this.command = undefined;
    }

    const height = context.mode.allocatedHeight;
    const width = context.mode.allocatedWidth;
    if (height > 0) this.host.style.height = `${height}px`;
    if (width > 0) this.host.style.width = `${width}px`;

    const props: SourcesPanelProps = {
      sources,
      selectedIds: this.selectedIds,
      guardrail,
      isBusy: p.IsBusy?.raw === true,
      highlightIds: (p.HighlightIds?.raw ?? "").split(",").map((x) => x.trim()).filter(Boolean),
      theme: (p.Theme?.raw || "dark") as ThemeName,
      sourceLimit: p.SourceLimit?.raw ?? 50,
      maxInlineFileBytes: p.MaxInlineFileBytes?.raw ?? 1572864,
      command: this.command,
      onSelectionChange: (ids) => {
        this.selectedIds = ids;
        this.emit("SelectionChanged", { ids });
      },
      onEvent: (name, payload) => this.emit(name, payload),
    };

    this.root.render(React.createElement(SourcesPanel, props));
  }

  private emit(name: string, payload?: unknown): void {
    this.eventName = name;
    this.eventPayload = payload === undefined ? "" : JSON.stringify(payload);
    this.eventId = newId();
    this.notify();
  }

  public getOutputs(): IOutputs {
    return {
      SelectedIds: this.selectedIds.join(","),
      SelectedCount: this.selectedIds.length,
      EventName: this.eventName,
      EventPayload: this.eventPayload,
      EventId: this.eventId,
    };
  }

  public destroy(): void {
    this.root.unmount();
  }
}
