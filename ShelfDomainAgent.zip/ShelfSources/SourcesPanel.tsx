import * as React from "react";
import {
  FileText,
  Plus,
  Search,
  Check,
  ChevronDown,
  ChevronRight,
  Upload,
  Trash2,
  Store,
  Package,
  ShieldCheck,
  AlertTriangle,
  Globe,
  X,
  Link2,
  ClipboardPaste,
  Loader2,
  Compass,
  PanelLeft,
} from "lucide-react";
import {
  Command,
  GuardrailState,
  IconCmp,
  SourceItem,
  ThemeName,
} from "../shared/types";

type GroupKey = "retail" | "cpg" | "mine";

export interface SourcesPanelProps {
  sources: SourceItem[];
  selectedIds: string[];
  guardrail: GuardrailState;
  isBusy: boolean;
  collapsed?: boolean;
  /** Source ids to flash-outline, e.g. after a citation click. */
  onRequestAddDialog?: () => void;
  highlightIds?: string[];
  theme: ThemeName;
  sourceLimit: number;
  maxInlineFileBytes: number;
  command?: Command;
  onSelectionChange: (ids: string[]) => void;
  onEvent: (name: string, payload?: unknown) => void;
}

const Box: React.FC<{ on: boolean }> = ({ on }) => (
  <span className={"cbx" + (on ? " on" : "")}>
    {on ? <Check size={12} strokeWidth={3.5} /> : null}
  </span>
);

export const SourcesPanel: React.FC<SourcesPanelProps> = (props) => {
  const {
    sources,
    selectedIds,
    guardrail,
    isBusy,
    collapsed,
    onRequestAddDialog,
    highlightIds,
    theme,
    sourceLimit,
    maxInlineFileBytes,
    command,
    onSelectionChange,
    onEvent,
  } = props;

  const hot = React.useMemo(() => new Set(highlightIds ?? []), [highlightIds]);

  const [query, setQuery] = React.useState("");
  const [open, setOpen] = React.useState<Record<GroupKey,boolean>>({
    retail: false,
    cpg: false,
    mine: true,
  });
  const [dialog, setDialog] = React.useState<"none" | "add">("none");

  React.useEffect(() => {
    if (!command) return;
    if (command.action === "ClearSearch") setQuery("");
    if (command.action === "OpenAdd") {
      if (onRequestAddDialog) onRequestAddDialog(); else setDialog("add");
    }
    if (command.action === "CloseDialog") setDialog("none");
  }, [command]);

  const sel = React.useMemo(() => new Set(selectedIds), [selectedIds]);
  const toggle = (id: string) => {
    const next = new Set(sel);
    if (next.has(id)) next.delete(id); else next.add(id);
    onSelectionChange(Array.from(next));
  };

  const allOn = sources.length > 0 && sel.size === sources.length;
  const toggleAll = () => onSelectionChange(allOn ? [] : sources.map((s) => s.id));

  const group = (g: SourceItem["group"]) =>
    sources.filter((s) => s.group === g && s.title.toLowerCase().includes(query.toLowerCase()));

  const Row: React.FC<{ item: SourceItem }> = ({ item }) => {
    const on = sel.has(item.id);
    const lit = hot.has(item.id);
    return (
      <div
        className={"src" + (on ? "" : " off") + (lit ? " lit" : "")}
        ref={(el:HTMLDivElement | null) => { 
          if (el && lit) el.scrollIntoView({ block: "nearest" }); }}
      >
        <button onClick={() => toggle(item.id)} aria-label={"Select " + item.title} className="plain">
          <Box on={on} />
        </button>
        {item.kind === "link" ? (
          <Globe size={15} className="ico" />
        ) : (
          <FileText size={15} className="ico" />
        )}
        <button className="tt" onClick={() => onEvent("OpenSource", { id: item.id })}>
          {item.title}
          {item.meta ? <div className="mm">{item.meta}</div> : null}
          {item.flagged ? (
            <span className="flag">
              <AlertTriangle size={10} /> Outside domain
            </span>
          ) : null}
        </button>
        {!item.isBuiltIn ? (
          <button
            className="iconbtn sm"
            aria-label="Remove source"
            onClick={() => onEvent("RemoveSource", { id: item.id })}
          >
            <Trash2 size={13} />
          </button>
        ) : null}
      </div>
    );
  };

  const Group: React.FC<{
    k: GroupKey;
    label: string;
    Icon: IconCmp;
    items: SourceItem[];
  }> = ({ k, label, Icon, items }) => (
    <>
      <button className="grp" onClick={() => setOpen((o) => ({ ...o, [k]: !o[k] }))}>
        {open[k] ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        <Icon size={13} /> {label}
        <span className="cnt">{items.length}</span>
      </button>
      {open[k] ? items.map((s) => <Row key={s.id} item={s} />) : null}
    </>
  );

  const mine = group("mine");
  if (collapsed) {
    return (
      <button
        className="panel panel-collapsed"
        data-t={theme}
        title="Open sources"
        onClick={() => onEvent("ExpandRequested", { panel: "sources" })}
      >
        <PanelLeft size={17} />
        <span className="ph-label">Sources</span>
        {selectedIds.length ? <span className="ph-count">{selectedIds.length}</span> : null}
      </button>
    );
  }  
  return (
    <div className="panel" data-t={theme}>
      <div className="ph" onClick={() => onEvent("CollapseRequested", { panel: "sources" })}>
        <h2>Sources</h2>
        <button
          className="iconbtn"
          title="Collapse"
          onClick={() => onEvent("CollapseRequested", { panel: "sources" })}
        >
          <PanelLeft size={17} />
        </button>
        
      </div>

      <div className="srcbtns">
        <button className="pillbtn" disabled={sources.length >= sourceLimit}
        title={sources.length >= sourceLimit ? `Source limit of ${sourceLimit} reached` : undefined}
        onClick={() => (onRequestAddDialog ? onRequestAddDialog() : setDialog("add"))}>
          <Plus size={15} /> Add
        </button>
      </div>

      <div className="searchwrap">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search sources"
        />
      </div>

      <div className="selrow">
        <button onClick={toggleAll} aria-label="Select all" className="plain">
          <Box on={allOn} />
        </button>
        <span>Select all sources</span>
      </div>

      <div className="scroll">
        {isBusy ? (
          <div className="skel-wrap">
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <div className="skel" key={i} />
            ))}
          </div>
        ) : (
          <>
            <Group k="retail" label="Retail library" Icon={Store} items={group("retail")} />
            <Group k="cpg" label="CPG library" Icon={Package} items={group("cpg")} />
            <button className="grp" onClick={() => setOpen((o)=>({ ...o, mine: !o.mine }))}>
              {open.mine ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              <Upload size={13} /> My sources
              <span className="cnt">{mine.length}</span>
            </button>
            {open.mine ? (
              mine.length === 0 ? (
                <div className="empty">
                  Add planograms, JBP decks or scan-data extracts to ground answers in your own business.
                </div>
              ) : (
                mine.map((s) => <Row key={s.id} item={s} />)
              )
            ) : null}
          </>
        )}
      </div>

      {guardrail.active ? (
        <div className="guard">
          <span className="dot" />
          <ShieldCheck size={15} className="gi" />
          <div>
            <div className="gt">Domain guardrail active</div>
            <div className="gs">
              {guardrail.domain} only. Questions and uploads outside the domain are blocked or flagged.
              {typeof guardrail.blockedToday === "number"
                ? ` ${guardrail.blockedToday} blocked today.`
                : ""}
            </div>
          </div>
        </div>
      ) : null}

      {dialog === "add" && !onRequestAddDialog ? (
        <AddDialog
          count={sources.length}
          limit={sourceLimit}
          maxInlineFileBytes={maxInlineFileBytes}
          onClose={() => setDialog("none")}
          onEvent={onEvent}
        />
      ) : null}

    </div>
  );
};



/* ——— add dialog ————————————————————————————— */

export const AddDialog: React.FC<{
  count: number;
  limit: number;
  maxInlineFileBytes: number;
  onClose: () => void;
  onEvent: (name: string, payload?: unknown) => void;
}> = ({ count, limit, maxInlineFileBytes, onClose, onEvent }) => {
  const [mode, setMode] = React.useState<"home" | "link" | "text">("home");
  const [url, setUrl] = React.useState("");
  const [title, setTitle] = React.useState("");
  const [body, setBody] = React.useState("");
  const [hot, setHot] = React.useState(false);
  
  const [fileError, setFileError] = React.useState<string | null>(null);
  const fileRef = React.useRef<HTMLInputElement>(null);

  const readFile = (f: File) =>
    new Promise<string | null>((resolve) => {
      if (f.size > maxInlineFileBytes) { resolve(null); return; }
      const r = new FileReader();
      r.onload = () => resolve(String(r.result).split(",")[1] ?? null);
      r.onerror = () => resolve(null);
      r.readAsDataURL(f);
    });

  // replace takeFiles
  const takeFiles = async (list: FileList | null) => {
      if (!list || list.length === 0) return;
      const mb = (maxInlineFileBytes / 1024 / 1024).toFixed(0);
      const oversized = Array.from(list).filter(f => f.size > maxInlineFileBytes);
      if (oversized.length > 0) {
          setFileError(`${oversized.map(f => f.name).join(", ")} exceed${oversized.length === 1 ? "s" : ""} the ${mb} MB limit and cannot be uploaded.`);
          return;
      }
      setFileError(null);
      const files = await Promise.all(
          Array.from(list).map(async (f) => ({
              name: f.name, size: f.size, mimeType: f.type,
              contentBase64: await readFile(f),
              tooLarge: false,
          })),
      );
      onEvent("AddFileRequested", { files });
      onClose();
  };

  return (
    <div className="scrim" onClick={onClose}>
      <div className="dlg wide" onClick={(e) => e.stopPropagation()}>
        <div className="dlg-top">
          <div>
            <h3>Add sources</h3>
            <p className="dsub">Sources ground every answer, quiz and learning path in this notebook.</p>
          </div>
          <button className="iconbtn" onClick={onClose} aria-label="Close">
            <X size={18} />
          </button>
        </div>

        <div className="dlg-scroll">
          {mode === "home" ? (
            <>
              <div
                className={"drop" + (hot ? " hot" : "")}
                onDragOver={(e) => { e.preventDefault(); setHot(true); }}
                onDragLeave={() => setHot(false)}
                onDrop={(e) => { e.preventDefault(); setHot(false); void takeFiles(e.dataTransfer.files); }}
              >

                <Upload size={26} className="di" />
                <div className="dt">Drop files here, or choose from your device</div>
                <div className="dd">PDF, .docx, .txt, .md, .csv · up to {limit} sources per notebook</div>
                <button className="pillbtn fill mt14" onClick={() => fileRef.current?.click()}>
                  Choose files
                </button>
                <input ref={fileRef} type="file" multiple className="hidden" onChange={(e) => void takeFiles(e.target.files)} />
              </div>
                {fileError ? (
                    <div className="warn err mt10">
                        <span className="werr">{fileError}</span>
                    </div>
                ) : null}
              <div className="optrow">
                <button className="optcard" onClick={() => setMode("link")}>
                  <Link2 size={17} className="oi" />
                  <div className="ot">Website</div>
                  <div className="os">Article or report URL</div>
                </button>
                <button className="optcard" onClick={() => setMode("text")}>
                  <ClipboardPaste size={17} className="oi" />
                  <div className="ot">Paste text</div>
                  <div className="os">Notes, minutes, extracts</div>
                </button>
                {/* <button className="optcard" onClick={() => onEvent("AddFromDriveRequested")}>
                  <Globe size={17} className="oi" />
                  <div className="ot">SharePoint</div>
                  <div className="os">Documents and decks</div>
                </button> */}
              </div>

              <div className="warn">
                <ShieldCheck size={15} className="wok" />
                <span>
                  Uploads are checked against the retail and CPG domain. Anything outside it is added but flagged and left unselected, so it never grounds an answer.
                </span>
              </div>
            </>
          ) : null}

          {mode === "link" ? (
            <>
              <div className="fld">
                <label>URL</label>
                <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://nielseniq.com" />
              </div>
              <div className="fld">
                <label>Title shown in the source list</label>
                <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Trade promotion effectiveness benchmark" />
              </div>
            </>
          ) : null}

          {mode === "text" ? (
            <>
              <div className="fld">
                <label>Title</label>
                <input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Q3 category review notes" />
              </div>
              <div className="fld">
                <label>Text</label>
                <textarea rows={7} value={body} onChange={(e) => setBody(e.target.value)} placeholder="Paste meeting notes, an extract from a JBP deck, or a scan-data summary." />
              </div>
            </>
          ) : null}
        </div>

        <div className="dlg-act">
          <span className="text-sm text-gray-500">{count} of {limit} sources</span>
          <div className="row8">
            {mode !== "home" ? (
              <button className="pillbtn" onClick={() => setMode("home")}>Back</button>
            ) : null}
            {mode === "link" ? (
              <button
                className="pillbtn fill"
                disabled={!url.trim()}
                onClick={() => { onEvent("AddLinkRequested", { url: url.trim(), title: title.trim() }); onClose(); }}
              >
                Add source
              </button>
            ) : null}
            {mode === "text" ? (
              <button
                className="pillbtn fill"
                disabled={!body.trim() || !title.trim()}
                onClick={() => { onEvent("AddTextRequested", { title: title.trim(), text: body.trim() }); onClose(); }}
              >
                Add source
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};
