# ShelfObservability

Admin dashboard: tiles, a questions-and-issues chart, usage by user, three small charts, and an activity log.
Filters: **start date, end date, users** (plus Today / 7 days / 30 days presets).

## 1. Switch it on
1. `python build-css.py`
2. Rename `ControlManifest.Input.xml.off` to `.xml`, point `pcfconfig.json` at it, build.
3. Add it to the Observability screen (the Home menu already emits `OpenObservability`).

## 2. What it captures (from the controls as they are)

| Tile / chart | Source event | Needs |
|---|---|---|
| Questions, Active users | `AskQuestion` (any event for users) | nothing new |
| Response (median, p95) | `AnswerReceived.latencyMs` | **new**, emitted by ChatPanel |
| Grounded | `AnswerReceived.citations` | **new** |
| Guardrail (blocked %) | `AnswerReceived.status = blocked` | **new** |
| Errors | `AnswerReceived.status = error`, `OutputFailed` | host logs these two (see 4) |
| Citations | `CitationClicked.resolvedLocally` true / false | **new flag** in ChatPanel |
| Helpful | `Feedback.vote` | nothing new |
| Feature usage | `GenerateRequested`, `CreatePathRequested`, `QuizCompleted`, `Add*Requested`, `CopyAnswer`, `SaveToNote`, `ExportRequested`, `DownloadSource` | nothing new |

Not capturable from the controls today: token counts, cost, model name, server-side failures.

## 3. Log every control event (host side)
Each control raises one event at a time (`EventName` / `EventPayload` / `EventId`). On `OnChange`, write one row.
Table columns (rename to yours): `at`, `userId`, `userName`, `panel`, `name`, `payload`.

```
// Workspace.OnChange
Collect(Telemetry, {
  at: Text(DateAdd(Now(), TimeZoneOffset(), TimeUnit.Minutes), "yyyy-mm-dd\Thh:mm:ss\Z"),
  userId: User().Email, userName: User().FullName,
  panel: Workspace.EventPanel, name: Workspace.EventName, payload: Workspace.EventPayload
})
```
Do the same for any standalone control (use its own EventName, and a fixed panel name).
Failures the controls cannot see, from your flow's error branch:
`IfError(<flow call>, <log row with name "AnswerReceived" and payload {"status":"error"}>)` and `name "OutputFailed"`.

## 4. Wire the screen

| Property | Value |
|---|---|
| `EventsJson` | `JSON(colTelemetry)` |
| `UsersJson` | your users collection (`AdminUsersJson` shape works) |
| `Theme`, `Title`, `IsLoading` | as on other screens |
| `DefaultStartDate`, `DefaultEndDate` | optional, `yyyy-mm-dd` |

```
// Observability.OnChange
Switch(Self.EventName,
  "FiltersApplied", RefreshRows,        // also fires once on start
  "RefreshRequested", RefreshRows,
  "NavigateHome", Navigate(HomeScreen),
  "ExportCompleted", Set(varNotice, {Show:true, Type:"success", Title:"Exported", Message: Text(JSON(Self.EventPayload)), Id:GUID()}))
```
`RefreshRows` = load rows for `Self.StartDate` to `Self.EndDate` (and `Self.UserIds`) into `colTelemetry`.
Dates are `yyyy-mm-dd`, inclusive, in the viewer's local time. The control filters again on its own, so a superset is fine.
Keep the row count under about 5,000 per load.

## 5. Known limits
- A control keeps only the last event raised in a tick. `QuizAnswered` for the final question is lost to `QuizCompleted`, which is why the dashboard uses `QuizCompleted` only.
- Ranges are capped at 90 days.
- The sample files in `sample/` can be pasted into a collection to test the screen before real logging exists.
