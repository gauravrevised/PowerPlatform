import { TelemetryRow, ObsUser } from "../shared/types";

/* ── filters & dates ─────────────────────────────────────────── */

export type Preset = "today" | "7d" | "30d" | "custom";
export interface Filters { start: string; end: string; userIds: string[]; }

export const MAX_RANGE_DAYS = 90;
const DAY = 86400000;
const HOUR = 3600000;
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const pad = (n: number) => String(n).padStart(2, "0");

export function toDateStr(d: Date): string {
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
export function parseDateStr(s: string | null | undefined): Date | null {
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(s ?? "");
    if (!m) return null;
    const d = new Date(+m[1], +m[2] - 1, +m[3]);
    return isNaN(d.getTime()) ? null : d;
}
export const startMs = (s: string): number => parseDateStr(s)?.getTime() ?? NaN;
export const endMs = (s: string): number => {
    const d = parseDateStr(s);
    return d ? new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime() - 1 : NaN;
};
export const daysInRange = (a: string, b: string): number =>
    Math.round((endMs(b) + 1 - startMs(a)) / DAY);

export function presetRange(p: Exclude<Preset, "custom">, now = new Date()): { start: string; end: string } {
    const end = toDateStr(now);
    const back = p === "today" ? 0 : p === "7d" ? 6 : 29;
    return { start: toDateStr(new Date(now.getFullYear(), now.getMonth(), now.getDate() - back)), end };
}
export function detectPreset(start: string, end: string, now = new Date()): Preset {
    for (const p of ["today", "7d", "30d"] as const) {
        const r = presetRange(p, now);
        if (r.start === start && r.end === end) return p;
    }
    return "custom";
}
export function validateRange(start: string, end: string): string | null {
    if (!parseDateStr(start) || !parseDateStr(end)) return "Pick a start and end date.";
    if (startMs(start) > startMs(end)) return "End date must be on or after the start date.";
    if (daysInRange(start, end) > MAX_RANGE_DAYS) return `Pick a range of ${MAX_RANGE_DAYS} days or less.`;
    return null;
}

/* ── normalised rows ─────────────────────────────────────────── */

export interface Row {
    t: number;
    userId: string;
    userName: string;
    panel: string;
    name: string;
    key: string;                       // lower-cased name, for matching
    p: Record<string, unknown>;        // parsed payload
    raw: TelemetryRow;
}

export function normalise(rows: TelemetryRow[]): Row[] {
    const out: Row[] = [];
    for (const r of rows) {
        const t = Date.parse(r?.at);
        if (!r || !r.name || isNaN(t)) continue;
        let p: unknown = r.payload;
        if (typeof p === "string") { try { p = JSON.parse(p); } catch { p = {}; } }
        if (!p || typeof p !== "object") p = {};
        out.push({
            t, userId: String(r.userId ?? ""), userName: r.userName ?? "", panel: r.panel ?? "",
            name: r.name, key: r.name.toLowerCase(), p: p as Record<string, unknown>, raw: r,
        });
    }
    return out.sort((a, b) => b.t - a.t);
}

export function filterRows(rows: Row[], f: Filters): Row[] {
    const a = startMs(f.start), b = endMs(f.end);
    const ids = f.userIds.length ? new Set(f.userIds) : null;
    return rows.filter((r) => r.t >= a && r.t <= b && (!ids || ids.has(r.userId)));
}

/* ── ratings (the colour-coded gauge tiles) ──────────────────── */

export type Rating = "good" | "fair" | "poor" | "none";
export interface GaugeCfg { good: number; poor: number; higherIsBetter: boolean; max: number; }

export const GAUGES = {
    latency:   { good: 5000, poor: 10000, higherIsBetter: false, max: 15000 } as GaugeCfg,
    grounded:  { good: 85,   poor: 70,    higherIsBetter: true,  max: 100 }   as GaugeCfg,
    citations: { good: 95,   poor: 85,    higherIsBetter: true,  max: 100 }   as GaugeCfg,
    helpful:   { good: 80,   poor: 60,    higherIsBetter: true,  max: 100 }   as GaugeCfg,
    blocked:   { good: 5,    poor: 15,    higherIsBetter: false, max: 30 }    as GaugeCfg,
};

export function rate(v: number | null, c: GaugeCfg): Rating {
    if (v === null || isNaN(v)) return "none";
    if (c.higherIsBetter) return v >= c.good ? "good" : v >= c.poor ? "fair" : "poor";
    return v <= c.good ? "good" : v <= c.poor ? "fair" : "poor";
}
const RANK: Record<Rating, number> = { none: -1, good: 0, fair: 1, poor: 2 };
export const worst = (rs: Rating[]): Rating => rs.reduce((a, b) => (RANK[b] > RANK[a] ? b : a), "none" as Rating);

export function percentile(a: number[], p: number): number | null {
    if (!a.length) return null;
    const s = [...a].sort((x, y) => x - y);
    return s[Math.min(s.length - 1, Math.max(0, Math.ceil((p / 100) * s.length) - 1))];
}
const ratio = (ok: number, n: number): number | null => (n > 0 ? (ok / n) * 100 : null);

/* ── aggregation ─────────────────────────────────────────────── */

export interface Bucket {
    t: number; label: string;
    q: number; answered: number; low: number; blocked: number; ansErr: number; errors: number;
    lat: number[]; p50: number | null; p95: number | null;
    gOk: number; gN: number; groundedPct: number | null;
    activeUsers: number;
}
export interface ToolRow { tool: string; requested: number; failed: number; }
export interface UserStat {
    userId: string; name: string;
    events: number; q: number; spark: number[];
    p50: number | null; groundedPct: number | null; helpfulPct: number | null;
    blocked: number; errors: number; worst: Rating;
}
export interface FeatureRow { key: string; label: string; count: number; hint?: string; names: string[]; }

export interface Metrics {
    hourly: boolean;
    questions: number; activeUsers: number; errors: number; answers: number;
    p50: number | null; p95: number | null;
    groundedPct: number | null; citationsPct: number | null; helpfulPct: number | null; blockedPct: number | null;
    buckets: Bucket[]; users: UserStat[]; features: FeatureRow[]; tools: ToolRow[];
}

const FEATURES: { key: string; label: string; names: string[] }[] = [
    { key: "ask",      label: "Questions asked",          names: ["askquestion"] },
    { key: "studio",   label: "Studio outputs requested", names: ["generaterequested", "createpathrequested"] },
    { key: "quiz",     label: "Quizzes completed",        names: ["quizcompleted"] },
    { key: "sources",  label: "Sources added",            names: ["addfilerequested", "addlinkrequested", "addtextrequested", "addfromdriverequested"] },
    { key: "cites",    label: "Citations opened",         names: ["citationclicked"] },
    { key: "reuse",    label: "Answers copied or saved",  names: ["copyanswer", "savetonote"] },
    { key: "exports",  label: "Exports and downloads",    names: ["exportrequested", "downloadsource"] },
];

function buildBuckets(f: Filters): { list: Bucket[]; hourly: boolean; index: (t: number) => number } {
    const a = startMs(f.start);
    const hourly = daysInRange(f.start, f.end) <= 2;
    const list: Bucket[] = [];
    const blank = (t: number, label: string): Bucket => ({
        t, label, q: 0, answered: 0, low: 0, blocked: 0, ansErr: 0, errors: 0,
        lat: [], p50: null, p95: null, gOk: 0, gN: 0, groundedPct: null, activeUsers: 0,
    });
    if (hourly) {
        const b = endMs(f.end);
        for (let t = a; t <= b; t += HOUR) {
            const d = new Date(t);
            list.push(blank(t, d.getHours() === 0 || t === a ? `${d.getDate()} ${MONTHS[d.getMonth()]}` : `${pad(d.getHours())}:00`));
        }
        return { list, hourly, index: (t) => Math.floor((t - a) / HOUR) };
    }
    const d0 = parseDateStr(f.start)!;
    const n = daysInRange(f.start, f.end);
    for (let i = 0; i < n; i++) {
        const d = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() + i);
        list.push(blank(d.getTime(), `${d.getDate()} ${MONTHS[d.getMonth()]}`));
    }
    return {
        list, hourly,
        index: (t) => {
            const d = new Date(t);
            return Math.round((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - a) / DAY);
        },
    };
}

export function computeMetrics(rows: Row[], f: Filters): Metrics {
    const { list: buckets, hourly, index } = buildBuckets(f);
    const users = new Map<string, UserStat & { lat: number[]; gOk: number; gN: number; up: number; down: number }>();
    const getUser = (r: Row) => {
        let u = users.get(r.userId);
        if (!u) {
            u = {
                userId: r.userId, name: r.userName || r.userId || "Unknown", events: 0, q: 0,
                spark: buckets.map(() => 0), p50: null, groundedPct: null, helpfulPct: null,
                blocked: 0, errors: 0, worst: "none", lat: [], gOk: 0, gN: 0, up: 0, down: 0,
            };
            users.set(r.userId, u);
        }
        if (r.userName && u.name === u.userId) u.name = r.userName;
        return u;
    };

    const bucketUsers = buckets.map(() => new Set<string>());
    const toolMap = new Map<string, ToolRow>();
    const toolRow = (name: string): ToolRow => {
        let t = toolMap.get(name);
        if (!t) { t = { tool: name, requested: 0, failed: 0 }; toolMap.set(name, t); }
        return t;
    };
    const toolName = (r: Row): string => String(r.p.toolName ?? r.p.tool ?? "unknown").toLowerCase();
    const counts: Record<string, number> = {};
    const lat: number[] = [];
    let questions = 0, answers = 0, errors = 0, blocked = 0, gOk = 0, gN = 0;
    let up = 0, down = 0, citeOk = 0, citeBad = 0, quizN = 0, quizPass = 0, quizScore = 0;
    let failedOutputs = 0;
    const origin: Record<string, number> = {};

    for (const r of rows) {
        counts[r.key] = (counts[r.key] ?? 0) + 1;
        const u = getUser(r);
        u.events++;
        const bi = index(r.t);
        const b = buckets[bi];
        if (b) bucketUsers[bi].add(r.userId);

        switch (r.key) {
            case "askquestion": {
                questions++; u.q++;
                if (b) { b.q++; u.spark[bi]++; }
                const o = String(r.p.origin ?? "typed"); origin[o] = (origin[o] ?? 0) + 1;
                break;
            }
            case "answerreceived": {
                answers++;
                const status = String(r.p.status ?? "ok").toLowerCase();
                const cites = Number(r.p.citations) || 0;
                const ms = Number(r.p.latencyMs);
                if (status === "blocked") { blocked++; u.blocked++; if (b) b.blocked++; }
                else if (status === "error") { errors++; u.errors++; if (b) { b.ansErr++; b.errors++; } }
                else {
                    if (status === "low" && b) b.low++;
                    gN++; u.gN++; if (b) b.gN++;
                    if (cites > 0) { gOk++; u.gOk++; if (b) b.gOk++; }
                }
                if (status !== "error" && status !== "blocked" && isFinite(ms) && ms > 0) { lat.push(ms); u.lat.push(ms); if (b) b.lat.push(ms); }
                break;
            }
            case "outputfailed": {
                errors++; failedOutputs++; u.errors++; if (b) b.errors++;
                toolRow(toolName(r)).failed++;
                break;
            }
            case "generaterequested": toolRow(toolName(r)).requested++; break;
            case "createpathrequested": toolRow("path").requested++; break;
            case "feedback": {
                if (r.p.vote === "up") { up++; u.up++; } else if (r.p.vote === "down") { down++; u.down++; }
                break;
            }
            case "citationclicked":
                // Workspace flags every click: true = opened the matching source, false = not found.
                // Clicks from a host that resolves citations itself carry no flag and are left out.
                if (r.p.resolvedLocally === true) citeOk++;
                else if (r.p.resolvedLocally === false) citeBad++;
                break;
            case "citationunresolved": citeBad++; break;
            case "quizcompleted": {
                quizN++; if (r.p.passed === true) quizPass++;
                if (isFinite(Number(r.p.score))) quizScore += Number(r.p.score);
                break;
            }
        }
    }

    buckets.forEach((b, i) => { b.activeUsers = bucketUsers[i].size; });
    for (const b of buckets) {
        b.answered = Math.max(0, b.q - b.low - b.blocked - b.ansErr);
        b.p50 = percentile(b.lat, 50);
        b.p95 = percentile(b.lat, 95);
        b.groundedPct = ratio(b.gOk, b.gN);
    }

    const userList: UserStat[] = [...users.values()].map((u) => {
        u.p50 = percentile(u.lat, 50);
        u.groundedPct = ratio(u.gOk, u.gN);
        u.helpfulPct = ratio(u.up, u.up + u.down);
        u.worst = worst([rate(u.p50, GAUGES.latency), rate(u.groundedPct, GAUGES.grounded), rate(u.helpfulPct, GAUGES.helpful)]);
        return u;
    }).sort((a, b) => b.q - a.q || b.events - a.events || a.name.localeCompare(b.name));

    const features: FeatureRow[] = FEATURES.map((d) => {
        const count = d.names.reduce((n, k) => n + (counts[k] ?? 0), 0);
        let hint: string | undefined;
        if (d.key === "ask" && count) {
            hint = ["typed", "suggested", "followup"].filter((k) => origin[k]).map((k) => `${origin[k]} ${k === "followup" ? "follow-up" : k}`).join(" · ");
        } else if (d.key === "studio" && failedOutputs) hint = `${failedOutputs} failed`;
        else if (d.key === "quiz" && quizN) hint = `${Math.round((quizPass / quizN) * 100)}% passed · avg score ${Math.round(quizScore / quizN)}%`;
        else if (d.key === "cites" && citeBad) hint = `${citeBad} unresolved`;
        return { key: d.key, label: d.label, count, hint, names: d.names };
    });

    const tools = [...toolMap.values()]
        .map((t) => ({ ...t, requested: Math.max(t.requested, t.failed) }))
        .sort((a, b) => b.requested - a.requested || a.tool.localeCompare(b.tool));

    return {
        hourly, questions, answers, errors,
        activeUsers: users.size,
        p50: percentile(lat, 50), p95: percentile(lat, 95),
        groundedPct: ratio(gOk, gN),
        citationsPct: ratio(citeOk, citeOk + citeBad),
        helpfulPct: ratio(up, up + down),
        blockedPct: ratio(blocked, answers),
        buckets, users: userList, features, tools,
    };
}

/* ── users for the picker ────────────────────────────────────── */

export function mergeUsers(listed: ObsUser[], rows: Row[]): ObsUser[] {
    const map = new Map<string, ObsUser>();
    for (const u of listed) if (u?.userId) map.set(u.userId, u);
    for (const r of rows) {
        if (r.userId && !map.has(r.userId)) map.set(r.userId, { userId: r.userId, name: r.userName || undefined });
    }
    return [...map.values()].sort((a, b) => (a.name || a.email || a.userId).localeCompare(b.name || b.email || b.userId));
}
export const userLabel = (u: ObsUser): string => u.name || u.email || u.userId;

/* ── formatting ──────────────────────────────────────────────── */

export const fmtMs = (v: number | null): string =>
    v === null ? "–" : v < 1000 ? `${Math.round(v)} ms` : `${(v / 1000).toFixed(v < 10000 ? 1 : 0)} s`;
export const fmtPct = (v: number | null): string => (v === null ? "–" : `${Math.round(v)}%`);
export function fmtDateTime(t: number): string {
    const d = new Date(t);
    return `${d.getDate()} ${MONTHS[d.getMonth()]}, ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
}
export function fmtRangeLabel(f: Filters): string {
    const a = parseDateStr(f.start), b = parseDateStr(f.end);
    if (!a || !b) return "";
    const s = (d: Date, y: boolean) => `${d.getDate()} ${MONTHS[d.getMonth()]}${y ? " " + d.getFullYear() : ""}`;
    return f.start === f.end ? s(a, true) : `${s(a, a.getFullYear() !== b.getFullYear())} – ${s(b, true)}`;
}

const clip = (s: string, n = 90) => (s.length > n ? s.slice(0, n - 1) + "…" : s);
export function summarise(r: Row): string {
    const p = r.p;
    switch (r.key) {
        case "askquestion":        return clip(String(p.text ?? ""));
        case "answerreceived":     return `${p.status ?? "ok"} · ${fmtMs(Number(p.latencyMs) || null)} · ${Number(p.citations) || 0} ${Number(p.citations) === 1 ? "source" : "sources"}`;
        case "feedback":           return String(p.vote ?? "");
        case "quizcompleted":      return `${p.score ?? "?"}% · ${p.passed ? "passed" : "not passed"}`;
        case "generaterequested":  return String(p.toolName ?? p.tool ?? "");
        case "citationclicked":
        case "citationunresolved": return String(p.fileName ?? p.sourceId ?? "");
        default: {
            const s = Object.keys(p).length ? JSON.stringify(p) : "";
            return clip(s);
        }
    }
}

export function toCsv(rows: Row[]): string {
    const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
    const head = ["at", "userId", "userName", "panel", "name", "payload"].join(",");
    const lines = rows.map((r) => [
        new Date(r.t).toISOString(), r.userId, r.userName, r.panel, r.name,
        Object.keys(r.p).length ? JSON.stringify(r.p) : "",
    ].map(esc).join(","));
    return [head, ...lines].join("\r\n");
}

/** Round the chart ceiling up to a readable tick step (1, 2, 2.5, 5 x 10^n). */
export function niceScale(max: number, ticks = 4, whole = false): { max: number; step: number } {
    if (max <= 0) return { max: ticks, step: 1 };
    const raw = max / ticks;
    const pow = Math.pow(10, Math.floor(Math.log10(raw)));
    const mult = whole ? [1, 2, 3, 4, 5, 10] : [1, 2, 2.5, 5, 10];
    let step = mult.map((m) => m * pow).find((x) => x >= raw) ?? 10 * pow;
    if (whole) step = Math.max(1, Math.ceil(step));
    return { max: step * ticks, step };
}
