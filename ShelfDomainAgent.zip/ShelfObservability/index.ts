import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { ObservabilityPanel } from "./ObservabilityPanel";
import { Filters } from "./metrics";
import { ThemeName, TelemetryRow, ObsUser, newId, parseJson } from "../shared/types";

export class ShelfObservability
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;

    private startDate = "";
    private endDate = "";
    private userIds = "";
    private eventName = "";
    private eventPayload = "";
    private eventId = "";

    // parse each JSON input only when its text changes
    private rawEvents: string | null | undefined = undefined;
    private rows: TelemetryRow[] = [];
    private rawUsers: string | null | undefined = undefined;
    private users: ObsUser[] = [];

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);
        this.host = document.createElement("div");
        this.host.className = "shelf shelf-obs";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;
        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        this.host.style.height = h > 0 ? `${h}px` : "100%";
        this.host.style.width  = w > 0 ? `${w}px` : "100%";

        const ev = p.EventsJson?.raw;
        if (ev !== this.rawEvents) {
            this.rawEvents = ev;
            const parsed = parseJson<TelemetryRow[]>(ev, []);
            this.rows = Array.isArray(parsed) ? parsed : [];
        }
        const us = p.UsersJson?.raw;
        if (us !== this.rawUsers) {
            this.rawUsers = us;
            const parsed = parseJson<ObsUser[]>(us, []);
            this.users = Array.isArray(parsed) ? parsed : [];
        }

        this.root.render(React.createElement(ObservabilityPanel, {
            title:        p.Title?.raw || "Observability",
            rows:         this.rows,
            users:        this.users,
            defaultStart: p.DefaultStartDate?.raw || "",
            defaultEnd:   p.DefaultEndDate?.raw || "",
            theme:        (p.Theme?.raw || "dark") as ThemeName,
            loading:      p.IsLoading?.raw === true,
            onFilters:    (f, reason) => this.filtersChanged(f, reason),
            onEvent:      (name, payload) => this.emit(name, payload),
        }));
    }

    private filtersChanged(f: Filters, reason: "init" | "apply" | "refresh"): void {
        this.startDate = f.start;
        this.endDate = f.end;
        this.userIds = f.userIds.join(",");
        this.emit(reason === "refresh" ? "RefreshRequested" : "FiltersApplied", f);
    }

    private emit(name: string, payload?: unknown): void {
        this.eventName = name;
        this.eventPayload = payload === undefined ? "" : JSON.stringify(payload);
        this.eventId = newId();
        this.notify();
    }

    public getOutputs(): IOutputs {
        return {
            StartDate: this.startDate,
            EndDate: this.endDate,
            UserIds: this.userIds,
            EventName: this.eventName,
            EventPayload: this.eventPayload,
            EventId: this.eventId,
        };
    }

    public destroy(): void { this.root.unmount(); }
}
