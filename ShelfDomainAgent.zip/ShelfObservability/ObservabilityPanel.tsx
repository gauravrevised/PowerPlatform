import * as React from "react";
import {
    ArrowLeft, RefreshCw, Download, Info, X, ChevronDown, Search, Check, RotateCcw,
} from "lucide-react";
import { ThemeName, TelemetryRow, ObsUser } from "../shared/types";
import {
    Filters, Preset, Bucket, UserStat, FeatureRow, ToolRow, GaugeCfg, GAUGES,
    normalise, filterRows, computeMetrics, mergeUsers, userLabel, rate, niceScale,
    presetRange, detectPreset, validateRange, parseDateStr, toDateStr,
    fmtMs, fmtPct, fmtDateTime, fmtRangeLabel, summarise, toCsv,
} from "./metrics";

export interface ObservabilityPanelProps {
    title: string;
    rows: TelemetryRow[];
    users: ObsUser[];
    defaultStart: string;
    defaultEnd: string;
    theme: ThemeName;
    loading: boolean;
    onFilters: (f: Filters, reason: "init" | "apply" | "refresh") => void;
    onEvent: (name: string, payload?: unknown) => void;
}

type Tab = "overview" | "activity";
type SortKey = "name" | "q" | "p50" | "grounded" | "helpful" | "blocked" | "errors";

const PAGE = 50;
const sameIds = (a: string[], b: string[]) => a.length === b.length && a.every((x) => b.includes(x));
const num = (v: number) => (Number.isInteger(v) ? String(v) : v.toFixed(1));
const RT_LABEL = { good: "Good", fair: "Fair", poor: "Poor", none: "No data" } as const;

/* ── user picker ─────────────────────────────────────────────── */

const UserPicker: React.FC<{ users: ObsUser[]; value: string[]; onChange: (v: string[]) => void }> = ({ users, value, onChange }) => {
    const [open, setOpen] = React.useState(false);
    const [q, setQ] = React.useState("");
    const ref = React.useRef<HTMLDivElement>(null);

    React.useEffect(() => {
        if (!open) return;
        const down = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
        const key = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
        document.addEventListener("mousedown", down);
        document.addEventListener("keydown", key);
        return () => { document.removeEventListener("mousedown", down); document.removeEventListener("keydown", key); };
    }, [open]);

    const sel = new Set(value);
    const needle = q.trim().toLowerCase();
    const list = users.filter((u) => !needle || `${userLabel(u)} ${u.email ?? ""} ${u.roleName ?? ""}`.toLowerCase().includes(needle));
    const toggle = (id: string) => onChange(sel.has(id) ? value.filter((x) => x !== id) : [...value, id]);
    const nameOf = (id: string) => { const u = users.find((x) => x.userId === id); return u ? userLabel(u) : id; };

    return (
        <div className="ob-picker" ref={ref}>
            <button type="button" className="ob-user" aria-haspopup="listbox" aria-expanded={open} onClick={() => setOpen(!open)}>
                {value.length === 0 ? <span className="ob-user-all">All users</span> : (
                    <>
                        {value.slice(0, 2).map((id) => <span className="ob-chip" key={id}>{nameOf(id)}</span>)}
                        {value.length > 2 ? <span className="ob-chip">+{value.length - 2}</span> : null}
                    </>
                )}
                <ChevronDown size={15} className="ob-user-caret" />
            </button>
            {open ? (
                <div className="ob-pop" role="listbox" aria-multiselectable="true">
                    <div className="ob-pop-search">
                        <Search size={14} />
                        <input autoFocus placeholder="Search name or email" value={q} onChange={(e) => setQ(e.target.value)} />
                    </div>
                    <div className="ob-pop-list">
                        <button type="button" className="ob-opt" onClick={() => onChange([])}>
                            <span className={`ob-box${value.length === 0 ? " on" : ""}`}>{value.length === 0 ? <Check size={12} /> : null}</span>
                            <span className="ob-opt-main">All users</span>
                            <span className="ob-opt-sub">{users.length}</span>
                        </button>
                        {list.map((u) => (
                            <button type="button" key={u.userId} className={`ob-opt${sel.has(u.userId) ? " sel" : ""}`}
                                    role="option" aria-selected={sel.has(u.userId)} onClick={() => toggle(u.userId)}>
                                <span className={`ob-box${sel.has(u.userId) ? " on" : ""}`}>{sel.has(u.userId) ? <Check size={12} /> : null}</span>
                                <span className="ob-opt-main">
                                    {userLabel(u)}
                                    <small>{[u.roleName, u.email && u.name ? u.email : ""].filter(Boolean).join(" · ")}</small>
                                </span>
                                {u.status === "Revoked" ? <span className="ob-tag">Revoked</span> : null}
                            </button>
                        ))}
                        {list.length === 0 ? <div className="ob-pop-empty">No matching users.</div> : null}
                    </div>
                    <div className="ob-pop-foot">
                        <span>{value.length} selected</span>
                        <span>
                            <button type="button" className="ob-link" onClick={() => onChange([])}>Clear</button>
                            <button type="button" className="ob-link strong" onClick={() => setOpen(false)}>Done</button>
                        </span>
                    </div>
                </div>
            ) : null}
        </div>
    );
};

/* ── gauge tile (TTFB / FCP style) ───────────────────────────── */

const Gauge: React.FC<{
    name: string; sub: string; tip: string; value: number | null; cfg: GaugeCfg;
    big: (v: number) => { n: string; u: string }; tick: (v: number) => string;
}> = ({ name, sub, tip, value, cfg, big, tick }) => {
    const r = rate(value, cfg);
    const pos = (v: number) => Math.max(0, Math.min(100, (v / cfg.max) * 100));
    const shown = value === null ? null : big(value);
    return (
        <div className="ob-tile" data-r={r}>
            <div className="ob-tile-hd"><b>{name}</b><span title={tip}><Info size={13} /></span></div>
            <div className="ob-tile-sub">{sub}</div>
            <div className="ob-tile-val">
                {shown ? <><strong>{shown.n}</strong><span className="ob-unit">{shown.u}</span></> : <strong className="ob-dash">–</strong>}
                <em>({RT_LABEL[r]})</em>
            </div>
            <div className="ob-gbar">
                {value !== null ? <i style={{ width: `${pos(value)}%` }} /> : null}
                {value !== null ? <s style={{ left: `${pos(value)}%` }} /> : null}
                <u style={{ left: `${pos(cfg.good)}%` }} /><u style={{ left: `${pos(cfg.poor)}%` }} />
            </div>
            <div className="ob-gticks">
                {[cfg.good, cfg.poor].sort((a, b) => a - b).map((t) => <span key={t}>{tick(t)}</span>)}
            </div>
        </div>
    );
};

/* ── charts ──────────────────────────────────────────────────── */

const Frame: React.FC<{ max: number; step: number; labels: string[]; fmt: (v: number) => string; children: React.ReactNode }> = ({ max, step, labels, fmt, children }) => {
    const ticks: number[] = [];
    for (let v = 0; v <= max + 1e-9; v += step) ticks.push(v);
    const every = Math.max(1, Math.ceil(labels.length / 8));
    return (
        <div className="ob-chart">
            <div className="ob-yaxis">{ticks.map((v) => <span key={v} style={{ bottom: `${(v / max) * 100}%` }}>{fmt(v)}</span>)}</div>
            <div className="ob-plot">
                {ticks.map((v) => <i className="ob-grid" key={v} style={{ bottom: `${(v / max) * 100}%` }} />)}
                {children}
            </div>
            <div className="ob-xaxis">{labels.map((l, i) => <span key={i}>{i % every === 0 ? l : ""}</span>)}</div>
        </div>
    );
};

const Empty: React.FC<{ text?: string }> = ({ text }) => <div className="ob-empty">{text ?? "No activity in this range."}</div>;

const StackedBars: React.FC<{ buckets: Bucket[] }> = ({ buckets }) => {
    const totals = buckets.map((b) => b.answered + b.low + b.blocked + b.errors);
    const peak = Math.max(0, ...totals);
    const { max, step } = niceScale(peak, 4, true);
    return (
        <Frame max={max} step={step} labels={buckets.map((b) => b.label)} fmt={num}>
            <div className="ob-cols">
                {buckets.map((b) => (
                    <div className="ob-col" key={b.t}
                         title={`${b.label}\nQuestions: ${b.q}\nAnswered: ${b.answered}\nLow confidence: ${b.low}\nBlocked: ${b.blocked}\nErrors: ${b.errors}`}>
                        <div className="ob-stack">
                            {([["ans", b.answered], ["low", b.low], ["blk", b.blocked], ["err", b.errors]] as [string, number][])
                                .filter(([, n]) => n > 0)
                                .map(([k, n]) => <div key={k} className={`ob-seg ${k}`} style={{ height: `${(n / max) * 100}%` }} />)}
                        </div>
                    </div>
                ))}
            </div>
        </Frame>
    );
};

const Bars: React.FC<{ buckets: Bucket[]; pick: (b: Bucket) => number; unit: string }> = ({ buckets, pick, unit }) => {
    const { max, step } = niceScale(Math.max(0, ...buckets.map(pick)), 4, true);
    return (
        <Frame max={max} step={step} labels={buckets.map((b) => b.label)} fmt={num}>
            <div className="ob-cols">
                {buckets.map((b) => (
                    <div className="ob-col" key={b.t} title={`${b.label}\n${pick(b)} ${unit}`}>
                        <div className="ob-stack">
                            {pick(b) > 0 ? <div className="ob-seg ans" style={{ height: `${(pick(b) / max) * 100}%` }} /> : null}
                        </div>
                    </div>
                ))}
            </div>
        </Frame>
    );
};

const ToolChart: React.FC<{ rows: ToolRow[] }> = ({ rows }) => {
    const { max, step } = niceScale(Math.max(0, ...rows.map((r) => r.requested)), 4, true);
    const cap = (t: string) => t.charAt(0).toUpperCase() + t.slice(1);
    return (
        <Frame max={max} step={step} labels={rows.map((r) => cap(r.tool))} fmt={num}>
            <div className="ob-cols">
                {rows.map((r) => (
                    <div className="ob-col" key={r.tool}
                         title={`${cap(r.tool)}\nRequested: ${r.requested}\nFailed: ${r.failed}`}>
                        <div className="ob-stack">
                            {r.requested - r.failed > 0 ? <div className="ob-seg ans" style={{ height: `${((r.requested - r.failed) / max) * 100}%` }} /> : null}
                            {r.failed > 0 ? <div className="ob-seg err" style={{ height: `${(r.failed / max) * 100}%` }} /> : null}
                        </div>
                        <span className="ob-val" style={{ bottom: `${(r.requested / max) * 100}%` }}>{r.requested}</span>
                    </div>
                ))}
            </div>
        </Frame>
    );
};

const Spark: React.FC<{ values: number[] }> = ({ values }) => {
    const peak = Math.max(1, ...values);
    const n = values.length;
    if (n < 2 || !values.some((v) => v > 0)) return <svg className="ob-spark" viewBox="0 0 100 24" preserveAspectRatio="none"><path d="M0 22L100 22" className="flat" /></svg>;
    const d = "M" + values.map((v, i) => `${((i / (n - 1)) * 100).toFixed(1)} ${(22 - (v / peak) * 20).toFixed(1)}`).join("L");
    return <svg className="ob-spark" viewBox="0 0 100 24" preserveAspectRatio="none"><path d={d} /></svg>;
};

const Legend: React.FC<{ items: [string, string][] }> = ({ items }) => (
    <div className="ob-legend">{items.map(([c, l]) => <span key={l}><i className={c} />{l}</span>)}</div>
);

const Card: React.FC<{ title: string; onExplore?: () => void; right?: React.ReactNode; children: React.ReactNode }> = ({ title, onExplore, right, children }) => (
    <section className="ob-card">
        <div className="ob-card-hd">
            <h3>{title}</h3>
            {right}
            {onExplore ? <button type="button" className="ob-explore" onClick={onExplore}>Explore</button> : null}
        </div>
        {children}
    </section>
);

const FeatureBars: React.FC<{ rows: FeatureRow[]; onExplore: (names: string[]) => void }> = ({ rows, onExplore }) => {
    const peak = Math.max(1, ...rows.map((r) => r.count));
    return (
        <div className="ob-feats">
            {rows.map((r) => (
                <button type="button" className="ob-feat" key={r.key} onClick={() => onExplore(r.names)} title="Open these events in Activity">
                    <span className="ob-feat-l">{r.label}{r.hint ? <small>{r.hint}</small> : null}</span>
                    <span className="ob-feat-bar"><i style={{ width: `${(r.count / peak) * 100}%` }} /></span>
                    <b>{r.count.toLocaleString()}</b>
                </button>
            ))}
        </div>
    );
};

/* ── panel ───────────────────────────────────────────────────── */

export const ObservabilityPanel: React.FC<ObservabilityPanelProps> = ({
    title, rows, users, defaultStart, defaultEnd, theme, loading, onFilters, onEvent,
}) => {
    const initial = React.useMemo<Filters>(() => {
        const d = presetRange("7d");
        const ok = parseDateStr(defaultStart) && parseDateStr(defaultEnd) && !validateRange(defaultStart, defaultEnd);
        return ok ? { start: defaultStart, end: defaultEnd, userIds: [] } : { ...d, userIds: [] };
    }, []);

    const [applied, setApplied] = React.useState<Filters>(initial);
    const [draft, setDraft] = React.useState<Filters>(initial);
    const [tab, setTab] = React.useState<Tab>("overview");
    const [evNames, setEvNames] = React.useState<string[]>([]);
    const [search, setSearch] = React.useState("");
    const [userSearch, setUserSearch] = React.useState("");
    const [sort, setSort] = React.useState<{ key: SortKey; dir: 1 | -1 }>({ key: "q", dir: -1 });
    const [limit, setLimit] = React.useState(PAGE);
    const [openRow, setOpenRow] = React.useState<number | null>(null);
    const startRef = React.useRef<HTMLInputElement>(null);

    React.useEffect(() => { onFilters(initial, "init"); }, []);

    const norm = React.useMemo(() => normalise(rows), [rows]);
    const filtered = React.useMemo(() => filterRows(norm, applied), [norm, applied]);
    const m = React.useMemo(() => computeMetrics(filtered, applied), [filtered, applied]);
    const pickerUsers = React.useMemo(() => mergeUsers(users, norm), [users, norm]);

    const today = toDateStr(new Date());
    const rangeErr = validateRange(draft.start, draft.end);
    const dirty = draft.start !== applied.start || draft.end !== applied.end || !sameIds(draft.userIds, applied.userIds);
    const preset: Preset = detectPreset(draft.start, draft.end);

    const commit = (f: Filters) => {
        setApplied(f); setDraft(f); setLimit(PAGE); setOpenRow(null);
        onFilters(f, "apply");
    };
    const apply = () => { if (!rangeErr && dirty) commit(draft); };
    const pickPreset = (p: Preset) => {
        if (p === "custom") { startRef.current?.focus(); return; }
        commit({ ...presetRange(p), userIds: draft.userIds });
    };
    const reset = () => commit({ ...presetRange("7d"), userIds: [] });
    const explore = (names: string[]) => { setEvNames(names); setSearch(""); setLimit(PAGE); setOpenRow(null); setTab("activity"); };

    const doExport = () => {
        try {
            const blob = new Blob(["\ufeff" + toCsv(filtered)], { type: "text/csv;charset=utf-8" });
            const url = URL.createObjectURL(blob);
            const a = document.createElement("a");
            a.href = url; a.download = `observability_${applied.start}_${applied.end}.csv`;
            document.body.appendChild(a); a.click(); a.remove();
            setTimeout(() => URL.revokeObjectURL(url), 1000);
            onEvent("ExportCompleted", { rows: filtered.length, start: applied.start, end: applied.end });
        } catch {
            onEvent("ExportFailed", { start: applied.start, end: applied.end });
        }
    };

    /* users table */
    const sortedUsers = React.useMemo(() => {
        const q = userSearch.trim().toLowerCase();
        const val = (u: UserStat): number | string | null => {
            switch (sort.key) {
                case "name": return u.name.toLowerCase();
                case "q": return u.q;
                case "p50": return u.p50;
                case "grounded": return u.groundedPct;
                case "helpful": return u.helpfulPct;
                case "blocked": return u.blocked;
                default: return u.errors;
            }
        };
        return m.users.filter((u) => !q || u.name.toLowerCase().includes(q)).sort((a, b) => {
            const x = val(a), y = val(b);
            if (x === null && y === null) return 0;
            if (x === null) return 1;
            if (y === null) return -1;
            return (x < y ? -1 : x > y ? 1 : 0) * sort.dir;
        });
    }, [m.users, userSearch, sort]);
    const th = (key: SortKey, label: string) => (
        <th className={sort.key === key ? "sorted" : ""} onClick={() => setSort({ key, dir: sort.key === key ? (sort.dir === 1 ? -1 : 1) : key === "name" ? 1 : -1 })}>
            {label}{sort.key === key ? (sort.dir === 1 ? " ↑" : " ↓") : ""}
        </th>
    );

    /* activity */
    const eventNames = React.useMemo(() => {
        const map = new Map<string, string>();
        filtered.forEach((r) => { if (!map.has(r.key)) map.set(r.key, r.name); });
        return [...map.entries()].sort((a, b) => a[1].localeCompare(b[1]));
    }, [filtered]);
    const shown = React.useMemo(() => {
        const q = search.trim().toLowerCase();
        const nm = evNames.length ? new Set(evNames) : null;
        return filtered.filter((r) => (!nm || nm.has(r.key)) &&
            (!q || `${r.userName} ${r.userId} ${r.name} ${summarise(r)}`.toLowerCase().includes(q)));
    }, [filtered, evNames, search]);

    const latBig = (v: number) => (v < 1000 ? { n: String(Math.round(v)), u: "ms" } : { n: (v / 1000).toFixed(v < 10000 ? 1 : 0), u: "s" });
    const pctBig = (v: number) => ({ n: String(Math.round(v)), u: "%" });
    const hasData = filtered.length > 0;
    const usersLabel = applied.userIds.length === 0 ? "All users" : `${applied.userIds.length} user${applied.userIds.length > 1 ? "s" : ""}`;

    return (
        <div className="shelf obs-root" data-t={theme}>
            <div className="obs">
                <header className="ob-hd">
                    <button type="button" className="iconbtn" aria-label="Back" onClick={() => onEvent("NavigateHome")}><ArrowLeft size={18} /></button>
                    <h1>{title}</h1>
                    <span className="ob-sub">{fmtRangeLabel(applied)} · {usersLabel}</span>
                    <div className="ob-hd-r">
                        <button type="button" className={`iconbtn${loading ? " spin" : ""}`} aria-label="Refresh" title="Refresh" onClick={() => onFilters(applied, "refresh")}><RefreshCw size={16} /></button>
                        <button type="button" className="iconbtn" aria-label="Export CSV" title="Export CSV" onClick={doExport}><Download size={16} /></button>
                    </div>
                </header>

                <nav className="ob-tabs">
                    <button type="button" className={tab === "overview" ? "on" : ""} onClick={() => setTab("overview")}>Overview</button>
                    <button type="button" className={tab === "activity" ? "on" : ""} onClick={() => setTab("activity")}>
                        Activity<span className="ob-count">{filtered.length.toLocaleString()}</span>
                    </button>
                </nav>

                <div className="ob-filters">
                    <div className="ob-f">
                        <label>Range</label>
                        <div className="ob-seg-pills" role="group" aria-label="Range">
                            {([["today", "Today"], ["7d", "7 days"], ["30d", "30 days"], ["custom", "Custom"]] as [Preset, string][]).map(([k, l]) => (
                                <button type="button" key={k} className={preset === k ? "on" : ""} onClick={() => pickPreset(k)}>{l}</button>
                            ))}
                        </div>
                    </div>
                    <div className="ob-f">
                        <label htmlFor="ob-start">Start date</label>
                        <input id="ob-start" ref={startRef} type="date" value={draft.start} max={today}
                               onChange={(e) => setDraft({ ...draft, start: e.target.value })} />
                    </div>
                    <div className="ob-f">
                        <label htmlFor="ob-end">End date</label>
                        <input id="ob-end" type="date" value={draft.end} max={today}
                               onChange={(e) => setDraft({ ...draft, end: e.target.value })} />
                    </div>
                    <div className="ob-f">
                        <label>Users</label>
                        <UserPicker users={pickerUsers} value={draft.userIds} onChange={(ids) => setDraft({ ...draft, userIds: ids })} />
                    </div>
                    <div className="ob-f act">
                        <button type="button" className={`pillbtn${dirty && !rangeErr ? " fill" : ""}`} disabled={!dirty || !!rangeErr} onClick={apply}>
                            <Check size={14} /> Apply
                        </button>
                        <button type="button" className="ob-link" onClick={reset} title="Last 7 days, all users"><RotateCcw size={13} /> Reset</button>
                    </div>
                    {rangeErr ? <div className="ob-err" role="alert">{rangeErr}</div> : null}
                </div>
                <div className={`ob-load${loading ? " on" : ""}`} />

                <div className="ob-body">
                    {tab === "overview" ? (
                        <>
                            <div className="ob-tiles">
                                <div className="ob-tile simple">
                                    <div className="ob-tile-hd"><b>Questions</b><span title="Questions asked (AskQuestion events)."><Info size={13} /></span></div>
                                    <div className="ob-big acc">{m.questions.toLocaleString()}</div>
                                    <div className="ob-tile-sub">{m.activeUsers} active user{m.activeUsers === 1 ? "" : "s"}</div>
                                </div>
                                <div className="ob-tile simple">
                                    <div className="ob-tile-hd"><b>Errors</b><span title="Failed answers (AnswerReceived with status error) and failed studio outputs (OutputFailed)."><Info size={13} /></span></div>
                                    <div className={`ob-big ${m.errors === 0 ? "ok" : "bad"}`}>{m.errors.toLocaleString()}</div>
                                    <div className="ob-tile-sub">answers and outputs</div>
                                </div>
                                <Gauge name="Response" sub="Median time to answer" tip="Median time from asking to the answer appearing. From AnswerReceived events; blocked and failed answers are left out."
                                       value={m.p50} cfg={GAUGES.latency} big={latBig} tick={(v) => fmtMs(v)} />
                                <Gauge name="Grounded" sub="Answers with sources" tip="Share of answers that cite at least one source. Blocked and failed answers are left out."
                                       value={m.groundedPct} cfg={GAUGES.grounded} big={pctBig} tick={(v) => `${v}%`} />
                                <Gauge name="Citations" sub="Resolved when opened" tip="Citation clicks that opened the matching source. A miss means the agent named a file that is not in the notebook."
                                       value={m.citationsPct} cfg={GAUGES.citations} big={pctBig} tick={(v) => `${v}%`} />
                                <Gauge name="Helpful" sub="Thumbs up share" tip="Thumbs up as a share of all thumbs up and down."
                                       value={m.helpfulPct} cfg={GAUGES.helpful} big={pctBig} tick={(v) => `${v}%`} />
                                <Gauge name="Guardrail" sub="Questions blocked" tip="Questions stopped by the domain guardrail, as a share of answers."
                                       value={m.blockedPct} cfg={GAUGES.blocked} big={pctBig} tick={(v) => `${v}%`} />
                            </div>

                            <Card title="Questions and issues" onExplore={() => explore(["askquestion"])}>
                                {m.questions + m.errors > 0 ? <StackedBars buckets={m.buckets} /> : <Empty />}
                                <Legend items={[["ans", "Answered"], ["low", "Low confidence"], ["blk", "Blocked"], ["err", "Errors"]]} />
                            </Card>

                            <Card title="Usage by user"
                                  right={<div className="ob-search"><Search size={13} /><input placeholder="Search..." value={userSearch} onChange={(e) => setUserSearch(e.target.value)} /></div>}>
                                {sortedUsers.length ? (
                                    <div className="ob-tablewrap">
                                        <table className="ob-table">
                                            <thead><tr>{th("name", "User")}{th("q", "Questions")}{th("p50", "Median time")}{th("grounded", "Grounded")}{th("helpful", "Helpful")}{th("blocked", "Blocked")}{th("errors", "Errors")}</tr></thead>
                                            <tbody>
                                                {sortedUsers.map((u) => (
                                                    <tr key={u.userId} className="click" data-r={u.worst} title="Filter to this user" onClick={() => commit({ ...applied, userIds: [u.userId] })}>
                                                        <td className="ob-name">{u.name}</td>
                                                        <td><span className="ob-qcell"><span>{u.q}</span><Spark values={u.spark} /></span></td>
                                                        <td className={`r-${rate(u.p50, GAUGES.latency)}`}>{fmtMs(u.p50)}</td>
                                                        <td className={`r-${rate(u.groundedPct, GAUGES.grounded)}`}>{fmtPct(u.groundedPct)}</td>
                                                        <td className={`r-${rate(u.helpfulPct, GAUGES.helpful)}`}>{fmtPct(u.helpfulPct)}</td>
                                                        <td>{u.blocked}</td>
                                                        <td className={u.errors ? "r-poor" : ""}>{u.errors}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                ) : <Empty text={hasData ? "No users match your search." : undefined} />}
                            </Card>

                            <div className="ob-trio">
                                <Card title={m.hourly ? "Active users per hour" : "Active users per day"}>
                                    {hasData ? <Bars buckets={m.buckets} pick={(b) => b.activeUsers} unit="active users" /> : <Empty />}
                                </Card>
                                <Card title="Tools used" onExplore={() => explore(["generaterequested", "createpathrequested", "outputfailed"])}>
                                    {m.tools.length ? (
                                        <>
                                            <ToolChart rows={m.tools} />
                                            <Legend items={[["ans", "Succeeded"], ["err", "Failed"]]} />
                                        </>
                                    ) : <Empty text="No tools used in this range." />}
                                </Card>
                                <Card title="Feature usage">
                                    {hasData ? <FeatureBars rows={m.features} onExplore={explore} /> : <Empty />}
                                </Card>
                            </div>
                        </>
                    ) : (
                        <Card title="Activity log" right={
                            <div className="ob-actfilters">
                                <select value={evNames.length === 0 ? "" : evNames.length === 1 ? evNames[0] : "__multi"}
                                        onChange={(e) => { setEvNames(e.target.value ? [e.target.value] : []); setLimit(PAGE); setOpenRow(null); }}>
                                    <option value="">All events</option>
                                    {evNames.length > 1 ? <option value="__multi">{evNames.length} event types</option> : null}
                                    {eventNames.map(([k, n]) => <option key={k} value={k}>{n}</option>)}
                                </select>
                                <div className="ob-search"><Search size={13} /><input placeholder="Search..." value={search} onChange={(e) => { setSearch(e.target.value); setLimit(PAGE); }} /></div>
                                {evNames.length || search ? <button type="button" className="ob-link" onClick={() => { setEvNames([]); setSearch(""); }}><X size={12} /> Clear</button> : null}
                            </div>}>
                            {shown.length ? (
                                <div className="ob-tablewrap">
                                    <table className="ob-table log">
                                        <thead><tr><th>Time</th><th>User</th><th>Panel</th><th>Event</th><th>Details</th></tr></thead>
                                        <tbody>
                                            {shown.slice(0, limit).map((r, i) => (
                                                <React.Fragment key={i}>
                                                    <tr className="click" onClick={() => setOpenRow(openRow === i ? null : i)}>
                                                        <td className="nw">{fmtDateTime(r.t)}</td>
                                                        <td>{r.userName || r.userId}</td>
                                                        <td>{r.panel}</td>
                                                        <td><span className="ob-ev">{r.name}</span></td>
                                                        <td className="ob-det">{summarise(r)}</td>
                                                    </tr>
                                                    {openRow === i ? (
                                                        <tr className="detail"><td colSpan={5}>
                                                            <pre>{JSON.stringify({ at: new Date(r.t).toISOString(), userId: r.userId, notebookId: r.raw.notebookId, payload: r.p }, null, 2)}</pre>
                                                        </td></tr>
                                                    ) : null}
                                                </React.Fragment>
                                            ))}
                                        </tbody>
                                    </table>
                                </div>
                            ) : <Empty text={hasData ? "No events match these filters." : undefined} />}
                            {shown.length > limit ? (
                                <div className="ob-more">
                                    <span>Showing {limit.toLocaleString()} of {shown.length.toLocaleString()}</span>
                                    <button type="button" className="pillbtn" onClick={() => setLimit(limit + PAGE)}>Load more</button>
                                </div>
                            ) : null}
                        </Card>
                    )}
                </div>
            </div>
        </div>
    );
};
