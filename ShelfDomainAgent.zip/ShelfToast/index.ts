import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { ToastPanel } from "./ToastPanel";
import { ThemeName, newId } from "../shared/types";

export class ShelfToast
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;
    private eventName = "";
    private eventId   = "";

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);
        this.host = document.createElement("div");
        this.host.className = "shelf shelf-toast";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;
        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        this.host.style.height = h > 0 ? `${h}px` : "100%";
        this.host.style.width  = w > 0 ? `${w}px` : "100%";

        this.root.render(React.createElement(ToastPanel, {
            visible:     p.Visible?.raw === true,
            type:        (p.Type?.raw || "info") as "error" | "success" | "warning" | "info",
            title:       p.Title?.raw || "Something went wrong",
            description: p.Description?.raw || "",
            theme:       (p.Theme?.raw || "dark") as ThemeName,
            popupX:      p.PopupX?.raw ?? null,
            popupY:      p.PopupY?.raw ?? null,
            popupWidth:  p.PopupWidth?.raw ?? 400,
            popupHeight: p.PopupHeight?.raw ?? 0,
            onOk: () => {
                this.eventName = "OkClicked";
                this.eventId   = newId();
                this.notify();
            },
        }));
            }

    public getOutputs(): IOutputs {
        return { EventName: this.eventName, EventId: this.eventId };
    }

    public destroy(): void { this.root.unmount(); }
}