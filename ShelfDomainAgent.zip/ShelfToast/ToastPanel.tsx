import * as React from "react";
import { CheckCircle2, XCircle, AlertTriangle, Info, X } from "lucide-react";
import { ThemeName } from "../shared/types";

export interface ToastPanelProps {
    visible:     boolean;
    type:        "error" | "success" | "warning" | "info";
    title:       string;
    description: string;
    theme:       ThemeName;
    popupX:      number | null;
    popupY:      number | null;
    popupWidth:  number;
    popupHeight: number;
    onOk:        () => void;
}

const ICONS = {
    success: CheckCircle2,
    error:   XCircle,
    warning: AlertTriangle,
    info:    Info,
} as const;

export const ToastPanel: React.FC<ToastPanelProps> = ({
    visible, type, title, description, theme,
    popupX, popupY, popupWidth, popupHeight, onOk,
}) => {
    if (!visible) return null;

    const Icon = ICONS[type] ?? Info;

    const cardStyle: React.CSSProperties = {
        width:  popupWidth  > 0 ? popupWidth  : 400,
        height: popupHeight > 0 ? popupHeight : "auto",
        ...(popupX !== null ? { position: "absolute", left: popupX, top: popupY ?? 0 } : {}),
    };

    return (
        <div className="shelf" data-t={theme}>
            <div className="toast-scrim" onClick={onOk} />
            <div className={`toast-card toast-${type}`}
                 style={cardStyle}
                 role="alertdialog" aria-modal="true">
                <div className="toast-head">
                    <Icon className="toast-icon" size={22} />
                    <span className="toast-title">{title}</span>
                    <button className="toast-close iconbtn sm" onClick={onOk} aria-label="Close">
                        <X size={16} />
                    </button>
                </div>
                {description ? (
                    <p className="toast-desc">{description}</p>
                ) : null}
                <div className="toast-foot">
                    <button className={`pillbtn fill toast-ok`} onClick={onOk}>Ok</button>
                </div>
            </div>
        </div>
    );
};