/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    AdminSettingsSchemaJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminSettingsValuesJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminUserFormSchemaJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminUsersJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminRolesJson: ComponentFramework.PropertyTypes.StringProperty;
    UserSearchResultsJson: ComponentFramework.PropertyTypes.StringProperty;
    Theme: ComponentFramework.PropertyTypes.StringProperty;
    Command: ComponentFramework.PropertyTypes.StringProperty;
    UserProfileJson: ComponentFramework.PropertyTypes.StringProperty;
    UserName: ComponentFramework.PropertyTypes.StringProperty;
    Show: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    Type: ComponentFramework.PropertyTypes.StringProperty;
    Title: ComponentFramework.PropertyTypes.StringProperty;
    Message: ComponentFramework.PropertyTypes.StringProperty;
    Duration: ComponentFramework.PropertyTypes.WholeNumberProperty;
    NotifyId: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    EventName?: string;
    EventPayload?: string;
    EventId?: string;
}
