import * as React from "react";
import { CheckCircle2, XCircle, AlertTriangle, Info, X } from "lucide-react";
import { ThemeName } from "../shared/types";

export type BannerType = "error" | "success" | "warning" | "info";

export interface BannerPanelProps {
    show:      boolean;
    type:      BannerType;
    title:     string;
    message:   string;
    duration:  number;       // ms; 0 = sticky
    notifyId:  string;       // change to replay the same message
    theme:     ThemeName;
    onDismiss: () => void;   // fired once the exit animation has finished
}

const ICONS = {
    success: CheckCircle2,
    error:   XCircle,
    warning: AlertTriangle,
    info:    Info,
} as const;

const EXIT_MS = 180;

type Phase = "in" | "out" | "gone";

export const BannerPanel: React.FC<BannerPanelProps> = ({
    show, type, title, message, duration, notifyId, theme, onDismiss,
}) => {
    const [phase, setPhase] = React.useState<Phase>("in");
    const exitTimer = React.useRef<number | undefined>(undefined);
    const onDismissRef = React.useRef(onDismiss);
    onDismissRef.current = onDismiss;

    // A new notification (or a replay via notifyId) always starts visible.
    React.useEffect(() => {
        window.clearTimeout(exitTimer.current);
        setPhase("in");
    }, [show, notifyId, type, title, message]);

    const dismiss = React.useCallback(() => {
        setPhase("out");
        window.clearTimeout(exitTimer.current);
        exitTimer.current = window.setTimeout(() => {
            setPhase("gone");
            onDismissRef.current();
        }, EXIT_MS);
    }, []);

    // Auto-dismiss.
    React.useEffect(() => {
        if (!show || phase !== "in" || duration <= 0) return;
        const t = window.setTimeout(dismiss, duration);
        return () => window.clearTimeout(t);
    }, [show, phase, duration, notifyId, type, title, message, dismiss]);

    React.useEffect(() => () => window.clearTimeout(exitTimer.current), []);

    // Hidden once dismissed, until Power Fx resets Show or a new notification arrives.
    if (!show || phase === "gone" || (!title && !message)) return null;

    const Icon = ICONS[type] ?? Info;
    const urgent = type === "error" || type === "warning";

    return (
        <div className="shelf" data-t={theme}>
            <div className={`bnr bnr-${type}${phase === "out" ? " bnr-out" : ""}`}
                 role={urgent ? "alert" : "status"}
                 aria-live={urgent ? "assertive" : "polite"}>
                <Icon className="bnr-icon" size={18} />
                <div className="bnr-text" title={[title, message].filter(Boolean).join(" ")}>
                    {title ? <strong className="bnr-title">{title}</strong> : null}
                    {message ? <span className="bnr-msg">{message}</span> : null}
                </div>
                <button className="bnr-close iconbtn sm" type="button" onClick={dismiss} aria-label="Dismiss">
                    <X size={16} />
                </button>
            </div>
        </div>
    );
};
