import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { BannerPanel, BannerType } from "./BannerPanel";
import { ThemeName, newId } from "../shared/types";

export class ShelfBanner
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;
    private eventName = "";
    private eventId   = "";

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);
        this.host = document.createElement("div");
        this.host.className = "shelf shelf-banner";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;
        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        this.host.style.height = h > 0 ? `${h}px` : "100%";
        this.host.style.width  = w > 0 ? `${w}px` : "100%";

        const duration = p.Duration?.raw;

        this.root.render(React.createElement(BannerPanel, {
            show:     p.Show?.raw === true,
            type:     (p.Type?.raw || "info") as BannerType,
            title:    p.Title?.raw || "",
            message:  p.Message?.raw || "",
            duration: duration === null || duration === undefined ? 4000 : duration,
            notifyId: p.NotifyId?.raw || "",
            theme:    (p.Theme?.raw || "dark") as ThemeName,
            onDismiss: () => {
                this.eventName = "Dismissed";
                this.eventId   = newId();
                this.notify();
            },
        }));
    }

    public getOutputs(): IOutputs {
        return { EventName: this.eventName, EventId: this.eventId };
    }

    public destroy(): void { this.root.unmount(); }
}
