import * as React from "react";
import {
    Save, AlertTriangle, CheckCircle2, X, UserCog, SlidersHorizontal,
    UserPlus, Pencil, Trash2, Check,ArrowLeft,
} from "lucide-react";
import {
    AdminFieldSchema, AdminSettingValues, AdminUserRow, AdminRoleOption,
    Command, ThemeName, withDefaults, validateForm,AdminPersonResult,
} from "../shared/types";

export interface AdminPanelProps {
    settingsSchema: AdminFieldSchema[];
    settingsValues: AdminSettingValues;
    userFormSchema: AdminFieldSchema[];
    users: AdminUserRow[];
    roles: AdminRoleOption[];
    theme: ThemeName;
    searchResults: AdminPersonResult[];
    command?: Command;
    onEvent: (name: string, payload?: unknown) => void;
}

type Toast = { kind: "success" | "error"; text: string } | null;
type FieldErrors = Record<string, string>;


const PeopleField: React.FC<{
    value: string;
    results: AdminPersonResult[];
    onSearch: (q: string) => void;
    onChange: (email: string) => void;
}> = ({ value, results, onSearch, onChange }) => {
    const [text, setText] = React.useState(value);
    const [open, setOpen] = React.useState(false);
    const timer = React.useRef<number | undefined>(undefined);

    React.useEffect(() => { setText(value); }, [value]);
    

    const type = (v: string) => {
        setText(v);
        onChange(v);                       // typed text is the value until a person is picked
        setOpen(true);
        window.clearTimeout(timer.current);
        if (v.trim().length >= 2) {
            timer.current = window.setTimeout(() => onSearch(v.trim()), 350);
        }
    };

    return (
        <div className="admin-people">
            <input
                type="text"
                value={text}
                placeholder="Search name or email…"
                onChange={(e) => type(e.target.value)}
                onFocus={() => setOpen(true)}
                onBlur={() => setOpen(false)}
            />
            {open && text.trim().length >= 2 && results.length > 0 ? (
                <ul className="admin-people-list" role="listbox">
                    {results.map((r) => (
                        <li
                            key={r.email}
                            role="option"
                            onMouseDown={(e) => {
                                e.preventDefault();
                                setText(r.email);
                                onChange(r.email);
                                setOpen(false);
                            }}
                        >
                            <span className="pn">{r.name}</span>
                            <span className="pe">{r.email}{r.title ? ` · ${r.title}` : ""}</span>
                        </li>
                    ))}
                </ul>
            ) : null}
        </div>
    );
};

export const AdminPanel: React.FC<AdminPanelProps> = ({
    settingsSchema, settingsValues, userFormSchema, users, roles, theme,searchResults, command, onEvent,
}) => {
    const [tab, setTab] = React.useState<"settings" | "users">("settings");
    const [toast, setToast] = React.useState<Toast>(null);

    const [settingsDraft, setSettingsDraft] = React.useState<AdminSettingValues>(
        () => withDefaults(settingsSchema, settingsValues),
    );
    const [settingsErrors, setSettingsErrors] = React.useState<FieldErrors>({});
    const [savingSettings, setSavingSettings] = React.useState(false);

    const emptyUserForm = React.useMemo(
        () => withDefaults(userFormSchema, {}), [userFormSchema],
    );
    const [userFormDraft, setUserFormDraft] = React.useState<AdminSettingValues>(emptyUserForm);
    const [userFormErrors, setUserFormErrors] = React.useState<FieldErrors>({});
    const [invitingUser, setInvitingUser] = React.useState(false);

    const [userDraft, setUserDraft] = React.useState<Record<string, string>>({});
    const [editingUserId, setEditingUserId] = React.useState<string | null>(null);
    const [editDraft, setEditDraft] = React.useState<{ name: string; email: string }>({ name: "", email: "" });

    React.useEffect(() => {
        setSettingsDraft(withDefaults(settingsSchema, settingsValues));
    }, [settingsSchema, settingsValues]);

    React.useEffect(() => {
        if (!command) return;
        const p = (command.payload ?? {}) as { success?: boolean; message?: string };
        switch (command.action) {
            case "SettingsSaveResult":
                setSavingSettings(false);
                setToast({
                    kind: p.success ? "success" : "error",
                    text: p.message ?? (p.success ? "Settings saved." : "Could not save settings."),
                });
                break;
            case "UserInviteResult":
                setInvitingUser(false);
                if (p.success) setUserFormDraft(emptyUserForm);
                setToast({
                    kind: p.success ? "success" : "error",
                    text: p.message ?? (p.success ? "User invited." : "Could not invite user."),
                });
                break;
            case "UserUpdateResult":
            case "UserRemoveResult":
                setToast({
                    kind: p.success ? "success" : "error",
                    text: p.message ?? (p.success ? "User updated." : "Could not update user."),
                });
                break;
            default:
                break;
        }
    }, [command, emptyUserForm]);

    React.useEffect(() => {
        if (!toast) return;
        const t = setTimeout(() => setToast(null), 3200);
        return () => clearTimeout(t);
    }, [toast]);

    const submitSettings = () => {
        const errs = validateForm(settingsSchema, settingsDraft);
        setSettingsErrors(errs);
        if (Object.keys(errs).length > 0) {
            setToast({ kind: "error", text: "Fix the highlighted fields before saving." });
            return;
        }
        setSavingSettings(true);
        onEvent("SettingsSubmitted", { values: settingsDraft });
    };

    const submitInviteUser = () => {
        const errs = validateForm(userFormSchema, userFormDraft);
        setUserFormErrors(errs);
        if (Object.keys(errs).length > 0) {
            setToast({ kind: "error", text: "Fix the highlighted fields before inviting." });
            return;
        }
        setInvitingUser(true);
        onEvent("UserInvited", { values: userFormDraft });
    };

    const updateUserRole = (userId: string, roleId: string) => {
        setUserDraft((d) => ({ ...d, [userId]: roleId }));
        onEvent("UserRoleUpdated", { userId, roleId });
    };

    const removeUser = (userId: string) => onEvent("UserRemoved", { userId });

    const startEdit = (u: AdminUserRow) => {
        setEditingUserId(u.userId);
        setEditDraft({ name: u.name, email: u.email });
    };
    const cancelEdit = () => setEditingUserId(null);
    const saveEdit = (userId: string) => {
        onEvent("UserUpdated", { userId, name: editDraft.name.trim(), email: editDraft.email.trim() });
        setEditingUserId(null);
    };

    const renderField = (
        f: AdminFieldSchema,
        values: AdminSettingValues,
        setValue: (key: string, v: AdminSettingValues[string]) => void,
        errors: FieldErrors,
    ) => {
        const value = values[f.key];
        const hasErr = Boolean(errors[f.key]);
        let input: React.ReactNode;

        switch (f.type) {
            case "boolean":
                input = (
                    <button
                        type="button"
                        className="admin-toggle-row"
                        onClick={() => setValue(f.key, !value)}
                    >
                        <div className="admin-toggle-text">
                            <span className="atl">{f.helpText ?? (value ? "On" : "Off")}</span>
                            {f.helpText ? <span className="ath">{value ? "On" : "Off"}</span> : null}
                        </div>
                        <div className={`admin-toggle-switch${value ? " on" : ""}`} aria-hidden="true" />
                    </button>
                );
                break;
            case "choice":
                input = (
                    <select value={(value as string) ?? ""} onChange={(e) => setValue(f.key, e.target.value)}>
                        <option value="" disabled>Select…</option>
                        {(f.options ?? []).map((o) => <option key={o} value={o}>{o}</option>)}
                    </select>
                );
                break;
            case "textarea":
                input = (
                    <textarea
                        rows={3}
                        maxLength={f.maxLength}
                        value={(value as string) ?? ""}
                        onChange={(e) => setValue(f.key, e.target.value)}
                    />
                );
                break;
            case "number":
                input = (
                    <input
                        type="number"
                        min={f.min}
                        max={f.max}
                        value={value === null || value === undefined ? "" : Number(value)}
                        onChange={(e) => setValue(f.key, e.target.value === "" ? null : Number(e.target.value))}
                    />
                );
                break;
            case "email":
                input = (
                    <input
                        type="email"
                        maxLength={f.maxLength}
                        value={(value as string) ?? ""}
                        onChange={(e) => setValue(f.key, e.target.value)}
                    />
                );
                break;
            case "people":
                input = (
                    <PeopleField
                        value={(value as string) ?? ""}
                        results={searchResults}
                        onSearch={(q) => onEvent("UserSearchRequested", { key: f.key, query: q })}
                        onChange={(email) => setValue(f.key, email)}
                    />
                );
                break;
            default:
                input = (
                    <input
                        type="text"
                        minLength={f.minLength}
                        maxLength={f.maxLength}
                        value={(value as string) ?? ""}
                        onChange={(e) => setValue(f.key, e.target.value)}
                    />
                );
        }

        const wide = f.type === "textarea" || f.type === "boolean";
        return (
            <div className={"admin-fld" + (wide ? " span2" : "") + (hasErr ? " err" : "")} key={f.key}>
                <label>{f.label}{f.required ? <span className="req">*</span> : null}</label>
                {input}
                {hasErr
                    ? <div className="admin-err">{errors[f.key]}</div>
                    : f.helpText ? <div className="admin-help">{f.helpText}</div> : null}
            </div>
        );
    };

    return (
        <div className="panel" data-t={theme}>
        <header className="ad-hd">
            <button type="button" className="iconbtn" aria-label="Back" title="Back to home"
                onClick={() => onEvent("NavigateHome")}>
                <ArrowLeft size={18} />
            </button>
            <h1>Admin</h1>
        </header>

            <div className="admin-tabs">
                <button className={"admin-tab" + (tab === "settings" ? " on" : "")} onClick={() => setTab("settings")}>
                    <SlidersHorizontal size={14} /> Settings
                </button>
                <button className={"admin-tab" + (tab === "users" ? " on" : "")} onClick={() => setTab("users")}>
                    <UserCog size={14} /> Users
                </button>
            </div>

            <div className="scroll">
                {tab === "settings" ? (
                    <>
                        <div className="admin-form admin-grid">
                            {settingsSchema.map((f) =>
                                renderField(f, settingsDraft, (k, v) => {
                                    setSettingsDraft((d) => ({ ...d, [k]: v }));
                                    setSettingsErrors((e) => { const n = { ...e }; delete n[k]; return n; });
                                }, settingsErrors),
                            )}
                        </div>
                        <div className="admin-act">
                            <button className="pillbtn fill" disabled={savingSettings} onClick={submitSettings}>
                                <Save size={14} /> {savingSettings ? "Saving…" : "Save settings"}
                            </button>
                        </div>
                    </>
                ) : (
                    <>
                        <div className="admin-subh">Invite a user</div>
                        <div className="admin-form admin-grid">
                            {userFormSchema.map((f) =>
                                renderField(f, userFormDraft, (k, v) => {
                                    setUserFormDraft((d) => ({ ...d, [k]: v }));
                                    setUserFormErrors((e) => { const n = { ...e }; delete n[k]; return n; });
                                }, userFormErrors),
                            )}
                        </div>
                        <div className="admin-act">
                            <button className="pillbtn fill" disabled={invitingUser} onClick={submitInviteUser}>
                                <UserPlus size={14} /> {invitingUser ? "Inviting…" : "Invite user"}
                            </button>
                        </div>

                        <div className="admin-subh mt20">Members</div>
                        <div className="admin-table-card">
                        <table className="admin-table">
                            <thead>
                                <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th /></tr>
                            </thead>
                            <tbody>
                                {users.length === 0 ? (
                                    <tr><td colSpan={5} className="admin-empty">No members yet — invite someone above.</td></tr>
                                ) : users.map((u) => {
                                    const editing = editingUserId === u.userId;
                                    return (
                                        <tr key={u.userId}>
                                            <td>
                                                {editing ? (
                                                    <input
                                                        className="admin-cell-input"
                                                        value={editDraft.name}
                                                        onChange={(e) => setEditDraft((d) => ({ ...d, name: e.target.value }))}
                                                    />
                                                ) : (
                                                    <div className="admin-row-user">
                                                        <div className="admin-row-avatar">
                                                            {(u.name ?? "").split(" ").filter(Boolean).slice(0, 2).map((w) => w[0]).join("").toUpperCase() || "?"}
                                                        </div>
                                                        <span>{u.name}</span>
                                                    </div>
                                                )}
                                            </td>
                                            <td className="dim">
                                                {editing ? (
                                                    <input
                                                        className="admin-cell-input"
                                                        type="email"
                                                        value={editDraft.email}
                                                        onChange={(e) => setEditDraft((d) => ({ ...d, email: e.target.value }))}
                                                    />
                                                ) : u.email}
                                            </td>
                                            <td>
                                                <select
                                                    value={userDraft[u.userId] ?? u.roleId}
                                                    onChange={(e) => updateUserRole(u.userId, e.target.value)}
                                                    disabled={editing}
                                                >
                                                    {roles.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                                                </select>
                                            </td>
                                            <td><span className={"status-pill " + u.status.toLowerCase()}>{u.status}</span></td>
                                            <td>
                                                {editing ? (
                                                    <div className="admin-row-actions">
                                                        <button className="iconbtn sm" aria-label="Save" onClick={() => saveEdit(u.userId)}>
                                                            <Check size={14} />
                                                        </button>
                                                        <button className="iconbtn sm" aria-label="Cancel" onClick={cancelEdit}>
                                                            <X size={14} />
                                                        </button>
                                                    </div>
                                                ) : (
                                                    <div className="admin-row-actions">
                                                        <button className="iconbtn sm" aria-label="Edit user" onClick={() => startEdit(u)}>
                                                            <Pencil size={14} />
                                                        </button>
                                                        <button className="iconbtn sm" aria-label="Remove user" onClick={() => removeUser(u.userId)}>
                                                            <Trash2 size={14} />
                                                        </button>
                                                    </div>
                                                )}
                                            </td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                        </div>
                    </>
                )}
            </div>

            {toast ? (
                <div className={"admin-toast " + toast.kind}>
                    {toast.kind === "success" ? <CheckCircle2 size={16} /> : <AlertTriangle size={16} />}
                    <span>{toast.text}</span>
                    <button className="iconbtn sm" onClick={() => setToast(null)} aria-label="Dismiss">
                        <X size={14} />
                    </button>
                </div>
            ) : null}
        </div>
    );
};