import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { AdminPanel } from "./AdminPanel";
import {
    AdminFieldSchema, AdminSettingValues, AdminUserRow, AdminRoleOption,
    Command, ThemeName, newId, parseJson,UserProfile,AdminPersonResult
} from "../shared/types";

export class ShelfAdmin
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;

    private eventName = "";
    private eventPayload = "";
    private eventId = "";

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);

        this.host = document.createElement("div");
        this.host.className = "shelf shelf-admin";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;

        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        this.host.style.height = h > 0 ? `${h}px` : "100%";
        this.host.style.width  = w > 0 ? `${w}px` : "100%";

        const command = parseJson<Command | null>(p.Command?.raw, null);

        this.root.render(
            React.createElement(AdminPanel, {
                settingsSchema:  parseJson<AdminFieldSchema[]>(p.AdminSettingsSchemaJson?.raw, []),
                settingsValues:  parseJson<AdminSettingValues>(p.AdminSettingsValuesJson?.raw, {}),
                userFormSchema:  parseJson<AdminFieldSchema[]>(p.AdminUserFormSchemaJson?.raw, []),
                users:           parseJson<AdminUserRow[]>(p.AdminUsersJson?.raw, []),
                roles:           parseJson<AdminRoleOption[]>(p.AdminRolesJson?.raw, []),
                theme:           (p.Theme?.raw || "dark") as ThemeName,
                searchResults: parseJson<AdminPersonResult[]>(p.UserSearchResultsJson?.raw, []),
                command:         command ?? undefined,
                onEvent: (name: string, payload?: unknown) => {
                    this.eventName    = name;
                    this.eventPayload = payload === undefined ? "" : JSON.stringify(payload);
                    this.eventId      = newId();
                    this.notify();
                },
            }),
        );
    }

    public getOutputs(): IOutputs {
        return {
            EventName:    this.eventName,
            EventPayload: this.eventPayload,
            EventId:      this.eventId,
        };
    }

    public destroy(): void {
        this.root.unmount();
    }
}