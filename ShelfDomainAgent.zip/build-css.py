#!/usr/bin/env python3
"""Regenerates ShelfWorkspace.css from the three panel stylesheets plus _shell.css.
Run from the project root after changing any panel CSS."""

src    = open('ShelfSources/css/ShelfSources.css').read()
chat   = open('ShelfChat/css/ShelfChat.css').read()
studio = open('ShelfStudio/css/ShelfStudio.css').read()
shell  = open('ShelfWorkspace/css/_shell.css').read()

chat_u   = chat[chat.index('/* thread */'):]
studio_u = studio[studio.index('/* feature card */'):studio.index('/* dialog */')]

extras = """
/* studio extras not covered by the sources dialog block */
.shelf .pillbtn.full { width: 100%; height: 34px; }
.shelf .mt12 { margin-top: 12px; }
.shelf .dlg-act.end { justify-content: flex-end; }
.shelf .warn.err { border-left: 3px solid var(--bad); }
.shelf .iconbtn.sm { width: 28px; height: 28px; }
"""

out = "\n".join([
    "/* ShelfMind - ShelfWorkspace (generated). Do not hand-edit. */",
    "", src, "", chat_u, "", studio_u, extras, "", shell,
])
open('ShelfWorkspace/css/ShelfWorkspace.css', 'w').write(out)
print("wrote ShelfWorkspace/css/ShelfWorkspace.css")




# For Home css only
src_full = open('ShelfSources/css/ShelfSources.css').read()
# Take only up to the source list section
tokens = src_full[:src_full.index('/* source list */')]

home_u = open('ShelfHome/css/_home.css').read()
open('ShelfHome/css/ShelfHome.css', 'w').write(
    "\n".join([
        "/* ShelfMind - ShelfHome (generated). Do not hand-edit. */",
        "", tokens, "", home_u, "", shell,
    ])
)
print("wrote ShelfHome/css/ShelfHome.css")

# For Admin css only
admin_u = open('ShelfAdmin/css/_admin.css').read()
open('ShelfAdmin/css/ShelfAdmin.css', 'w').write(
    "\n".join([
        "/* ShelfMind - ShelfAdmin (generated). Do not hand-edit. */",
        "", tokens, "", admin_u, "", shell,
    ])
)
print("wrote ShelfAdmin/css/ShelfAdmin.css")

# For Toast css only
toast_u = open('ShelfToast/css/_toast.css').read()
open('ShelfToast/css/ShelfToast.css', 'w').write(
    "\n".join([
        "/* ShelfMind - ShelfToast (generated). Do not hand-edit. */",
        "", tokens, "", toast_u,
    ])
)
print("wrote ShelfToast/css/ShelfToast.css")

# For Banner css only
banner_u = open('ShelfBanner/css/_banner.css').read()
open('ShelfBanner/css/ShelfBanner.css', 'w').write(
    "\n".join([
        "/* ShelfMind - ShelfBanner (generated). Do not hand-edit. */",
        "", tokens, "", banner_u,
    ])
)
print("wrote ShelfBanner/css/ShelfBanner.css")

# For Observability css only
obs_u = open('ShelfObservability/css/_observability.css').read()
open('ShelfObservability/css/ShelfObservability.css', 'w').write(
    "\n".join([
        "/* ShelfMind - ShelfObservability (generated). Do not hand-edit. */",
        "", tokens, "", obs_u,
    ])
)
print("wrote ShelfObservability/css/ShelfObservability.css")