/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    AdminSettingsSchemaJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminSettingsValuesJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminUserFormSchemaJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminUsersJson: ComponentFramework.PropertyTypes.StringProperty;
    AdminRolesJson: ComponentFramework.PropertyTypes.StringProperty;
    UserSearchResultsJson: ComponentFramework.PropertyTypes.StringProperty;
    Theme: ComponentFramework.PropertyTypes.StringProperty;
    Command: ComponentFramework.PropertyTypes.StringProperty;
    UserProfileJson: ComponentFramework.PropertyTypes.StringProperty;
    UserName: ComponentFramework.PropertyTypes.StringProperty;
    Show: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    Type: ComponentFramework.PropertyTypes.StringProperty;
    Title: ComponentFramework.PropertyTypes.StringProperty;
    Message: ComponentFramework.PropertyTypes.StringProperty;
    Duration: ComponentFramework.PropertyTypes.WholeNumberProperty;
    NotifyId: ComponentFramework.PropertyTypes.StringProperty;
    MessagesJson: ComponentFramework.PropertyTypes.StringProperty;
    NotebookJson: ComponentFramework.PropertyTypes.StringProperty;
    SuggestedJson: ComponentFramework.PropertyTypes.StringProperty;
    ViewerJson: ComponentFramework.PropertyTypes.StringProperty;
    StreamingText: ComponentFramework.PropertyTypes.StringProperty;
    IsThinking: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    SelectedCount: ComponentFramework.PropertyTypes.WholeNumberProperty;
    DomainLabel: ComponentFramework.PropertyTypes.StringProperty;
    Placeholder: ComponentFramework.PropertyTypes.StringProperty;
    NotebooksJson: ComponentFramework.PropertyTypes.StringProperty;
    LogoSvg: ComponentFramework.PropertyTypes.StringProperty;
    LogoUrl: ComponentFramework.PropertyTypes.StringProperty;
    AppName: ComponentFramework.PropertyTypes.StringProperty;
    HeroHeadline: ComponentFramework.PropertyTypes.StringProperty;
    HeroDescription: ComponentFramework.PropertyTypes.StringProperty;
    IsAdmin: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    ShowObservability: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    EventsJson: ComponentFramework.PropertyTypes.StringProperty;
    UsersJson: ComponentFramework.PropertyTypes.StringProperty;
    DefaultStartDate: ComponentFramework.PropertyTypes.StringProperty;
    DefaultEndDate: ComponentFramework.PropertyTypes.StringProperty;
    IsLoading: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    SourcesJson: ComponentFramework.PropertyTypes.StringProperty;
    SelectedIdsIn: ComponentFramework.PropertyTypes.StringProperty;
    GuardrailJson: ComponentFramework.PropertyTypes.StringProperty;
    DiscoverJson: ComponentFramework.PropertyTypes.StringProperty;
    HighlightIds: ComponentFramework.PropertyTypes.StringProperty;
    IsBusy: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    SourceLimit: ComponentFramework.PropertyTypes.WholeNumberProperty;
    MaxInlineFileBytes: ComponentFramework.PropertyTypes.WholeNumberProperty;
    ToolsJson: ComponentFramework.PropertyTypes.StringProperty;
    OutputsJson: ComponentFramework.PropertyTypes.StringProperty;
    BusyToolId: ComponentFramework.PropertyTypes.StringProperty;
    PathDefaultsJson: ComponentFramework.PropertyTypes.StringProperty;
    MinSources: ComponentFramework.PropertyTypes.WholeNumberProperty;
    ErrorText: ComponentFramework.PropertyTypes.StringProperty;
    Visible: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    Description: ComponentFramework.PropertyTypes.StringProperty;
    PopupX: ComponentFramework.PropertyTypes.WholeNumberProperty;
    PopupY: ComponentFramework.PropertyTypes.WholeNumberProperty;
    PopupWidth: ComponentFramework.PropertyTypes.WholeNumberProperty;
    PopupHeight: ComponentFramework.PropertyTypes.WholeNumberProperty;
    Roles: ComponentFramework.PropertyTypes.StringProperty;
    Levels: ComponentFramework.PropertyTypes.StringProperty;
    DefaultRole: ComponentFramework.PropertyTypes.StringProperty;
    DefaultLevel: ComponentFramework.PropertyTypes.StringProperty;
    WorkspaceSettingsJson: ComponentFramework.PropertyTypes.StringProperty;
    ShowHeader: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    ResolveCitationsLocally: ComponentFramework.PropertyTypes.TwoOptionsProperty;
    WorkspaceSettingsSchemaJson: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    EventName?: string;
    EventPayload?: string;
    EventId?: string;
    DraftText?: string;
    StartDate?: string;
    EndDate?: string;
    UserIds?: string;
    SelectedIds?: string;
    SelectedCount?: number;
    EventPanel?: string;
}
