import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { WorkspaceSettings, Workspace, WorkspaceProps } from "./Workspace";
import {
    ChatMessage, Command, GuardrailState, NotebookMeta, PathDefaults,
    PanelKey, SourceItem, StudioOutput, StudioTool, SuggestedQuestion, ThemeName, ViewerPayload,
    AdminFieldSchema, AdminSettingValues, AdminUserRow, AdminRoleOption, UserProfile,
    newId, parseJson,
} from "../shared/types";

const DEFAULT_TOOLS: StudioTool[] = [
    { id: "slides", name: "Slide deck", sub: "Board-ready summary", icon: "slides", enabled: true },
    { id: "quiz", name: "Quiz", sub: "Check understanding", icon: "quiz", enabled: true },
    { id: "guide", name: "Study guide", sub: "Terms and questions", icon: "guide", enabled: true },
    { id: "brief", name: "Briefing doc", sub: "One-page summary", icon: "brief", enabled: true },
];

const DEFAULT_PATH: PathDefaults = {
    roles: ["Category manager", "Key account manager", "Store manager", "Brand manager", "Analyst"],
    levels: ["New to the field", "Some experience", "Experienced"],
};

const DEFAULT_WS_SETTINGS_SCHEMA: AdminFieldSchema[] = [
    { key: "emoji", label: "Emoji", type: "text", required: false, maxLength: 2 },
    { key: "title", label: "Workspace name", type: "text", required: true, minLength: 1, maxLength: 80 },
    { key: "answerStyle", label: "Answer style", type: "segmented", required: true,
      options: ["concise", "balanced", "detailed"], defaultValue: "balanced" },
    { key: "citationMode", label: "Citations", type: "segmented", required: true,
      options: ["always", "when-available"], defaultValue: "always" },
    { key: "passMark", label: "Quiz pass mark", type: "segmented", required: false,
      options: ["60", "70", "80"], defaultValue: "70", readOnly: true },
    { key: "strictSources", label: "Answer only from selected sources", type: "boolean", required: false,
      defaultValue: true, helpText: "Off lets the agent say when the library has no coverage instead of refusing." },
];

function csvList(raw: string | null | undefined): string[] | undefined {
    const items = (raw ?? "").split(",").map((s) => s.trim()).filter(Boolean);
    return items.length ? items: undefined;
}

export class ShelfWorkspace
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;

    private selectedIds: string[] = [];
    private eventName = "";
    private eventPayload = "";
    private eventId = "";
    private eventPanel = "";
    private draft = "";

    private lastCommandId = "";
    private command?: Command;
    private seeded = false;
        
    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);

        this.host = document.createElement("div");
        this.host.className = "shelf shelf-workspace";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;

        const sources = parseJson<SourceItem[]>(p.SourcesJson?.raw, []);
        const tools = parseJson<StudioTool[]>(p.ToolsJson?.raw, DEFAULT_TOOLS);
        const pathDefaults = parseJson<PathDefaults>(p.PathDefaultsJson?.raw, DEFAULT_PATH);

        if (!this.seeded) {
            const seed = (p.SelectedIdsIn?.raw ?? "").split(",").map((s) => s.trim()).filter(Boolean);
            this.selectedIds = seed;
            this.seeded = true;
        }

        const cmd = parseJson<Command | null>(p.Command?.raw, null);
        if (cmd && cmd.id && cmd.id !== this.lastCommandId) {
            this.lastCommandId = cmd.id;
            this.command = cmd;
            if (cmd.action === "SetSelection" && Array.isArray(cmd.payload?.ids)) {
                this.selectedIds = cmd.payload!.ids as string[];
            }
            if (cmd.action === "SelectAll") this.selectedIds = sources.map((s) => s.id);
            if (cmd.action === "ClearSelection") this.selectedIds = [];
            if (cmd.action === "ClearDraft") this.draft = "";
        } else {
            this.command = undefined;
        }

        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        this.host.style.height = (h > 0) ? `${h}px` : "100%";
        this.host.style.width = (w > 0) ? `${w}px` : "100%";

        const viewerRaw = p.ViewerJson?.raw ?? "";

        const props: WorkspaceProps = {
            sources,
            selectedIds: this.selectedIds,
            guardrail: parseJson<GuardrailState>(p.GuardrailJson?.raw, {
                active: true, domain: "Retail & CPG",
            }),
            sourceLimit: p.SourceLimit?.raw ?? 50,
            maxInlineFileBytes: p.MaxInlineFileBytes?.raw ?? 1572864,

            messages: parseJson<ChatMessage[]>(p.MessagesJson?.raw, []),
            notebook: parseJson<NotebookMeta>(p.NotebookJson?.raw, { title: "Untitled Workspace" }),
            suggested: parseJson<SuggestedQuestion[]>(p.SuggestedJson?.raw, []),
            viewer: parseJson<ViewerPayload | null>(viewerRaw, null),
            viewerKey: viewerRaw,
            streamingText: p.StreamingText?.raw ?? "",
            isThinking: p.IsThinking?.raw === true,
            domainLabel: p.DomainLabel?.raw ?? "Retail & CPG domain only",
            placeholder: p.Placeholder?.raw ?? "Ask anything about retail or consumer goods",

            tools: tools.filter((t) => t.enabled !== false),
            outputs: parseJson<StudioOutput[]>(p.OutputsJson?.raw, []),
            busyToolId: p.BusyToolId?.raw ?? "",
            pathDefaults: {
                roles: csvList(p.Roles?.raw) ?? pathDefaults.roles ?? DEFAULT_PATH.roles,
                levels: csvList(p.Levels?.raw) ?? pathDefaults.levels ?? DEFAULT_PATH.levels,
                role: p.DefaultRole?.raw || pathDefaults.role,
                level: p.DefaultLevel?.raw || pathDefaults.level,
                goal: pathDefaults.goal,
            },
            minSources: p.MinSources?.raw ?? 1,
            errorText: p.ErrorText?.raw ?? "",
            settingsSchema: parseJson<AdminFieldSchema[]>(p.WorkspaceSettingsSchemaJson?.raw, DEFAULT_WS_SETTINGS_SCHEMA),
            workspaceSettingsValues: parseJson<AdminSettingValues>(p.WorkspaceSettingsJson?.raw, {}),
            userName: p.UserName?.raw ?? "",
            logoSvg: p.LogoSvg ?. raw ?? "",
            logoUrl: p.LogoUrl ?. raw ?? "",
            appName: p.AppName ?. raw || "RCPG Agent",
            theme: ((p.Theme?.raw || "dark") as ThemeName),
            showHeader: p.ShowHeader?.raw === true,
            resolveCitationsLocally: p.ResolveCitationsLocally?.raw !== false,
            width: w,
            command: this.command,
            isAdmin: p.IsAdmin?.raw === true,
            showObservability: p.ShowObservability?.raw === true,
            // add to each control's props object in updateView:
            userProfile: parseJson<UserProfile | null>(p.UserProfileJson?.raw, null),
            onSelectionChange: (ids) => {
                this.selectedIds = ids;
                this.emit("sources", "SelectionChanged", { ids });
            },
            onDraftChange: (t) => { this.draft = t; },
            onEvent: (panel, name, payload) => this.emit(panel, name, payload),
        };

        this.root.render(React.createElement(Workspace, props));
    }

    private emit(panel: PanelKey, name: string, payload?: unknown): void {
        this.eventPanel = panel;
        this.eventName = name;
        this.eventPayload = payload === undefined ? "" : JSON.stringify(payload);
        this.eventId = newId();
        this.notify();
    }

    public getOutputs(): IOutputs {
        return {
            SelectedIds: this.selectedIds.join(","),
            SelectedCount: this.selectedIds.length,
            EventName: this.eventName,
            EventPayload: this.eventPayload,
            EventId: this.eventId,
            EventPanel: this.eventPanel,
            DraftText: this.draft,
        };
    }

    public destroy(): void {
        this.root.unmount();
    }
}
