import * as React from "react";
import {
    PanelLeft, PanelRight, FileText, MessageSquareText, Sparkles, Share2, Pencil, Sun, Moon, Settings, Activity, ShieldCheck, SlidersHorizontal, X, Check,
} from "lucide-react";
import {
    ChatMessage, Citation, Command, GuardrailState, IconCmp,NotebookMeta,
    PathDefaults, SourceItem, StudioOutput, StudioTool, SuggestedQuestion,
    ThemeName, ViewerPayload, PanelKey, UserProfile,
    AdminFieldSchema, AdminSettingValues, withDefaults, validateForm,
} from "../shared/types";

import { AddDialog, SourcesPanel } from "../ShelfSources/SourcesPanel";
import { ChatPanel } from "../ShelfChat/ChatPanel";
import { PathDialog, StudioPanel } from "../ShelfStudio/StudioPanel";
import { ProfileCard } from "../shared/ProfileCard";
import { CommonMenuItems } from "../shared/CommonMenuItems";


export interface WorkspaceProps {
    /* sources */
    sources: SourceItem[];
    selectedIds: string[];
    guardrail: GuardrailState;
    sourceLimit: number;
    maxInlineFileBytes: number;
    /* chat */
    messages: ChatMessage[];
    notebook: NotebookMeta;
    suggested: SuggestedQuestion[];
    viewer: ViewerPayload | null;
    viewerKey: string;
    streamingText: string;
    isThinking: boolean;
    domainLabel: string;
    placeholder: string;
    /* studio */
    tools: StudioTool[];
    outputs: StudioOutput[];
    busyToolId: string;
    pathDefaults: PathDefaults;
    minSources: number;
    errorText: string;
    /* shell */
    logoSvg: string;
    logoUrl: string;
    appName: string;
    userName:string;
    settingsSchema: AdminFieldSchema[];
    workspaceSettingsValues: AdminSettingValues;
    theme: ThemeName;
    showHeader: boolean;
    resolveCitationsLocally: boolean;
    width: number;
    command?: Command;

    /* admin */
    isAdmin: boolean;
    showObservability: boolean;
    userProfile: UserProfile | null;

    onSelectionChange: (ids: string[]) => void;
    onDraftChange: (text: string) => void;
    onEvent: (panel: PanelKey, name: string, payload?: unknown) => void;
}

const NARROW = 900;

/* Renders a caller-supplied mark as an <img> data URI rather than inlining the markup, so hostile SVG cannot execute script in the host session. */
const BrandMark: React.FC<{ svg: string; url: string }> = ({ svg, url }) => {
    if (svg.trim().startsWith("<svg")) {
        
    const src= `data:image/svg+xml:charset=utf-8,${encodeURIComponent(svg)}`;
    return <img className="ws-logo" src={src} alt="" aria-hidden="true" />;
    }
    if (url) return <img className="ws-logo" src={url} alt="" aria-hidden="true" />;
    return (
        <svg className="ws-logo" viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" rx="16" fill="currentColor" />
        <rect x="16" y="22" width="32" height="4" rx="2" fill="#fff" />
        <rect x="16" y="42" width="32" height="4" rx="2" fill="#fff" />
        <rect x="20" y="10" width="9" height="12" rx="2" fill="#fff" />
        <rect x="33" y="14" width="9" height="12" rx="2" fill="#fff" opacity=".55" />
        <rect x="20" y="32" width="14" height="10" rx="2" fill="#fff" opacity=".55" />
        </svg>
    );
};


export const Workspace: React.FC<WorkspaceProps> = (props) => {
    const {
        sources, selectedIds, guardrail, sourceLimit, maxInlineFileBytes,
        messages, notebook, suggested, viewer, viewerKey, streamingText, isThinking,
        domainLabel, placeholder,
        tools, outputs, busyToolId, pathDefaults, minSources, errorText,
        logoSvg,logoUrl,appName, userName, settingsSchema, workspaceSettingsValues, theme, showHeader, resolveCitationsLocally, width, command, isAdmin, showObservability, userProfile,
        
        onSelectionChange, onDraftChange, onEvent,
    } = props;

    const narrow = width > 0 && width <= NARROW;

    const [leftOpen, setLeftOpen] = React.useState(false);   // sources collapsed by default
    const [rightOpen, setRightOpen] = React.useState(true);  // studio open by default
    const [tab, setTab] = React.useState<PanelKey>("chat");

    /* viewer opened from inside the control, e.g. a citation click */
    const [pathOpen, setPathOpen] = React.useState(false);
    const [addOpen, setAddOpen] = React.useState(false);
    const [menuOpen, setMenuOpen] = React.useState(false);
    const [guardOpen, setGuardOpen] = React.useState(false);
    const [setsOpen, setSetsOpen] = React.useState(false);
    const [profileOpen, setProfileOpen] = React.useState(false);
    const initials = (userName || "User")
            .split(" ").filter(Boolean).slice(0, 2)
            .map((w)=>w[0].toUpperCase()).join("");
    const [localViewer, setLocalViewer] = React.useState<ViewerPayload | null>(null);
    const [highlight, setHighlight] = React.useState<string[]>([]);
    const hlTimer = React.useRef<number | undefined>(undefined);

    /* an app-driven viewer change always wins over the local one */
    React.useEffect(() => { setLocalViewer(null); }, [viewerKey]);

    React.useEffect(() => () => {
        if (hlTimer.current) window.clearTimeout(hlTimer.current);
    }, []);

    React.useEffect(() => {
        if (!command) return;
        switch (command.action) {
            case "OpenPanel": {
                const p = command.payload?.panel as PanelKey | undefined;
                if (p === "sources") { setLeftOpen(true); setTab("sources"); }
                if (p === "studio") { setRightOpen(true); setTab("studio"); }
                if (p === "chat") setTab("chat");
                break;
            }
            case "ClosePanel": {
                const p = command.payload?.panel as PanelKey | undefined;
                if (p === "sources") setLeftOpen(false);
                if (p === "studio") setRightOpen(false);
                break;
            }
            case "CloseViewer":
                setLocalViewer(null);
                break;
            case "OpenPathDialog":
                setPathOpen(true);
                break;
            case "OpenAdd":
                setAddOpen(true);
                break;
            case "CloseDialog":
                setPathOpen(false);
                setAddOpen(false);
                break;
            default:
                break;
        }
    }, [command]);

    const flash = (id: string) => {
        setHighlight([id]);
        if (hlTimer.current) window.clearTimeout(hlTimer.current);
        hlTimer.current = window.setTimeout(() => setHighlight([]), 2200);
    };

    /* resolve a citation against the in-memory source list, no round trip */
    const resolveCitation = (c: Citation, messageId: string): boolean => {
        if (!resolveCitationsLocally) return false;

        const match = sources.find((s) => s.id === c.sourceId) ?? (
            c.fileName
                ? sources.find((s) =>
                    (s.fileName ?? "").toLowerCase() === c.fileName!.toLowerCase() ||
                    s.title.toLowerCase() === c.fileName!.toLowerCase()
                )
                : undefined
        );

        if (!match) {
            onEvent("chat", "CitationUnresolved", {
                messageId, sourceId: c.sourceId, fileName: c.fileName, index: c.index,
            });
            return false;
        }

        setLocalViewer({
            type: "doc",
            data: {
                ...match,
                summary: c.summary ?? match.summary,
                meta: c.page ? `${match.meta ?? ""}${match.meta ? " • " : ""}Cited on page ${c.page}` : match.meta,
            },
        });

        flash(match.id);
        if (narrow) setTab("chat");

        /* still tell the app, for telemetry, but it need not act */
        onEvent("chat", "CitationClicked", {
            messageId, sourceId: match.id, fileName: match.fileName,
            index: c.index, page: c.page, resolvedLocally: true,
        });
        return true;
    };

    const activeViewer = localViewer ?? viewer;

    const togglePanel = (panel: "sources" | "studio", open: boolean) => {
        if (panel === "sources") setLeftOpen(open); else setRightOpen(open);
        onEvent(panel, "PanelToggled", { panel, open });
    };

    // const showLeft = leftOpen && (!narrow || tab === "sources");
    // const showRight = rightOpen && (!narrow || tab === "studio");
    const showChat = !narrow || tab === "chat";

    return (
        <div className="ws" data-t={theme}>
            {showHeader ? (
                <header className="ws-top">
                    <button className="ws-brand" aria-label="Go to home"
                    onClick={()=>onEvent("chat", "NavigateHome")}>
                    <BrandMark svg={logoSvg} url={logoUrl} />
                    <span className="ws-name">{appName}</span>
                    </button>
                    <span className="ws-div" />
                    <div className="ws-title">
                        {notebook.emoji ? <span className="ws-em">{notebook.emoji}</span> : null}
                        <button className="nb-title" onClick={() => onEvent("chat", "RenameRequested")}>
                            {notebook.title} <Pencil size={13} className="dim" />
                        </button>
                    </div>
                    <div className="ws-sp" />
                        <div className="ws-actions">
                            <button className="iconbtn" title="Switch theme"    
                                onClick={() => onEvent("shell","ThemeToggled",
                                { theme: theme === "dark" ? "light" : "dark" })}>
                                {theme === "dark" ? <Sun size={18} /> : <Moon size={18} />}
                            </button>

                            <button className={"iconbtn" + (menuOpen ? " on" : "")} title="Settings"
                                onClick={() => setMenuOpen(!menuOpen)}>
                                <Settings size={18} />
                            </button>

                            <div style={{ position: "relative" }}>
                                <button className="ws-avatar" title={userName || "Profile"}
                                    onClick={() => setProfileOpen(v => !v)}>
                                    {initials}
                                </button>
                                {profileOpen && userProfile ? (
                                    <ProfileCard
                                        profile={userProfile}
                                        initials={initials}
                                        onClose={() => setProfileOpen(false)}
                                    />
                                ) : null}
                            </div>   

                            {menuOpen ? (
                            <>
                            <div className="ws-menu-scrim" onClick={() => setMenuOpen(false)} />
                            <div className="ws-menu">
                            {showObservability ? (
                                <button className="ws-mi"
                                    onClick={()=>{setMenuOpen(false); onEvent("shell", "OpenObservability"); }}>
                                    <Activity size={16} className="mi-i" />
                                    <span>Observability<span className="mi-s">Usage, grounding, guardrail</span></span>
                                </button>
                            ) : null}
                            <button className="ws-mi"
                            onClick={()=>{ setMenuOpen(false); setGuardOpen(true);}}>
                            <ShieldCheck size={16} />
                            <span>Domain guardrail<span className="mi-s">What is allowed here</span></span>
                            </button>
                            <button className="ws-mi"
                            onClick={()=> { setMenuOpen(false); setSetsOpen(true); }}>
                            <SlidersHorizontal size={16} />
                            <span>Workspace settings<span className="mi-s">Name, answers, quizzes</span></span>
                            </button>
                            {isAdmin ? (
                            <button className="ws-mi"
                            onClick={() => { setMenuOpen(false); onEvent("shell", "NavigateAdminScreen"); }}>
                            <ShieldCheck size={16} />
                            <span>Admin<span className="mi-s">Limits, roles and users</span></span>
                            </button>
                        ) : null}
                        <CommonMenuItems
                                withSeparator
                                onProfile={userProfile ? () => { setMenuOpen(false); setProfileOpen(true); } : undefined}
                                onHelp={() => { setMenuOpen(false); onEvent("shell", "OpenHelp"); }}
                                onFeedback={() => { setMenuOpen(false); onEvent("shell", "SendFeedback"); }}
                            />
                            
                            </div>
                            </>
                            ) : null}
        </div>
        </header>
    ) : null}

            <div className="ws-body">
                        <>
                {!narrow || tab === "studio" ? (
                    <div className={"ws-col ws-left" + (rightOpen ? "" : " collapsed")}>
                        <StudioPanel
                            tools={tools}
                            outputs={outputs}
                            busyToolId={busyToolId}
                            pathDefaults={pathDefaults}
                            selectedCount={selectedIds.length}
                            minSources={minSources}
                            errorText={errorText}
                            theme={theme}
                            command={command}
                            collapsed={!rightOpen}
                            onRequestPathDialog={() => setPathOpen(true)}
                            onEvent={(name, payload) => {
                                if (name === "CollapseRequested") { togglePanel("studio", false); return; }
                                if (name === "ExpandRequested") { togglePanel("studio", true); return; }
                                onEvent("studio", name, payload);
                            }}
                        />
                    </div>
                ) : null}

                {showChat ? (
                    <div className="ws-col ws-mid">
                        <ChatPanel
                            messages={messages}
                            notebook={notebook}
                            suggested={suggested}
                            viewer={activeViewer}
                            streamingText={streamingText}
                            isThinking={isThinking}
                            selectedCount={selectedIds.length}
                            domainLabel={domainLabel}
                            placeholder={placeholder}
                            theme={theme}
                            command={command}
                            onDraftChange={onDraftChange}
                            onCitationResolve={resolveCitation}
                            onEvent={(name, payload) => {
                                if (name === "ViewerClosed") {
                                    if (localViewer) {
                                        setLocalViewer(null);
                                    }
                                    // always fire to Power Apps so it can clear ViewerPayloadJson
                                    onEvent("chat", "ViewerClosed", payload);
                                    return;
                                }
                                onEvent("chat", name, payload);
                            }}
                        />
                    </div>
                ) : null}

                {!narrow || tab === "sources" ? (
                    <div className={"ws-col ws-right" + (leftOpen ? "" : " collapsed")}>
                        <SourcesPanel
                            sources={sources}
                            selectedIds={selectedIds}
                            guardrail={guardrail}
                            isBusy={false}
                            collapsed={!leftOpen}
                            onRequestAddDialog={() => setAddOpen(true)}
                            highlightIds={highlight}
                            theme={theme}
                            sourceLimit={sourceLimit}
                            maxInlineFileBytes={maxInlineFileBytes}
                            command={command}
                            onSelectionChange={onSelectionChange}
                            onEvent={(name, payload) => {
                                if (name === "CollapseRequested") { togglePanel("sources", false); return; }
                                if (name === "ExpandRequested") { togglePanel("sources", true); return; }
                                if (name === "OpenSource") {
                                    const id = (payload as { id: string }).id;
                                    const match = sources.find((s) => s.id === id);
                                    if (match && resolveCitationsLocally) {
                                        setLocalViewer({ type: "doc", data: match });
                                        if (narrow) setTab("chat");
                                    }
                                }
                                onEvent("sources", name, payload);
                            }}
                        />
                    </div>
                ) : null}
            </>
            </div>
            {narrow ? (
                <nav className="ws-tabs">
                    {([
                        ["sources", "Sources", FileText],
                        ["chat", "Chat", MessageSquareText],
                        ["studio", "Studio", Sparkles],
                    ] as [PanelKey, string, IconCmp][]).map(
                        ([k, label, Icon]) => (
                            <button key={k} className={"ws-tab" + (tab === k ? " on" : "")}
                                onClick={() => {
                                    setTab(k);
                                    if (k === "sources") setLeftOpen(true);
                                    if (k === "studio") setRightOpen(true);
                                }}>
                                <Icon size={15} /> {label}
                            </button>
                        ),
                    )}
                </nav>
            ) : null}
        {guardOpen ? (
        <GuardrailDialog g={guardrail} onClose={() => setGuardOpen(false)} />
        ): null}

        {setsOpen ? (
        <SettingsDialog
            schema={settingsSchema}
            initial={workspaceSettingsValues}
            notebookTitle={notebook.title}
            notebookEmoji={notebook.emoji ?? ""}
            onClose={()=> setSetsOpen(false)}
            onSave={(s)=>{ setSetsOpen(false); onEvent("shell", "WorkspaceSettingsSaved", s);}}
            />
        ) : null}

        {addOpen ? (
            <AddDialog
                count={sources.length}
                limit={sourceLimit}
                maxInlineFileBytes={maxInlineFileBytes}
                onClose={() => setAddOpen(false)}
                onEvent={(name, payload) =>{ setAddOpen(false); onEvent("sources", name, payload); }}
            />
            ) : null}
        
            {pathOpen ? (
                <PathDialog
                    defaults={pathDefaults}
                    onClose={() => setPathOpen(false)}
                    onCreate={(role, level, goal) => {
                        setPathOpen(false);
                        onEvent("studio", "createPathRequested",{ role, level, goal});
                    }}
                    />
            ) : null}
            </div>
    );      
};
        

/*-------------settings shape ----------------->*/
export interface WorkspaceSettings {
    title ?: string;
    emoji ?: string;
    answerStyle ?: "concise"|"balanced" |"detailed";
    citationMode ?: "always" | "when-available";
    passMark ?: number;
    strictSources ?: boolean;
}



/*-------------guardrail dialog----------------->*/

const GuardrailDialog: React.FC<{
  g: GuardrailState; onClose: () => void;
}> = ({ g, onClose }) => (
  <div className="scrim" onClick={onClose}>
    <div className="dlg" onClick={(e) => e.stopPropagation()}>
      <div className="dlg-top">
        <div>
          <h3>Domain guardrail</h3>
          <p className="dsub">Why some questions are answered and others are not.</p>
        </div>
        <button className="iconbtn" onClick={onClose} aria-label="Close"><X size={18} /></button>
      </div>

      <div className="dlg-scroll">
        <div className="gd-state">
          <span className={"gd-dot" + (g.active ? " on" : "")} />
          <div>
            <div className="gd-t">{g.active ? "Active" : "Disabled"}</div>
            <div className="gd-s">Scope: {g.domain}</div>
          </div>
          {typeof g.blockedToday === "number" ? (
            <span className="gd-n">{g.blockedToday}<span className="gd-nl">blocked today</span></span>
          ) : null}
        </div>

        <h4 className="gd-h">What this means</h4>
        <p className="gd-p">
          Answers are generated only from the sources selected in this workspace. Questions outside
          retail and consumer goods are refused rather than answered from general knowledge, and
          uploads outside the domain are flagged and left unselected so they cannot ground an answer.
        </p>

        {g.rules && g.rules.length ? (
          <>
            <h4 className="gd-h">In scope</h4>
            <ul className="gd-list">{g.rules.map((r) => <li key={r}>{r}</li>)}</ul>
          </>
        ) : null}
      </div>

      <div className="dlg-act end">
        <button className="pillbtn fill" onClick={onClose}>Got it</button>
      </div>
    </div>
  </div>
);


/* - workspace settings dialog--*/
/* - workspace settings dialog--*/

const SettingsDialog: React.FC<{
  schema: AdminFieldSchema[];
  initial: AdminSettingValues;
  notebookTitle: string;
  notebookEmoji: string;
  onClose: () => void;
  onSave: (s: AdminSettingValues) => void;
}> = ({ schema, initial, notebookTitle, notebookEmoji, onClose, onSave }) => {
  const seeded: AdminSettingValues = {
    title: notebookTitle,
    emoji: notebookEmoji,
    ...initial,
  };
  const [draft, setDraft] = React.useState<AdminSettingValues>(() => withDefaults(schema, seeded));
  const [errors, setErrors] = React.useState<Record<string, string>>({});

  const setField = (key: string, value: AdminSettingValues[string]) => {
    setDraft((d) => ({ ...d, [key]: value }));
    setErrors((e) => { const n = { ...e }; delete n[key]; return n; });
  };

  const handleSave = () => {
    const errs = validateForm(schema, draft);
    setErrors(errs);
    if (Object.keys(errs).length > 0) return;
    onSave(draft);
  };

  const renderField = (f: AdminFieldSchema) => {
    const value = draft[f.key];
    const hasErr = Boolean(errors[f.key]);

    let input: React.ReactNode;
    switch (f.type) {
      case "boolean":
        input = (
          <button className="set-toggle" type="button" disabled={f.readOnly}
            onClick={() => setField(f.key, !value)}>
            <span className={"set-box" + (value ? " on" : "")}>
              {value ? <Check size={12} strokeWidth={3.5} /> : null}
            </span>
            <span>
              {f.label}
              {f.helpText ? <span className="set-hint">{f.helpText}</span> : null}
            </span>
          </button>
        );
        break;
      case "segmented":
      case "choice":
        input = (
          <div className="segs">
            {(f.options ?? []).map((o) => (
              <button key={o} className={"seg" + (value === o ? " on" : "")}
                disabled={f.readOnly} onClick={() => setField(f.key, o)}>
                {o.charAt(0).toUpperCase() + o.slice(1)}
              </button>
            ))}
          </div>
        );
        break;
      case "textarea":
        input = (
          <textarea rows={3} maxLength={f.maxLength} disabled={f.readOnly}
            value={(value as string) ?? ""} onChange={(e) => setField(f.key, e.target.value)} />
        );
        break;
      case "number":
        input = (
          <input type="number" min={f.min} max={f.max} disabled={f.readOnly}
            value={value === null || value === undefined ? "" : Number(value)}
            onChange={(e) => setField(f.key, e.target.value === "" ? null : Number(e.target.value))} />
        );
        break;
      default:
        input = (
          <input type={f.type === "email" ? "email" : "text"}
            minLength={f.minLength} maxLength={f.maxLength} disabled={f.readOnly}
            value={(value as string) ?? ""} onChange={(e) => setField(f.key, e.target.value)} />
        );
    }

    if (f.type === "boolean") {
      return (
        <div className="fld" key={f.key}>
          {input}
          {hasErr ? <div className="fld-err">{errors[f.key]}</div> : null}
        </div>
      );
    }

    return (
      <div className="fld" key={f.key}>
        <label>
          {f.label}
          {f.readOnly ? <span className="fld-note">Set by your admin</span> : null}
        </label>
        {input}
        {hasErr
          ? <div className="fld-err">{errors[f.key]}</div>
          : f.helpText ? <div className="fld-note">{f.helpText}</div> : null}
      </div>
    );
  };

  return (
    <div className="scrim" onClick={onClose}>
      <div className="dlg" onClick={(e) => e.stopPropagation()}>
        <div className="dlg-top">
          <div>
            <h3>Workspace settings</h3>
            <p className="dsub">Applies to every answer and output generated here.</p>
          </div>
          <button className="iconbtn" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>

        <div className="dlg-scroll">
          {schema.map(renderField)}
        </div>

        <div className="dlg-act end">
          <button className="pillbtn" onClick={onClose}>Cancel</button>
          <button className="pillbtn fill" disabled={!String(draft.title ?? "").trim()} onClick={handleSave}>
            Save
          </button>
        </div>
      </div>
    </div>
  );
};