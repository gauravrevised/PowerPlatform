import * as React from "react";
import {
    X, Download, Copy, ChevronDown, Clock, GraduationCap, ListChecks, Lightbulb,
    CircleCheck, FileText, ExternalLink,
} from "lucide-react";
import { ViewerPayload } from "../shared/types";

export interface ViewerProps {
    payload: ViewerPayload;
    onEvent: (name: string, payload?: unknown) => void;
}

export const Viewer: React.FC<ViewerProps> = ({ payload, onEvent }) => {
    const title =
        payload.type === "doc" ? payload.data.title
        : payload.type === "path" ? (payload.data.title ?? `Learning path for ${payload.data.role}`)
        : (payload.data.title ?? "Output");

    return (
        <>
            <div className="vh">
                <button className="iconbtn" aria-label="Back"
                        onClick={() => onEvent("ViewerClosed")}>
                    <X size={18} />
                </button>
                <h3>{title}</h3>
                {/* {payload.type === "doc" ? (
                    <button className="pillbtn"
                            onClick={() => onEvent("DownloadSource", {
                                id: payload.data.id, downloadUrl: payload.data.downloadUrl,
                            })}>
                        <Download size={14} /> Download
                    </button>
                ) : (
                    <button className="pillbtn"
                            onClick={() => onEvent("ExportRequested", { type: payload.type })}>
                        <Copy size={14} /> Export
                    </button>
                )} */}
            </div>

            <div className="vbody">
                <div className="vbody-in">
                    {payload.type === "doc" ? <DocView payload={payload} onEvent={onEvent} /> : null}
                    {payload.type === "slides" ? <SlidesView payload={payload} /> : null}
                    {payload.type === "quiz" ? <QuizView payload={payload} onEvent={onEvent} /> : null}
                    {payload.type === "path" ? <PathView payload={payload} onEvent={onEvent} /> : null}
                    {payload.type === "text" ? <TextView payload={payload} /> : null}
                </div>
            </div>
        </>
    );
};

/* ——— source document ———————————————————————————————————————— */

const DocView: React.FC<{
    payload: Extract<ViewerPayload, { type: "doc" }>;
    onEvent: (name: string, payload?: unknown) => void;
}> = ({ payload, onEvent }) => {
    const d = payload.data;
    return (
        <>
            <div className="vmeta">
                {d.meta ? `${d.meta} • ` : ""}{d.isBuiltIn ? "Built-in source" : "Your source"}
            </div>
            <div className="dlbar">
                <FileText size={22} className="dlicon" />
                <div className="dlbar-b">
                    <div className="dlt">{d.fileName ?? d.title}</div>
                    <div className="dls">
                        {d.isBuiltIn ? "Read-only · licensed for in-app use" : "Uploaded to this notebook"}
                    </div>
                </div>
                {d.url ? (
                    <button className="pillbtn"
                            onClick={() => onEvent("OpenSourceExternal", { id: d.id, url: d.url })}>
                        <ExternalLink size={14} /> Open
                    </button>
                ) : null}
                <button className="pillbtn fill"
                        onClick={() => onEvent("DownloadSource", { id: d.id, downloadUrl: d.downloadUrl })}>
                    <Download size={14} /> Download
                </button>
            </div>

            {d.summary ? (
                <>
                    <h4>Summary</h4>
                    <p>{d.summary}</p>
                </>
            ) : null}
        </>
    );
};

/* ——— slides ———————————————————————————————————————— */

const SlidesView: React.FC<{
    payload: Extract<ViewerPayload, { type: "slides" }>;
}> = ({ payload }) => {
    const [open, setOpen] = React.useState(0);
    return (
        <>
            <p className="vlead">
                {payload.data.slides.length} slides generated from the selected sources. Expand a slide to see its talking points.
            </p>
            {payload.data.slides.map((s, i) => (
                <div className="slide" key={i}>
                    <button className="slide-h" onClick={() => setOpen(open === i ? -1 : i)}>
                        <span className="slide-n">{i + 1}</span>
                        <span className="st">{s.title}</span>
                        <ChevronDown size={16} className={"chev" + (open === i ? " up" : "")} />
                    </button>
                    {open === i ? (
                        <ul className="slide-b">
                            {s.bullets.map((b, j) => <li key={j}>{b}</li>)}
                        </ul>
                    ) : null}
                </div>
            ))}
        </>
    );
};

/* ——— quiz ———————————————————————————————————————— */

const QuizView: React.FC<{
    payload: Extract<ViewerPayload, { type: "quiz" }>;
    onEvent: (name: string, payload?: unknown) => void;
}> = ({ payload, onEvent }) => {
    const questions = payload.data.questions;
    const passMark = payload.data.passMark ?? 70;
    const [picked, setPicked] = React.useState<Record<string, number>>({});
    const [startedAt] = React.useState(() => Date.now());
    const answered = Object.keys(picked).length;
    const correct = questions.reduce(
        (n, q) => n + (picked[q.id] === q.answerIndex ? 1 : 0), 0);

    const choose = (qIndex: number, optIndex: number) => {
        const q = questions[qIndex];
        if (picked[q.id] !== undefined) return;

        const next = { ...picked, [q.id]: optIndex };
        setPicked(next);

        onEvent("QuizAnswered", {
            quizId: payload.data.id,
            questionId: q.id,
            selectedIndex: optIndex,
            correct: optIndex === q.answerIndex,
            answeredAt: new Date().toISOString(),
        });

        if (Object.keys(next).length === questions.length) {
            const score = Math.round(
                (questions.reduce((n, qq) => n + (next[qq.id] === qq.answerIndex ? 1 : 0), 0) / questions.length) * 100
            );
            onEvent("QuizCompleted", {
                quizId: payload.data.id,
                total: questions.length,
                correct: questions.reduce((n, qq) => n + (next[qq.id] === qq.answerIndex ? 1 : 0), 0),
                score,
                passed: score >= passMark,
                durationSeconds: Math.round((Date.now() - startedAt) / 1000),
            });
        }
    };

    return (
        <>
            <p className="vlead">
                {questions.length} questions • pass mark {passMark}%
                {answered > 0 ? ` • ${correct} of ${answered} correct so far.` : ""}
            </p>
            {questions.map((q, i) => {
                const p = picked[q.id];
                return (
                    <div className="qz" key={q.id}>
                        <div className="qq">{i + 1}. {q.prompt}</div>
                        {q.options.map((o, j) => {
                            const cls = p === undefined ? ""
                                : j === q.answerIndex ? " right"
                                : p === j ? " wrong" : "";
                            return (
                                <button key={j} className={"opt" + cls} disabled={p !== undefined}
                                        onClick={() => choose(i, j)}>
                                    <span className="oli">{"ABCDEF"[j]}</span> {o}
                                </button>
                            );
                        })}
                        {p !== undefined && q.explanation ? <div className="why">{q.explanation}</div> : null}
                    </div>
                );
            })}
        </>
    );
};

/* ——— learning path ———————————————————————————————————————— */

const PathView: React.FC<{
    payload: Extract<ViewerPayload, { type: "path" }>;
    onEvent: (name: string, payload?: unknown) => void;
}> = ({ payload, onEvent }) => {
    const d = payload.data;
    const nextModule = d.modules.find((m) => !m.done);
    return (
        <>
            <div className="vmeta">
                {d.level} · {d.totalHours ?? "—"} across {d.modules.length} modules
            </div>

            {d.goal ? (
                <div className="card mt14">
                    <div className="goalrow">
                        <Lightbulb size={16} className="di" />
                        <p className="m0">Sequenced for your stated goal: {d.goal}</p>
                    </div>
                </div>
            ) : null}

            <div className="mt18">
                {d.modules.map((m) => (
                    <div className="mod" key={m.n}>
                        {m.done
                            ? <CircleCheck size={26} className="mod-done" />
                            : <span className="mod-n">{m.n}</span>}
                        <div className="mod-b">
                            <div className="mt">{m.title}</div>
                            {m.desc ? <div className="md">{m.desc}</div> : null}
                            <div className="modchips">
                                {m.hours ? <span className="chip"><Clock size={11} /> {m.hours}</span> : null}
                                {(m.sourceTitles ?? []).map((t) => <span key={t} className="chip">{t}</span>)}
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="vact">
                <button className="pillbtn fill"
                        onClick={() => onEvent("ModuleStarted", {
                            pathId: d.id,
                            moduleNumber: nextModule?.n ?? 1,
                            moduleTitle: nextModule?.title,
                        })}>
                    <GraduationCap size={15} /> {nextModule ? `Start module ${nextModule.n}` : "Review path"}
                </button>
                <button className="pillbtn"
                        onClick={() => onEvent("GenerateModuleQuizRequested", { pathId: d.id })}>
                    <ListChecks size={15} /> Add quiz per module
                </button>
            </div>
        </>
    );
};

/* ——— generic text output ———————————————————————————————————————— */

const TextView: React.FC<{
    payload: Extract<ViewerPayload, { type: "text" }>;
}> = ({ payload }) => {
    return (
        <>
            {payload.data.meta ? <p className="vlead">{payload.data.meta}</p> : null}
            {payload.data.sections.map((s, i) => (
                <div key={i}>
                    {s.heading ? <h4>{s.heading}</h4> : null}
                    {s.body.split("\n\n").map((p, j) => <p key={j}>{p}</p>)}
                </div>
            ))}
        </>
    );
};
