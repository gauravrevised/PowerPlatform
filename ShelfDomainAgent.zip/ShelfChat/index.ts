import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { ChatPanel, ChatPanelProps } from "./ChatPanel";
import {
    ChatMessage, Command, NotebookMeta, SuggestedQuestion, ThemeName, ViewerPayload,
    newId, parseJson,
} from "../shared/types";

export class ShelfChat
    implements ComponentFramework.StandardControl<IInputs, IOutputs> {

    private root!: Root;
    private host!: HTMLDivElement;
    private notify!: () => void;

    private eventName = "";
    private eventPayload = "";
    private eventId = "";
    private draft = "";

    private lastCommandId = "";
    private command?: Command;

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        _state: ComponentFramework.Dictionary,
        container: HTMLDivElement,
    ): void {
        this.notify = notifyOutputChanged;
        context.mode.trackContainerResize(true);

        this.host = document.createElement("div");
        this.host.className = "shelf shelf-chat";
        container.appendChild(this.host);
        this.root = createRoot(this.host);
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        const p = context.parameters;

        const messages = parseJson<ChatMessage[]>(p.MessagesJson?.raw, []);
        const notebook = parseJson<NotebookMeta>(p.NotebookJson?.raw, { title: "Untitled Workspace" });
        const suggested = parseJson<SuggestedQuestion[]>(p.SuggestedJson?.raw, []);
        const viewer = parseJson<ViewerPayload | null>(p.ViewerJson?.raw, null);

        const cmd = parseJson<Command | null>(p.Command?.raw, null);
        if (cmd && cmd.id && cmd.id !== this.lastCommandId) {
            this.lastCommandId = cmd.id;
            this.command = cmd;
            if (cmd.action === "ClearDraft") this.draft = "";
        } else {
            this.command = undefined;
        }

        const h = context.mode.allocatedHeight;
        const w = context.mode.allocatedWidth;
        if (h > 0) this.host.style.height = `${h}px`;
        if (w > 0) this.host.style.width = `${w}px`;

        const props: ChatPanelProps = {
            messages,
            notebook,
            suggested,
            viewer,
            streamingText: p.StreamingText?.raw ?? "",
            isThinking: p.IsThinking?.raw === true,
            selectedCount: p.SelectedCount?.raw ?? 0,
            domainLabel: p.DomainLabel?.raw ?? "Retail & CPG domain only",
            placeholder: p.Placeholder?.raw ?? "Ask anything about retail or consumer goods",
            theme: (p.Theme?.raw || "dark") as ThemeName,
            command: this.command,
            onDraftChange: (t) => { this.draft = t; },
            onEvent: (name, payload) => this.emit(name, payload),
        };

        this.root.render(React.createElement(ChatPanel, props));
    }

    private emit(name: string, payload?: unknown): void {
        this.eventName = name;
        this.eventPayload = payload === undefined ? "" : JSON.stringify(payload);
        this.eventId = newId();
        this.notify();
    }

    public getOutputs(): IOutputs {
        return {
            EventName: this.eventName,
            EventPayload: this.eventPayload,
            EventId: this.eventId,
            DraftText: this.draft,
        };
    }

    public destroy(): void {
        this.root.unmount();
    }
}
