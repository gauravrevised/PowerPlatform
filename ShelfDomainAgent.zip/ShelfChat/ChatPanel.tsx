import * as React from "react";
import {
  Sparkles, Send, Copy, Plus, RefreshCw, Loader2, ShieldCheck, ThumbsUp, ThumbsDown,
  CornerDownRight,Mic, MicOff,
} from "lucide-react";
import {
  ChatMessage, Citation, Command, NotebookMeta, QuestionOrigin, SuggestedQuestion,
  ThemeName, ViewerPayload,
} from "../shared/types";
import { Viewer } from "./Viewer";
import SpeechRecognition, { useSpeechRecognition } from "react-speech-recognition";
import "regenerator-runtime/runtime";

export interface ChatPanelProps {
  messages: ChatMessage[];
  notebook: NotebookMeta;
  suggested: SuggestedQuestion[];
  viewer: ViewerPayload | null;
  streamingText: string;
  isThinking: boolean;
  selectedCount: number;
  domainLabel: string;
  placeholder: string;
  theme: ThemeName;
  command?: Command;
  onDraftChange: (text: string) => void;
  onEvent: (name: string, payload?: unknown) => void;
  /** Supplied by ShelfWorkspace to resolve a citation without a round trip.
   *  Return true if handled locally; otherwise the control emits CitationClicked. */
  onCitationResolve?: (c: Citation, messageId: string) => boolean;
}

export const ChatPanel: React.FC<ChatPanelProps> = (props) => {
  const {
    messages, notebook, suggested, viewer, streamingText, isThinking,
    selectedCount, domainLabel, placeholder, theme, command, onDraftChange, onEvent,
    onCitationResolve,
  } = props;

  const [draft, setDraft] = React.useState("");
  const scrollRef = React.useRef<HTMLDivElement>(null);
  const taRef = React.useRef<HTMLTextAreaElement>(null);
  // ── Speech-to-text ───────────────────────────────────────────────
   const {
      transcript,
      listening,
      resetTranscript,
      browserSupportsSpeechRecognition,
  } = useSpeechRecognition();

  // sync transcript into draft
  React.useEffect(() => {
      if (!listening || !transcript) return;
      const next = draft.slice(0, interimStartRef.current) + transcript;
      setDraft(next);
      onDraftChange(next);
      if (taRef.current) {
          taRef.current.style.height = "auto";
          taRef.current.style.height = taRef.current.scrollHeight + "px";
      }
  }, [transcript, listening]);

  const interimStartRef = React.useRef(0);

  const toggleSpeech = () => {
      if (listening) {
          SpeechRecognition.stopListening();
          interimStartRef.current = draft.length; // commit position
      } else {
          resetTranscript();
          interimStartRef.current = draft.length; // append after existing text
          SpeechRecognition.startListening({ continuous: true, language: "en-US" });
      }
  };
  // ─────────────────────────────────────────────────────────────────
  React.useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages.length, isThinking, streamingText]);

  React.useEffect(() => {
    if (!command) return;
    if (command.action === "ClearDraft") {
      setDraft("");
      onDraftChange("");
      if (taRef.current) taRef.current.style.height = "auto";
    }
    if (command.action === "FocusComposer") taRef.current?.focus();
    if (command.action === "ScrollToBottom" && scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
    if (command.action === "SetDraft") {
      const t = String(command.payload?.text ?? "");
      setDraft(t);
      onDraftChange(t);
    }
  }, [command]);

  const ask = (text: string, origin: QuestionOrigin = "typed", fromMessageId?: string) => {
    const q = text.trim();
    if (!q || isThinking) return;
    onEvent("AskQuestion", { text: q, origin, fromMessageId });
    setDraft("");
    onDraftChange("");
    if (taRef.current) taRef.current.style.height = "auto";
  };

  const handleCitation = (c: Citation, messageId: string) => {
    const handled = onCitationResolve ? onCitationResolve(c, messageId) : false;
    if (handled) return;
    onEvent(c.sourceId || c.fileName ? "CitationClicked" : "CitationUnresolved", {
      messageId, sourceId: c.sourceId, fileName: c.fileName,
index: c.index, page: c.page, url: c.url,
  ...(onCitationResolve ? { resolvedLocally: false } : {}),
  });
  };

  const grow = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setDraft(e.target.value);
    onDraftChange(e.target.value);
    e.target.style.height = "auto";
    e.target.style.height = `${Math.min(e.target.scrollHeight, 120)}px`;
  };

  if (viewer) {
    return (
      <div className="panel" data-t={theme}>
        <Viewer payload={viewer} onEvent={onEvent} />
      </div>
    );
  }

  return (
    <div className="panel" data-t={theme}>
          <div className="hero hero-full">
            {notebook.emoji ? <span className="em">{notebook.emoji}</span> : null}
            <div>
              <h1>{notebook.title}</h1>
              <div className="sub">
                {selectedCount} source{selectedCount === 1 ? "" : "s"} selected · Grounded answers only
              </div>
            </div>
          </div>
      <div className="mid-scroll"  ref={scrollRef}>
        <div className="mid-in">
          {(notebook.summary || (notebook.topics && notebook.topics.length)) ? (
            <div className="card">
              {notebook.summary ? <p>{notebook.summary}</p> : null}
              {notebook.topics && notebook.topics.length ? (
                <div className="chips">
                  {notebook.topics.map((t) => <span key={t} className="chip">{t}</span>)}
                </div>
              ) : null}
            </div>
          ) : null}

          {messages.length === 0 && suggested.length > 0 ? (
            <div className="mt22">
              <div className="startlbl">Start with a question</div>
              {suggested.map((s) => (
                <button key={s.id} className="qchip" onClick={() => ask(s.text, "suggested")}>
                  {s.text}
                </button>
              ))}
            </div>
          ) : null}

          {messages.map((m) =>
            m.role === "user" ? (
              <div className="msg u" key={m.id}><div className="bub">{m.text}</div></div>
            ) : (
              <Answer key={m.id} m={m} onEvent={onEvent} onAsk={ask} onCitation={handleCitation} />
            )
          )}

          {streamingText ? (
            <div className="msg">
              <div className="ares">
                <Sparkles size={17} className="spark" />
                <div className="abody">
                  {streamingText.split("\n\n").map((para, i) => <p key={i}>{para}</p>)}
                  <span className="caret" />
                </div>
              </div>
            </div>
          ) : null}

          {isThinking && !streamingText ? (
            <div className="msg">
              <div className="ares">
                <Loader2 size={17} className="spark spin" />
                <div className="abody faint">Reading {selectedCount} sources...</div>
              </div>
            </div>
          ) : null}
        </div>
      </div>

      <div className="comp">
        <div className="comp-in">
          <textarea
            ref={taRef}
            rows={1}
            value={draft}
            onChange={grow}
            placeholder={listening ? "Listening…" : placeholder}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                SpeechRecognition.stopListening();
                ask(draft);
              }
            }}
          />
          {browserSupportsSpeechRecognition ? (
              <button
                  className={`micbtn${listening ? " active" : ""}`}
                  onClick={toggleSpeech}
                  aria-label={listening ? "Stop listening" : "Speak"}
                  title={listening ? "Stop (recording…)" : "Speak your question"}
              >
                  {listening ? <MicOff size={16} /> : <Mic size={16} />}
              </button>
          ) : null}
          <button
              className="sendbtn"
              disabled={!draft.trim() || isThinking}
              onClick={() => { SpeechRecognition.stopListening(); ask(draft); }}
              aria-label="Send"
          >
              <Send size={16} />
          </button>
        </div>
        <div className="comp-meta">
          <span>{selectedCount} sources selected</span>
          <span>{domainLabel}</span>
        </div>
      </div>
    </div>
  );
};

const Answer: React.FC<{
  m: ChatMessage;
  onEvent: (name: string, payload?: unknown) => void;
  onAsk: (text: string, origin?: QuestionOrigin, fromMessageId?: string) => void;
  onCitation: (c: Citation, messageId: string) => void;
}> = ({ m, onEvent, onAsk, onCitation }) => {
  const [vote, setVote] = React.useState<"up" | "down" | null>(null);
  const paras = m.text.split("\n\n");
  const cites = m.citations ?? [];
  const follow = m.followUps ?? [];
  const blocked = m.status === "blocked";

  const rate = (v: "up" | "down") => {
    setVote(v);
    onEvent("Feedback", { messageId: m.id, vote: v });
  };

  return (
    <div className="msg">
      <div className="ares">
        {blocked ? <ShieldCheck size={17} className="spark bad" /> : <Sparkles size={17} className="spark" />}
        <div className="abody">
          {blocked ? (
            <div className="blocked">
              {paras.map((p, i) => <p key={i} className={i === paras.length - 1 ? "m0" : ""}>{p}</p>)}
            </div>
          ) : (
            <>
              {paras.map((para, i) => (
                <p key={i}>
                  {para}
                  {i === 0 && cites.length > 0 && cites.map((c) => (
                    <span className="citewrap" key={`${c.sourceId}-${c.index}`}>
                      <button className="cite" onClick={() => onCitation(c, m.id)}>
                        {c.index}
                      </button>
                      <span className="citecard">
                        <span className="cc-t">{c.sourceTitle ?? c.fileName ?? c.sourceId}</span>
                        {c.summary ? <span className="cc-s">{c.summary}</span> : null}
                        {c.snippet ? <span className="cc-q">"{c.snippet}"</span> : null}
                        <span className="cc-f">
                          {c.page ? `Page ${c.page} · ` : ""}Click to open
                        </span>
                      </span>
                    </span>
                  ))}
                </p>
              ))}
            </>
          )}

          {m.status === "low" ? (
            <div className="warn">
              <ShieldCheck size={15} className="werr wicon" />
              <span>
                Coverage in the library is thin for this question. Treat the answer as indicative and check the cited sources.
              </span>
            </div>
          ) : null}
        </div>
      </div>

      {cites.length ? (
        <div className="srcnote">
          Grounded in {cites.map((c) => c.sourceTitle ?? c.fileName ?? c.sourceId).join(" · ")}
        </div>
      ) : null}

      <div className="arow">
        <button className="tinybtn" onClick={() => onEvent("CopyAnswer", { messageId: m.id })}>
          <Copy size={14} /> Copy
        </button>
        <button className="tinybtn" onClick={() => onEvent("SaveToNote", { messageId: m.id })}>
          <Plus size={14} /> Save to note
        </button>
        {/* <button className="tinybtn" onClick={() => onEvent("Regenerate", { messageId: m.id })}>
          <RefreshCw size={14} /> Regenerate
        </button> */}
        <span className="spacer" />
        <button className={`tinybtn ${vote === "up" ? "voted" : ""}`} onClick={() => rate("up")} aria-label="Helpful">
          <ThumbsUp size={14} />
        </button>
        <button className={`tinybtn ${vote === "down" ? "voted" : ""}`} onClick={() => rate("down")} aria-label="Not helpful">
          <ThumbsDown size={14} />
        </button>
      </div>

      {follow.length ? (
        <div className="follow">
          <div className="follow-h">Suggested next</div>
          {follow.map((f, i) => (
            <button
              key={i}
              className="fchip"
              onClick={() => onAsk(f, "followup", m.id)}
            >
              <CornerDownRight size={13} /> {f}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
};
