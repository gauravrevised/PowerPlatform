// Manifest-aligned bootstrap types. Regenerate with npm run refreshTypes.
export interface IInputs {
  Title: ComponentFramework.PropertyTypes.StringProperty;
  Subtitle: ComponentFramework.PropertyTypes.StringProperty;
  LastUpdatedOn: ComponentFramework.PropertyTypes.StringProperty;
  Author: ComponentFramework.PropertyTypes.StringProperty;
  VersionLabel: ComponentFramework.PropertyTypes.StringProperty;
  ContentMarkdown: ComponentFramework.PropertyTypes.StringProperty;
  AppName: ComponentFramework.PropertyTypes.StringProperty;
  Theme: ComponentFramework.PropertyTypes.StringProperty;
  ShowBackButton: ComponentFramework.PropertyTypes.TwoOptionsProperty;
  BackLabel: ComponentFramework.PropertyTypes.StringProperty;
  ShowTableOfContents: ComponentFramework.PropertyTypes.TwoOptionsProperty;
  ShowExamples: ComponentFramework.PropertyTypes.TwoOptionsProperty;
  FooterText: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
  EventName?: string;
  EventPayload?: string;
  EventId?: string;
}
