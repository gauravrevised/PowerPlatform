import * as React from "react";
import { EXAMPLE_MARKDOWN } from "./examples";
import { parseDocument, renderTokens } from "./markdown";

export interface HelpPanelProps {
  title: string; subtitle: string; lastUpdatedOn: string; author: string;
  versionLabel: string; content: string; appName: string; theme: "light" | "dark";
  showBackButton: boolean; backLabel: string; showTableOfContents: boolean;
  showExamples: boolean; footerText: string;
  onEvent: (name: string, payload: Record<string, string>) => void;
}

export function formatUpdatedDate(value: string): string {
  if (!/^\d{4}-\d{2}-\d{2}(?:T.*)?$/.test(value)) return value;
  // Date-only content is a calendar date. UTC avoids a previous-day display.
  const date = new Date(value.length === 10 ? `${value}T00:00:00Z` : value);
  return Number.isNaN(date.valueOf()) ? value : new Intl.DateTimeFormat("en", {
    year: "numeric", month: "short", day: "numeric", timeZone: "UTC",
  }).format(date);
}

export const HelpPanel: React.FC<HelpPanelProps> = (props) => {
  const prefix = `sh-${React.useId().replace(/:/g, "")}-`;
  const root = React.useRef<HTMLDivElement>(null);
  const article = React.useRef<HTMLElement>(null);
  const example = !props.content.trim() && props.showExamples;
  const markdown = example ? EXAMPLE_MARKDOWN : props.content;
  const document = React.useMemo(() => {
    try { return { ...parseDocument(markdown), error: "" }; }
    catch (error) { return { tokens: [], headings: [], error: error instanceof Error ? error.message : "Unable to display help content." }; }
  }, [markdown]);
  const [activeId, setActiveId] = React.useState("");
  React.useEffect(() => {
    setActiveId("");
    if (root.current) root.current.scrollTop = 0;
  }, [markdown, props.title]);
  const goToSection = (id: string) => {
    const element = Array.from(article.current?.querySelectorAll<HTMLElement>("[id]") ?? [])
      .find((node) => node.id === prefix + id);
    if (!element) return;
    element.scrollIntoView({ behavior: "auto", block: "start" });
    element.focus({ preventScroll: true });
    setActiveId(id);
  };
  const hasToc = props.showTableOfContents && document.headings.length > 0;

  return <div className="sh-page" data-theme={props.theme} ref={root}>
    <header className="sh-topbar">
      <div className="sh-brand"><span className="sh-brand-mark" aria-hidden="true">S</span>{props.appName}<span className="sh-divider">/</span><span className="sh-top-label">Help center</span></div>
      {props.showBackButton && <button className="sh-back" onClick={() => props.onEvent("NavigateBack", {})}><span aria-hidden="true">←</span> {props.backLabel}</button>}
    </header>
    <main className="sh-main">
      <div className="sh-hero">
        <div className="sh-eyebrow">YOUR WORKSPACE, EXPLAINED</div>
        <h1>{props.title}</h1>
        {props.subtitle && <p className="sh-subtitle">{props.subtitle}</p>}
        <div className="sh-metadata">
          {props.lastUpdatedOn && <span>Updated {formatUpdatedDate(props.lastUpdatedOn)}</span>}
          {props.author && <span>By {props.author}</span>}
          {props.versionLabel && <span className="sh-version">{props.versionLabel}</span>}
          {example && <span className="sh-example-badge">Example content</span>}
        </div>
      </div>
      <div className={`sh-layout${hasToc ? "" : " sh-layout-full"}`}>
        {hasToc && <aside className="sh-sidebar"><nav aria-label="On this page">
          <div className="sh-toc-title">ON THIS PAGE</div>
          {document.headings.map((heading) => <button key={heading.id}
            className={`sh-toc-item${heading.level > 2 ? " sh-toc-sub" : ""}${activeId === heading.id ? " sh-toc-active" : ""}`}
            aria-current={activeId === heading.id ? "location" : undefined}
            onClick={() => goToSection(heading.id)}>{heading.text}</button>)}
        </nav><div className="sh-tip"><strong>Start small.</strong><p>Add one trusted source and ask one focused question.</p></div></aside>}
        <article className="sh-article" ref={article} aria-label={props.title}>
          {document.error ? <div className="sh-empty" role="alert"><h2>Help content could not be displayed</h2><p>{document.error}</p></div>
            : !markdown.trim() ? <div className="sh-empty"><h2>No help content yet</h2><p>Add Markdown to ContentMarkdown, or enable ShowExamples to explore the page.</p></div>
            : renderTokens(document.tokens, { prefix, onSection: goToSection,
                onLink: (url, text) => props.onEvent("LinkClicked", { url, text }) })}
        </article>
      </div>
      <footer className="sh-footer"><span>{props.footerText || `${props.appName} · Help center`}</span>
        <button onClick={() => { if (root.current) root.current.scrollTop = 0; }}>Back to top ↑</button>
      </footer>
    </main>
  </div>;
};
