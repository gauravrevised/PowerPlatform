import * as React from "react";
import { createRoot, Root } from "react-dom/client";
import { IInputs, IOutputs } from "./generated/ManifestTypes";
import { HelpPanel } from "./HelpPanel";

export class ShelfHelp implements ComponentFramework.StandardControl<IInputs, IOutputs> {
  private root!: Root;
  private host!: HTMLDivElement;
  private notify!: () => void;
  private eventName = "";
  private eventPayload = "";
  private eventId = "";
  private eventSequence = 0;

  public init(
    context: ComponentFramework.Context<IInputs>,
    notifyOutputChanged: () => void,
    _state: ComponentFramework.Dictionary,
    container: HTMLDivElement,
  ): void {
    this.notify = notifyOutputChanged;
    context.mode.trackContainerResize(true);
    this.host = document.createElement("div");
    this.host.className = "shelf-help-host";
    container.appendChild(this.host);
    this.root = createRoot(this.host);
  }

  public updateView(context: ComponentFramework.Context<IInputs>): void {
    const p = context.parameters;
    const { allocatedHeight: height, allocatedWidth: width } = context.mode;
    this.host.style.height = height > 0 ? `${height}px` : "100%";
    this.host.style.width = width > 0 ? `${width}px` : "100%";
    this.root.render(React.createElement(HelpPanel, {
      title: p.Title.raw?.trim() || "How can we help?",
      subtitle: p.Subtitle.raw ?? "A practical guide to your Shelf workspace.",
      lastUpdatedOn: p.LastUpdatedOn.raw ?? "",
      author: p.Author.raw ?? "",
      versionLabel: p.VersionLabel.raw ?? "",
      content: p.ContentMarkdown.raw ?? "",
      appName: p.AppName.raw?.trim() || "RCPG Agent",
      theme: p.Theme.raw === "light" ? "light" : "dark",
      showBackButton: p.ShowBackButton.raw !== false,
      backLabel: p.BackLabel.raw?.trim() || "Back to workspace",
      showTableOfContents: p.ShowTableOfContents.raw !== false,
      showExamples: p.ShowExamples.raw !== false,
      footerText: p.FooterText.raw ?? "",
      onEvent: (name, payload) => this.emit(name, payload),
    }));
  }

  private emit(name: string, payload: Record<string, string>): void {
    this.eventName = name;
    this.eventPayload = JSON.stringify(payload);
    // A unique change token, not a database record id.
    this.eventId = `${Date.now()}-${++this.eventSequence}`;
    this.notify();
  }

  public getOutputs(): IOutputs {
    return { EventName: this.eventName, EventPayload: this.eventPayload, EventId: this.eventId };
  }

  public destroy(): void {
    this.root.unmount();
    this.host.remove();
  }
}
