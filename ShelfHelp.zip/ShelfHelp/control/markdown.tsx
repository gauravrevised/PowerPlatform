import * as React from "react";
import MarkdownIt from "markdown-it";

// Render parser tokens as React elements; never inject Markdown-generated HTML.
const parser = new MarkdownIt({ html: false, linkify: true, breaks: false });
export const MAX_MARKDOWN_LENGTH = 100000;
type Token = ReturnType<MarkdownIt["parse"]>[number];
export interface Heading { id: string; text: string; level: number }
export interface ParsedDocument { tokens: Token[]; headings: Heading[] }

export function safeLink(value: string): string | null {
  const url = value.trim();
  if (!url || Array.from(url).some((character) => character.charCodeAt(0) <= 32 || character.charCodeAt(0) === 127)) return null;
  if (url.startsWith("#")) return url;
  if (!/^(https?:\/\/|mailto:)/i.test(url)) return null;
  try {
    const parsed = new URL(url);
    if (parsed.username || parsed.password) return null;
    return url;
  } catch { return null; }
}

export function parseDocument(markdown: string): ParsedDocument {
  if (markdown.length > MAX_MARKDOWN_LENGTH) throw new Error("Help content exceeds 100,000 characters. Split it into smaller pages.");
  const tokens = parser.parse(markdown, {});
  const headings: Heading[] = [];
  const used = new Set<string>();
  tokens.forEach((token, index) => {
    if (token.type !== "heading_open") return;
    const inline = tokens[index + 1];
    const text = (inline?.children ?? [])
      .filter((child) => ["text", "code_inline", "image"].includes(child.type))
      .map((child) => child.content).join("") || inline?.content || "Section";
    const base = text.toLowerCase().trim().replace(/[^\p{L}\p{M}\p{N}\s-]/gu, "").replace(/\s+/g, "-") || "section";
    let id = base;
    let suffix = 2;
    while (used.has(id)) id = `${base}-${suffix++}`;
    used.add(id);
    token.attrSet("id", id);
    headings.push({ id, text, level: Number(token.tag.slice(1)) });
  });
  return { tokens, headings };
}

interface RenderOptions {
  prefix: string;
  onLink: (url: string, text: string) => void;
  onSection: (id: string) => void;
}
const allowedTags = new Set(["p", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li", "blockquote", "strong", "em", "s", "table", "thead", "tbody", "tr", "th", "td"]);

export function renderTokens(tokens: Token[], options: RenderOptions): React.ReactNode[] {
  let cursor = 0;
  const walk = (): React.ReactNode[] => {
    const result: React.ReactNode[] = [];
    while (cursor < tokens.length) {
      const token = tokens[cursor++];
      const key = cursor;
      if (token.nesting === -1) break;
      if (token.nesting === 1) {
        const children = walk();
        if (token.hidden) { result.push(...children); continue; }
        if (token.type === "link_open") {
          const url = safeLink(token.attrGet("href") ?? "");
          result.push(url ? <a key={key} href={url.startsWith("#") ? `#${options.prefix}${url.slice(1)}` : url}
            onClick={(event) => {
              event.preventDefault();
              if (url.startsWith("#")) {
                try { options.onSection(decodeURIComponent(url.slice(1))); } catch { /* Invalid fragment: ignore. */ }
              } else options.onLink(url, event.currentTarget.textContent ?? "");
            }}>{children}</a> : <span key={key}>{children}</span>);
          continue;
        }
        const tag = allowedTags.has(token.tag) ? token.tag : "div";
        const attrs: Record<string, unknown> = { key };
        const headingId = token.attrGet("id");
        if (headingId) { attrs.id = options.prefix + headingId; attrs.tabIndex = -1; }
        if (tag === "ol") attrs.start = Number(token.attrGet("start") ?? 1);
        if (tag === "th" || tag === "td") {
          const alignment = token.attrGet("style")?.match(/^text-align:(left|right|center)$/)?.[1];
          if (alignment) attrs.style = { textAlign: alignment };
        }
        const element = React.createElement(tag, attrs, children);
        result.push(tag === "table" ? <div key={key} className="sh-table-scroll" tabIndex={0} role="region" aria-label="Help table">{element}</div> : element);
      } else if (token.type === "inline") {
        result.push(...renderTokens(token.children ?? [], options));
      } else if (token.type === "text" || token.type === "html_inline" || token.type === "html_block") {
        result.push(token.content);
      } else if (token.type === "code_inline") {
        result.push(<code key={key}>{token.content}</code>);
      } else if (token.type === "fence" || token.type === "code_block") {
        result.push(<div className="sh-code" key={key}>
          {token.info.trim() && <div className="sh-code-language">{token.info.trim().split(/\s+/)[0]}</div>}
          <pre tabIndex={0}><code>{token.content}</code></pre>
        </div>);
      } else if (token.type === "softbreak") result.push("\n");
      else if (token.type === "hardbreak") result.push(<br key={key} />);
      else if (token.type === "hr") result.push(<hr key={key} />);
      // No remote image fetching from host-provided Markdown.
      else if (token.type === "image") result.push(<span className="sh-image-alt" key={key}>[Image: {token.content || "illustration"}]</span>);
    }
    return result;
  };
  return walk();
}
