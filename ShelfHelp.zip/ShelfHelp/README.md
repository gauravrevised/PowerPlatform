# ShelfHelp

A standalone **Power Apps Component Framework (PCF)** help page, created at the workspace root. Its deployed identity is `RCPGDomainAgent.ShelfHelp`.

The control displays a page title, subtitle, update date, author, version, Markdown documentation, a table of contents, a back button, and a footer. It follows the dark/purple styling of the existing Shelf controls and also supports light mode. All styles are scoped to this control.

## Files

- `control/ControlManifest.Input.xml`: Power Apps input/output properties.
- `control/index.ts`: PCF lifecycle, input bindings, and event outputs.
- `control/HelpPanel.tsx`: page layout, metadata, and navigation.
- `control/markdown.tsx`: Markdown parsing and React rendering.
- `control/css/ShelfHelp.css`: responsive dark/light presentation.
- `control/examples.ts`: built-in help displayed when content is blank and `ShowExamples` is true.
- `examples/getting-started.md`: editable copy of that example documentation.
- `examples/properties.json`: sample input values; use individually in the harness, not as a single PCF input.
- `POWERAPPS_SETUP.txt`: copy/paste formulas and integration with the existing `OpenHelp` event.
- `tests/markdown.test.tsx`: parser/rendering regression tests.

## Inputs

| Property | Type | Default / meaning |
| --- | --- | --- |
| `Title` | Text | `How can we help?` |
| `Subtitle` | Text | Description beneath the title |
| `LastUpdatedOn` | Text | Optional ISO date, ISO timestamp, or an already formatted label |
| `Author` | Text | Optional author/team label |
| `VersionLabel` | Text | Optional badge, such as `Guide v1.0` |
| `ContentMarkdown` | Multiline text | Markdown itself; do not JSON-encode it |
| `AppName` | Text | `RCPG Agent` |
| `Theme` | Text | `dark` or `light`; defaults to `dark` |
| `ShowBackButton` | Boolean | Back action visibility |
| `BackLabel` | Text | `Back to workspace` |
| `ShowTableOfContents` | Boolean | Heading navigation visibility |
| `ShowExamples` | Boolean | Show built-in examples only when content is blank |
| `FooterText` | Text | Optional custom footer |

Explicitly bind the three Boolean properties in Canvas. Blank optional author/date/version values are omitted. ISO timestamps are displayed as UTC calendar dates; for a local business date, format the label in Power Apps before supplying it. Plain-text labels are preserved.

## Markdown behavior

Supported: headings, paragraphs, bold, italic, strikethrough, ordered and unordered/nested lists, blockquotes, tables, horizontal rules, inline code, fenced code blocks, line breaks, auto-linked URLs, and Markdown links. Headings generate unique section IDs. The table of contents works with keyboard navigation and remains usable on narrow layouts.

Raw HTML is displayed as text. Markdown is parsed with `markdown-it` and rendered as React elements; the control does not inject HTML. Remote images appear as alt-text placeholders rather than fetching files. Relative links, script/data URLs, and URLs containing credentials are not navigable. Ordinary clicks on HTTP(S)/mailto links emit `LinkClicked`; the host app decides whether to `Launch()` them. Internal `#heading-id` links navigate inside the page.

Code blocks have readable formatting and an optional language label; syntax highlighting, task-list checkboxes, Mermaid, and embedded HTML are not implemented. Content above 100,000 characters produces an explicit error rather than silently truncating.

Use `ShowExamples=true` with `ContentMarkdown=""` to see the included examples immediately in the PCF harness or Canvas. Set `ShowExamples=false` for a real empty-state screen. The example text is sample documentation, not proof that your flows have been configured.

## Build and preview

Run from this `ShelfHelp` folder using Node/npm compatible with the installed PCF tooling:

```powershell
npm install
npm run refreshTypes
npm test
npm run build -- --buildMode production
npm start
```

Use the harness properties from `examples/properties.json`, then try your own Markdown and both themes. The standalone harness does not execute Power Fx; confirm emitted output values there and test navigation in Canvas. After the first successful install, keep the generated `package-lock.json` and use `npm ci` for subsequent builds.

`control/generated/ManifestTypes.d.ts` is supplied for editor support and must be regenerated when the manifest changes. This project does not import code from `ShelfDomainAgent` and does not need the two flows to render help.

## Add to a solution

This new root project is separate from `ShelfDomainAgent/tools/make_solution.py` and its hardcoded control list. Do not add a nonexistent `ShelfDomainAgent/ShelfHelp` entry to that script.

If the existing solution project already exists, run from its directory:

```powershell
# Directory: DomainAgent/ShelfDomainAgent/solution/ShelfMind
pac solution add-reference --path ../../../ShelfHelp
msbuild /t:build /restore /p:Configuration=Release
```

Otherwise create a separate solution under this project:

```powershell
# Directory: DomainAgent/ShelfHelp
New-Item -ItemType Directory -Path solution
Set-Location solution
pac solution init --publisher-name RCPGDomainAgent --publisher-prefix rcpg
pac solution add-reference --path ..
msbuild /t:build /restore /p:Configuration=Release
```

Import the resulting solution ZIP in Power Apps, then insert the Shelf Help code component. The CLI and Visual Studio Build Tools must already be installed for these commands. When updating an already deployed version, increase the manifest version and update the component in the Canvas editor.

## Verification status

The manifest/resources, supplied types, configuration JSON, and integration bindings were checked locally. Node/npm were unavailable in this workspace, so dependency installation, the supplied automated tests, a PCF build, and visual checks in the harness/Canvas still need to run on a machine with the tooling. No deployment has been performed.

Markdown parser documentation: [markdown-it usage](https://github.com/markdown-it/markdown-it/blob/master/docs/usage.md), [rendering safety](https://github.com/markdown-it/markdown-it/blob/master/docs/safety.md).
