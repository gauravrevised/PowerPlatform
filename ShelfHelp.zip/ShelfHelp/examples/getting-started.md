## Get started
Your workspace brings **sources**, **chat**, and **Studio** together. Start with a source you trust, then ask a focused question.

1. Create or open a workspace.
2. Add a website, upload a document, or paste text.
3. Wait for validation, then select the accepted sources.
4. Ask your question in chat.

> **Good to know:** A source must pass validation before it can ground an answer. Check the source list if a file does not appear.

## Add your sources
| Source | What to provide | Example |
| :--- | :--- | :--- |
| Website | An accessible HTTPS URL | A published retail report |
| Document | A supported, readable file | A category review PDF |
| Plain text | A title and the complete passage | Meeting notes |

Accepted file types and upload limits depend on your app configuration. Encrypted or unreadable documents may be rejected.

### Keep the selection focused
- Select only the sources relevant to your question.
- Review citations before relying on an answer.
- Remove outdated material from your workspace.

## Ask a useful question
Give the agent a task and the context it needs. Try:

```text
Compare the key promotion findings across the selected reports.
Give me three takeaways and cite the supporting sources.
```

You can select a suggested follow-up under an answer to keep exploring. An answer marked *low coverage* needs extra checking.

## Create with Studio
Use Studio to turn your selected sources into a slide summary, quiz, study guide, briefing, or learning path.

### Example learning path
- **Role:** Category manager
- **Experience:** New to the field
- **Goal:** Understand assortment and promotion basics

## Troubleshooting
| What you see | What to try |
| --- | --- |
| No sources selected | Tick an accepted source before sending. |
| Upload rejected | Check the size, format, readability, and domain. |
| Answer has no citations | Refine the question or select more relevant sources. |
| Request timed out | Reload and check for a saved result before retrying. |

## Markdown examples
Use **bold**, *italic*, ~~strikethrough~~, and `inline code` to make help easy to scan.

```powerfx
Set(varHelpTitle, "Workspace help");
Set(varHelpMarkdown, "## Welcome" & Char(10) & "Select a source to begin.")
```

[Jump to Get started](#get-started) or visit [Microsoft Learn](https://learn.microsoft.com/power-apps/).

---
This is example help content. Replace it with your team's approved guidance.
