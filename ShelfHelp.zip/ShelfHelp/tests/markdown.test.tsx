import { test } from "node:test";
import assert from "node:assert/strict";
import * as React from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { parseDocument, renderTokens, safeLink, MAX_MARKDOWN_LENGTH } from "../control/markdown";
import { formatUpdatedDate } from "../control/HelpPanel";
import { EXAMPLE_MARKDOWN } from "../control/examples";

function render(text: string): string {
  return renderToStaticMarkup(<div>{renderTokens(parseDocument(text).tokens, {
    prefix: "test-", onLink: () => {}, onSection: () => {},
  })}</div>);
}
test("examples render tables, code, emphasis, and ordered lists", () => {
  const html = render(EXAMPLE_MARKDOWN);
  for (const tag of ["<table>", "<pre", "<strong>", "<ol", "<blockquote>"]) assert.ok(html.includes(tag), tag);
  assert.ok(html.includes('id="test-get-started"'));
});
test("heading ids remain unique, including suffix collisions and Unicode", () => {
  const result = parseDocument("## Intro\n## Intro\n## Intro-2\n## परिचय");
  assert.equal(new Set(result.headings.map((h) => h.id)).size, 4);
  assert.equal(result.headings[3].id, "परिचय");
});
test("raw HTML is text, never executable DOM", () => {
  const html = render('<script>alert(1)</script>\n\n<img src=x onerror="alert(1)">');
  assert.ok(!html.includes("<script"));
  assert.ok(!html.includes("<img"));
  assert.ok(html.includes("&lt;script&gt;"));
});
test("links reject script/data/relative/protocol-relative and credential URLs", () => {
  for (const url of ["javascript:alert(1)", "data:text/html,test", "//evil.example", "/relative", "https://user:pass@example.com", "java\nscript:alert(1)"]) assert.equal(safeLink(url), null);
  assert.equal(safeLink("https://learn.microsoft.com/"), "https://learn.microsoft.com/");
  assert.equal(safeLink("#get-started"), "#get-started");
  assert.equal(safeLink("mailto:help@example.com"), "mailto:help@example.com");
});
test("images do not make remote image requests", () => {
  const html = render("![Diagram](https://example.com/tracker.png)");
  assert.ok(!html.includes("<img"));
  assert.ok(html.includes("[Image: Diagram]"));
});
test("oversized Markdown is rejected rather than silently truncated", () => {
  assert.throws(() => parseDocument("a".repeat(MAX_MARKDOWN_LENGTH + 1)), /100,000/);
});
test("date-only values do not shift across time zones; custom labels survive", () => {
  assert.equal(formatUpdatedDate("2026-10-13"), "Oct 13, 2026");
  assert.equal(formatUpdatedDate("Reviewed quarterly"), "Reviewed quarterly");
});
