from enum import Enum
from pydantic import BaseModel, Field


class Priority(str, Enum):
    critical = "critical"
    high = "high"
    medium = "medium"
    low = "low"


class TicketStatus(str, Enum):
    new = "new"
    in_progress = "in_progress"
    resolved = "resolved"
    closed = "closed"


# --- Request ---

class ServiceNowTicket(BaseModel):
    ticket_id: str = Field(..., min_length=1, max_length=100)
    short_description: str = Field(..., min_length=1, max_length=500)
    priority: Priority
    status: TicketStatus


# --- Responses ---

class HealthResponse(BaseModel):
    status: str


class PublishResponse(BaseModel):
    status: str
    ticket_id: str
    message_id: str | None = None
    message: str | None = None


class ErrorResponse(BaseModel):
    status: str = "error"
    detail: str
