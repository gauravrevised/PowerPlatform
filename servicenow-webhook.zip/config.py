import os

GOOGLE_CLOUD_PROJECT = os.environ.get("GOOGLE_CLOUD_PROJECT")
if not GOOGLE_CLOUD_PROJECT:
    raise RuntimeError("GOOGLE_CLOUD_PROJECT environment variable is not set")

PUBSUB_TOPIC_ID = os.environ.get("PUBSUB_TOPIC_ID", "service-now-events")
FIRESTORE_COLLECTION = os.environ.get("FIRESTORE_COLLECTION", "servicenow_tickets")
