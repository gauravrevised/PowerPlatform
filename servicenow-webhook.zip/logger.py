import logging
import os

def get_logger(name: str) -> logging.Logger:
    """
    Returns a logger integrated with Google Cloud Logging when running on GCP,
    falls back to standard stdout logging locally.
    """
    logger = logging.getLogger(name)

    if logger.handlers:
        return logger

    if os.getenv("K_SERVICE") or os.getenv("GOOGLE_CLOUD_PROJECT"):
        # Running on GCP (Cloud Run / GCE / GKE) — use Cloud Logging handler
        try:
            import google.cloud.logging
            client = google.cloud.logging.Client()
            client.setup_logging(log_level=logging.INFO)
        except Exception:
            # Fallback if Cloud Logging setup fails
            logging.basicConfig(level=logging.INFO)
    else:
        logging.basicConfig(level=logging.INFO)

    logger.setLevel(logging.INFO)
    return logger
