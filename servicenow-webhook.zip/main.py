import json

from fastapi import FastAPI, HTTPException, status
from fastapi.responses import JSONResponse

from app.models import ServiceNowTicket, HealthResponse, PublishResponse, ErrorResponse
from app.firestore_client import ticket_exists, save_ticket
from app.pubsub_client import publish_ticket
from app.logger import get_logger

logger = get_logger(__name__)

app = FastAPI(
    title="ServiceNow Webhook",
    version="1.0.0",
)


@app.exception_handler(Exception)
async def unhandled_exception_handler(request, exc):
    logger.exception("Unhandled error: %s", exc)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content=ErrorResponse(detail="Internal server error").model_dump(),
    )


@app.get(
    "/",
    response_model=HealthResponse,
    status_code=status.HTTP_200_OK,
    tags=["Health"],
)
def health_check():
    return HealthResponse(status="running")


@app.post(
    "/publish",
    response_model=PublishResponse,
    status_code=status.HTTP_200_OK,
    responses={
        409: {"model": ErrorResponse, "description": "Duplicate ticket"},
        500: {"model": ErrorResponse, "description": "Internal server error"},
    },
    tags=["Tickets"],
)
def publish(ticket: ServiceNowTicket):
    logger.info("Received ticket: %s", ticket.ticket_id)

    try:
        if ticket_exists(ticket.ticket_id):
            logger.warning("Duplicate ticket: %s", ticket.ticket_id)
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Ticket {ticket.ticket_id} already exists in Firestore",
            )

        payload = json.dumps(ticket.model_dump())
        message_id = publish_ticket(payload)
        save_ticket(ticket.ticket_id, ticket.model_dump(), message_id)
        logger.info("Published ticket %s with message_id %s", ticket.ticket_id, message_id)

        return PublishResponse(
            status="published",
            ticket_id=ticket.ticket_id,
            message_id=message_id,
        )

    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("Failed to process ticket %s: %s", ticket.ticket_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to publish ticket",
        )
