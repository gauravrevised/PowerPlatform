from datetime import datetime, timezone
from typing import Any

from google.cloud import firestore

from app.config import FIRESTORE_COLLECTION
from app.logger import get_logger

logger = get_logger(__name__)

db = firestore.Client()


def ticket_exists(ticket_id: str) -> bool:
    logger.info("Checking Firestore for ticket: %s", ticket_id)
    doc_ref = db.collection(FIRESTORE_COLLECTION).document(ticket_id)
    exists = doc_ref.get().exists
    logger.info("Firestore lookup result for %s: exists=%s", ticket_id, exists)
    return exists


def save_ticket(ticket_id: str, data: dict[str, Any], message_id: str) -> None:
    logger.info("Writing ticket %s to Firestore", ticket_id)
    doc_ref = db.collection(FIRESTORE_COLLECTION).document(ticket_id)
    doc_ref.set({
        **data,
        "message_id": message_id,
        "created_at": datetime.now(timezone.utc),
    })
    logger.info("Ticket %s written to Firestore successfully", ticket_id)