from google.cloud import pubsub_v1

from app.config import GOOGLE_CLOUD_PROJECT, PUBSUB_TOPIC_ID
from app.logger import get_logger

logger = get_logger(__name__)

publisher = pubsub_v1.PublisherClient()
topic_path = publisher.topic_path(GOOGLE_CLOUD_PROJECT, PUBSUB_TOPIC_ID)


def publish_ticket(payload: str) -> str:
    logger.info("Publishing message to topic: %s", topic_path)
    future = publisher.publish(topic_path, payload.encode("utf-8"))
    message_id = future.result()
    logger.info("Message published successfully, message_id: %s", message_id)
    return message_id
